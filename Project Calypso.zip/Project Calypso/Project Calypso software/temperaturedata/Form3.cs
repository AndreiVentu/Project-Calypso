﻿using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace temperaturedata
{
    public partial class Form3 : Form
    {
        public static int bdrate;
        public static string prtname;
        public static SerialPort myport;
        private string in_data;
        String turb = "";
        String temp = "";
        String pH = "";
        String EC = "";
        String Waterlvl = "";

        public Form3()
        {
            InitializeComponent();
            bdrate = Convert.ToInt32(textBox1.Text);
            comboBox1.Text = "COM1";
            prtname = "COM1";
            myport = new SerialPort();
            prtname = comboBox1.Text;
            myport.PortName = prtname;
            myport.BaudRate = bdrate;
            myport.Parity = Parity.None;
            myport.DataBits = 8;
            myport.StopBits = StopBits.One;
            try
            {
              myport.Close();
              myport.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }              
                           
        }
        public async Task Foo()
        {
            await Task.Delay(4000);
            dataToolStripMenuItem.Enabled = true;
        }
        private async void Form3_Load(object sender, EventArgs e)
        {
            //BackColor = Color.Red;  
            dataToolStripMenuItem.Enabled = false;
            await Foo();                  
        }


        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
                bdrate = Convert.ToInt32(textBox1.Text);
            
        }

        private void graphicsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
        
   

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            prtname = comboBox1.Text;

            myport = new SerialPort();
            prtname = comboBox1.Text;
            myport.PortName = prtname;
            myport.BaudRate = bdrate;
            myport.Parity = Parity.None;
            myport.DataBits = 8;
            myport.StopBits = StopBits.One;
            try
            {
                myport.Close();
                myport.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }

            if (label4.Text == "Connected to : " )
            {
                label4.Text = "Connected to :  " + comboBox1.Text;
            }
            else
            {
                label4.Text = "Connected to :  " + comboBox1.Text;
            }         
        }
       

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void mapsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void googleMapsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {

        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void serialMonitorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
            {
                //MessageBox.Show("Select the Port Name and connect to your Board!");
            }
            else
            {
                Form1 form1 = new Form1();
                form1.Show();

            }
        }

        private void chartsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
            {
                //MessageBox.Show("Select the Port Name and connect to your Board!");
            }
            else
            {
                Form4 form4 = new Form4();
                form4.Show();
            }
        }

        private void mapsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           if (comboBox1.Text == "")
            {
                //MessageBox.Show("Select the Port Name and connect to your Board!");
            }
            else
            {
                Form5 form5 = new Form5();
                form5.Show();
            }
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void dataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form9 frm9 = new Form9();
            frm9.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About frmab = new About();
            frmab.Show();
        }
        private void sendMailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Visible   = true;
            button2.Visible   = true;
            listView1.Visible = true;       
        }

        private void changeEmailAdressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form11 f11 = new Form11();
            f11.Show();
        }

        private void widgetsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mapsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            panel1.Visible = true;
            Form12 myForm = new Form12();    
            myForm.TopLevel = false;
            myForm.AutoScroll = true;
            myForm.ControlBox = false;
            myForm.Text = string.Empty;
            label4.Parent = myForm;
            label2.Parent = myForm;
            label1.Parent = myForm;           
            panel1.Controls.Add(myForm);
            myForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            myForm.Show();
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {
            
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;      
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            label4.Parent = this;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void serialMonitorToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            panel1.Visible = true;
            serialmonitorcntrl myForm = new serialmonitorcntrl();
            myForm.TopLevel = false;
            myForm.AutoScroll = true;
            myForm.ControlBox = false;
            myForm.Text = string.Empty;
            label4.Parent = myForm;
            label2.Parent = myForm;
            label1.Parent = myForm;
            panel1.Controls.Add(myForm);
            myForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            myForm.Show();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }     

        private void button1_Click_3(object sender, EventArgs e)
        {
            //
            int i, k = 0, k1 = 0, j = 0, k2 = 0, k3 = 0, k4 = 0, k5 = 0,k6 = 0,k7 = 0;
            temp = "";
            turb = "";
            pH = "";
            EC = "";
            Waterlvl = "";
            in_data = myport.ReadLine();

            for (i = 0; i < in_data.Length - 1; i++)
            {

                //turb
                if (in_data[i] == '(' && in_data[i + 1] != '(' && in_data[i - 1] != '(')
                {
                    k = i;
                    
                }
                if (in_data[i] == ')' && in_data[i + 1] != ')' && in_data[i - 1] != ')')
                {
                    k1 = i;
                    
                }
                //
                //pH
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(')
                {
                    k2 = i;
                    
                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')')
                {
                    k3 = i;
                   
                }
                //
                // EC
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] == '(' && in_data[i + 3] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(' && in_data[i - 3] != '(')
                {
                    k4 = i;
                    
                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] == ')' && in_data[i + 3] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')' && in_data[i - 3] != ')')
                {
                    k5 = i;
                   
                }

                if(in_data[i]=='*' && in_data[i+1] !='*' && in_data[i - 1] != '*')
                {
                    k6 = i;                  
                }

                if(in_data[i]=='^')
                {
                    k7 = i;
                   
                }
                //

            }

            if (k > 0 && k1 > 0)
            {
                for (j = (k + 1); j < k1 - 1; j++)
                {
                    turb += in_data[j];
                }
            }
            for (j = 0; j < k; j++)
            {
                temp += in_data[j];
            }

            for (j = k2 + 2; j < k3; j++)
            {
                pH += in_data[j];
            }

            for (j = k4 + 3; j < k5; j++)
            {
                EC += in_data[j];
            }

            for(j = k6 + 1;j<k7;j++)
            {
                Waterlvl += in_data[j];
            }

            int F1, F2;
            string Watlvl,temptxt,turbtxt,pHtxt,ECtxt,good;
            F1 = (int)(7 * 1.8) + 32;
            F2 = (int)(15 * 1.8) + 32;
            if (System.IO.File.Exists(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt") == false)
            {
                Form10 f10 = new Form10();
                f10.Show();
            }
            else
            {//
                string line1;
                using (StreamReader reader = new StreamReader(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt"))
                {
                    line1 = reader.ReadLine();
                }

                using (MailMessage mail = new MailMessage())
                {
                    mail.From = new MailAddress("AtlasTeamCL@gmail.com");
                    mail.To.Add(line1);
                    mail.Subject = "Calypo - water quality";

                    if(Convert.ToInt32(Waterlvl) <100)
                    {
                    Watlvl = "Also Calypso is protected!";
                    }
                    else
                    {
                    Watlvl = "Be careful Calypso is not protected!";
                    }
                    int ok = 1;
                    if (Convert.ToSingle(temp.Trim()) >= 7 && Convert.ToSingle(temp.Trim()) <= 15)
                    {
                        temptxt = " which is ok because is between 7° C and 15° C (" + F1 + "° F and " + F2 + "° F)";
                    }
                    else
                    {
                        temptxt = " which should be between 7° C and 15° C (" + F1 + "° F and " + F2 + "° F)";
                        ok = 0;
                    }

                    if(Convert.ToSingle(turb.Trim()) >= 0 && Convert.ToSingle(turb.Trim()) <= 150)
                    {
                        turbtxt = " which is ok because is between 0 NTU and 150 NTU";
                    }
                    else
                    {
                        turbtxt = " which should be between 0 NTU and 150 NTU";
                        ok = 0;
                    }

                    if(Convert.ToSingle(pH.Trim()) >= 6 && Convert.ToSingle(pH.Trim()) <= 8)
                    {
                        pHtxt = " which is ok because is between 6 and 8";
                    }
                    else
                    {
                        pHtxt = " which should be between 6 and 8";
                        ok = 0;
                    }

                    if(Convert.ToSingle(EC.Trim()) >= 5 && Convert.ToSingle(EC.Trim()) <= 50)
                    {
                        ECtxt = " which is ok because is between 5 and 50";
                    }
                    else
                    {
                        ECtxt = " which should be between 5 and 50";
                        ok = 0;
                    }
                    if(ok == 1)
                    {
                         good = "Water quality is good.";
                    }
                    else
                    {
                         good = "Water quality is bad.";
                    }

                    
                    mail.Body = good + "\nTemperature is " + temp.Trim() + temptxt + " \nTurbidity is " + turb.Trim() + turbtxt + " \npH is " + pH.Trim() + pHtxt + " \nElectrical Conductivity is " + EC.Trim() + ECtxt +" \n" + Watlvl;
                                                   
                    // mail.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("AtlasTeamCL@gmail.com", "calypsovs");
                        smtp.EnableSsl = true;                    
                        smtp.Send(mail);
                    }
                    MessageBox.Show("E-mail sent!");

                }
                
            }          
            button2.Visible   = false;
            button1.Visible   = false;
            listView1.Visible = false;
        //
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Visible   = false;
            button1.Visible   = false;
            listView1.Visible = false; 
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void iNFOToolStripMenuItem_Click(object sender, EventArgs e)
        {
           // logo fr = new logo();
            //fr.Show();
        }
    }
}
