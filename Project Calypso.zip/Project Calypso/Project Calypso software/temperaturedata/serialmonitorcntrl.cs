﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace temperaturedata
{
    public partial class serialmonitorcntrl : Form
    {
        private SerialPort myport;
        private string in_data;
        private string bdrate;
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool HideCaret(IntPtr hWnd);

        [DllImport("user32")]
        static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);
        [DllImport("user32")]
        static extern bool EnableMenuItem(IntPtr hMenu, uint uIDEnableItem, uint uEnable);
        const int MF_BYCOMMAND = 0;
        const int MF_DISABLED = 2;
        const int SC_CLOSE = 0xF060;
        public serialmonitorcntrl()
        {
            InitializeComponent();
            myport = new SerialPort();
            myport.PortName = Form3.prtname;
            myport.BaudRate = Convert.ToInt32(Form3.bdrate);
            myport.Parity = Parity.None;
            myport.DataBits = 8;
            myport.StopBits = StopBits.One;
            try
            {
                myport.Close();
                myport.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            
        }


        void myport_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

            in_data = myport.ReadLine();
            if (IsHandleCreated)
            {
                if (InvokeRequired)
                    Invoke(new EventHandler(displaydata_event));
            }
            else
            {
                // Handle the error case, or do nothing.
            }

        }


        private void displaydata_event(object sender, EventArgs e)
        {

            richTextBox1.AppendText(in_data + "\n");

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;
            int start = 0;
            int endpoz = 0;
            string cuvant = textBox1.Text.Trim();
            int endtext = richTextBox1.Text.Length;
            for (int i = 0; i <= endtext; i = start)
            {
                if (i == -1)
                {
                    break;
                }
                start = richTextBox1.Find(cuvant, start, endtext, RichTextBoxFinds.WholeWord);
                if (start >= 0)
                {
                    count++;
                    richTextBox1.SelectionBackColor = Color.Yellow;
                    endpoz = textBox1.Text.Length;
                    start = start + endpoz;
                }
            }
            if (count == 0)
            {
                MessageBox.Show("No Match Found!");//daca  nu gaseste un caracter din textbox.text 
            }

        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            try
            {
                string pathfile = @"D:\Andrei";
                string filename = "data.txt";
                System.IO.File.WriteAllText(pathfile + filename, richTextBox1.Text);
                MessageBox.Show("Done!Just go to " + pathfile, "");

            }
            catch (Exception ex3)
            {
                MessageBox.Show(ex3.Message, "ERROR");
            }
        }

        private void stop_brn_Click(object sender, EventArgs e)
        {
            try
            {
                myport.Close();
                MessageBox.Show("Port Closed!");
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message, "ERROR");
            }
        }

        private void start_btn_Click(object sender, EventArgs e)
        {
            myport.DataReceived += myport_DataReceived;
            richTextBox1.Text = "";
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                richTextBox1.SelectionStart = richTextBox1.Text.Length;
                richTextBox1.ScrollToCaret();
            }
        }

        private void serialmonitorcntrl_Load(object sender, EventArgs e)
        {
            bdrate = "9600";
        }

        private void Data_tb_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                myport.Close();
            }
            else
            {
                myport.Open();
            }
        }
    }
}
