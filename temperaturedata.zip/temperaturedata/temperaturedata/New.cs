﻿using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Net.Mail;
using System.Net;

namespace temperaturedata
{
    public partial class New : Form
    {
        private string in_data;
        public static int bdrate;
        public static string prtname;
        public static SerialPort myport;
        String turb = "";
        String temp = "";
        String pH = "";
        String EC = "";
        String Waterlvl = "";
        

        public New()
        {
            InitializeComponent();
            timer1.Start();
            bunifuCircleProgressbar14.LabelVisible = false;
            bunifuCircleProgressbar13.LabelVisible = false;
            bunifuCircleProgressbar12.LabelVisible = false;
            bunifuCircleProgressbar11.LabelVisible = false;
            bunifuCircleProgressbar1.LabelVisible = true;
            bunifuCircleProgressbar10.LabelVisible = false;
            bunifuCircleProgressbar9.LabelVisible = false;
            bunifuCircleProgressbar8.LabelVisible = false;
            bunifuCircleProgressbar7.LabelVisible = false;
            bunifuCircleProgressbar3.LabelVisible = false;
            bunifuCircleProgressbar4.LabelVisible = false;
            bunifuCircleProgressbar5.LabelVisible = false;
            bunifuCircleProgressbar6.LabelVisible = false;
            bunifuFlatButton6.IconVisible = true;
            bunifuFlatButton7.IconVisible = true;
            bunifuFlatButton13.IconVisible = true;
            bunifuFlatButton14.IconVisible = true;
            bunifuFlatButton12.IconVisible = true;
            bunifuFlatButton11.IconVisible = true;
            bunifuFlatButton21.IconVisible = true;
            bunifuFlatButton22.IconVisible = true;
            bunifuFlatButton23.IconVisible = true;
            bunifuFlatButton24.IconVisible = true;
            bunifuFlatButton25.IconVisible = true;
            bunifuFlatButton20.IconVisible = true;
            bunifuFlatButton27.IconVisible = true;



            ////////////initializare port
            bdrate = 9600;
            comboBox1.Text = "COM3";
            //prtname = 
            myport = new SerialPort();
            //prtname = comboBox1.Text;
            myport.PortName = "COM3";
            myport.BaudRate = bdrate;
            myport.Parity = Parity.None;
            myport.DataBits = 8;
            myport.StopBits = StopBits.One;
            try
            {
                myport.Close();
                myport.Open();
                label47.ForeColor = Color.FromArgb(0, 192, 0);
                label47.Text = "Connected";
               
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message, "Error");
                label47.ForeColor = Color.Red;
                label47.Text = "Disconnected";
                label47.Font = new Font("Verdana", 12);
                label47.Location = new Point(label47.Location.X - 4, label47.Location.Y+2);
                bunifuCustomLabel12.Text = "Disconnected";
                bunifuCustomLabel12.Location = new Point(bunifuCustomLabel12.Location.X - 17, bunifuCustomLabel12.Location.Y);

            }
           
            //////////////
        }
       

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void New_Load(object sender, EventArgs e)
        {
            //serial////////
            myport.DataReceived += myport_DataReceived;
            richTextBox1.Text = "";
            ///////////////

            chart2.ChartAreas[0].AxisY.Maximum = 150;
            chart5.ChartAreas[0].AxisY.Maximum = 150;
            chart2.ChartAreas[0].AxisY.Minimum = 120;
             
        }
        public async Task a()
        {
            await Task.Delay(1000);

        }

        public async Task b()
        {
            await Task.Delay(1500);

        }

        public async Task Foo()
        {
            await Task.Delay(3000);

        }
        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            Form9 g = new Form9();
            g.Show();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(Maps);
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(Charts);
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(Serial_Monitor);
        }
       

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton10_Click(object sender, EventArgs e)
        {
            if (panel2.Width == 56)
            {              
                panel2.Width = 227;
                tabControl1.Width = 960;
                tabControl1.Left =  219;
                panel3.Location = new Point(panel3.Location.X - 25, panel3.Location.Y);
                panel4.Location = new Point(panel4.Location.X - 25, panel4.Location.Y);
                panel5.Location = new Point(panel5.Location.X - 25, panel5.Location.Y);
                panel6.Location = new Point(panel6.Location.X - 25, panel6.Location.Y);
                panel7.Location = new Point(panel7.Location.X - 25, panel7.Location.Y);
                panel8.Location = new Point(panel8.Location.X - 25, panel8.Location.Y);
           
                //

                tabControl2.Location = new Point(tabControl2.Location.X - 45, tabControl2.Location.Y);
                tabControl2.Width = 965;
                panel9.Location = new Point(panel9.Location.X - 5, panel9.Location.Y);
                panel10.Location = new Point(panel10.Location.X - 5, panel10.Location.Y);
                panel11.Location = new Point(panel11.Location.X - 5, panel11.Location.Y);
                panel12.Location = new Point(panel12.Location.X - 5, panel12.Location.Y);
                panel13.Width = 1184;

                bunifuFlatButton16.Location = new Point(bunifuFlatButton16.Location.X - 60, bunifuFlatButton16.Location.Y);
                bunifuFlatButton17.Location = new Point(bunifuFlatButton17.Location.X - 60, bunifuFlatButton17.Location.Y);
                bunifuFlatButton18.Location = new Point(bunifuFlatButton18.Location.X - 60, bunifuFlatButton18.Location.Y);
                bunifuFlatButton19.Location = new Point(bunifuFlatButton19.Location.X - 60, bunifuFlatButton19.Location.Y);
                bunifuFlatButton26.Location = new Point(bunifuFlatButton26.Location.X - 60, bunifuFlatButton26.Location.Y);
                //

                label2.Location = new Point(label2.Location.X - 130, label2.Location.Y);
                label3.Location = new Point(label3.Location.X - 130, label3.Location.Y);
                label4.Location = new Point(label4.Location.X - 130, label4.Location.Y);
                label5.Location = new Point(label5.Location.X - 130, label5.Location.Y);
                label6.Location = new Point(label6.Location.X - 130, label6.Location.Y);
                label7.Location = new Point(label7.Location.X - 130, label7.Location.Y);
                panel30.Location = new Point(panel30.Location.X - 52, panel30.Location.Y);
                richTextBox1.Location = new Point(richTextBox1.Location.X - 130, richTextBox1.Location.Y);
                Serial_Monitor.BackColor = Color.FromArgb( 57, 61, 120);
                panel30.Width = 960;
                label1.Location = new Point(label1.Location.X - 70, label1.Location.Y);
                pictureBox4.Image = Image.FromFile("D:/BucurestiTechlallenge/temperaturedata/2_bun.jpg");
               
            }
            else
            {
                panel2.Width = 56;
                tabControl1.Width = 1180;
                tabControl1.Left = -1;
                panel3.Location = new Point(panel3.Location.X + 25, panel3.Location.Y);
                panel4.Location = new Point(panel4.Location.X + 25, panel4.Location.Y);
                panel5.Location = new Point(panel5.Location.X + 25, panel5.Location.Y);
                panel6.Location = new Point(panel6.Location.X + 25, panel6.Location.Y);
                panel7.Location = new Point(panel7.Location.X + 25, panel7.Location.Y);
                panel8.Location = new Point(panel8.Location.X + 25, panel8.Location.Y);
               
                //

                tabControl2.Location = new Point(tabControl2.Location.X  +45, tabControl2.Location.Y);
                tabControl2.Width = 1132;
                panel9.Location = new Point(panel9.Location.X + 5, panel9.Location.Y);
                panel10.Location = new Point(panel10.Location.X + 5, panel10.Location.Y);
                panel11.Location = new Point(panel11.Location.X + 5, panel11.Location.Y);
                panel12.Location = new Point(panel12.Location.X + 5, panel12.Location.Y);
                panel13.Width = 1350;

                bunifuFlatButton16.Location = new Point(bunifuFlatButton16.Location.X + 60, bunifuFlatButton16.Location.Y);
                bunifuFlatButton17.Location = new Point(bunifuFlatButton17.Location.X + 60, bunifuFlatButton17.Location.Y);
                bunifuFlatButton18.Location = new Point(bunifuFlatButton18.Location.X + 60, bunifuFlatButton18.Location.Y);
                bunifuFlatButton19.Location = new Point(bunifuFlatButton19.Location.X + 60, bunifuFlatButton19.Location.Y);
                bunifuFlatButton26.Location = new Point(bunifuFlatButton26.Location.X + 60, bunifuFlatButton26.Location.Y);
                //

                label2.Location = new Point(label2.Location.X + 130, label2.Location.Y);
                label3.Location = new Point(label3.Location.X + 130, label3.Location.Y);
                label4.Location = new Point(label4.Location.X + 130, label4.Location.Y);
                label5.Location = new Point(label5.Location.X + 130, label5.Location.Y);
                label6.Location = new Point(label6.Location.X + 130, label6.Location.Y);
                label7.Location = new Point(label7.Location.X + 130, label7.Location.Y);
                panel30.Location = new Point(panel30.Location.X + 52, panel30.Location.Y);
                richTextBox1.Location = new Point(richTextBox1.Location.X + 130, richTextBox1.Location.Y);
                Serial_Monitor.BackColor = Color.FromArgb(28, 32, 84);
                panel30.Width = 1127;
                label1.Location = new Point(label1.Location.X + 70, label1.Location.Y);
                pictureBox4.Image = Image.FromFile("D:/BucurestiTechlallenge/temperaturedata/1_bun.jpg");
               

            }
        }

        private void bunifuFlatButton6_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void gMapControl1_Load(object sender, EventArgs e)
        {
            gMapControl1.DragButton = MouseButtons.Left;
            gMapControl1.CanDragMap = true;
            gMapControl1.MapProvider = GMapProviders.GoogleMap;
            gMapControl1.Position = new PointLatLng(44.438226, 26.051790);
            gMapControl1.MinZoom = 0;
            gMapControl1.MaxZoom = 24;
            gMapControl1.Zoom = 11;
            gMapControl1.AutoScroll = true;
            GMapOverlay markersOverlay = new GMapOverlay("markers");
            GMarkerGoogle marker = new GMarkerGoogle(new PointLatLng(44.438226, 26.051790),
            GMarkerGoogleType.green);
            markersOverlay.Markers.Add(marker);
            gMapControl1.Overlays.Add(markersOverlay);
        }

        private void bunifuFlatButton7_Click_1(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton14_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton13_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(Home);
        }

        private void bunifuFlatButton8_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(Settings);
        }

        private void bunifuFlatButton9_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(About);
        }

        private void bunifuFlatButton11_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(Settings);
            bunifuFlatButton8.selected = true;
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gMapControl2_Load(object sender, EventArgs e)
        {
            gMapControl2.DragButton = MouseButtons.Left;
            gMapControl2.CanDragMap = false;
            gMapControl2.MapProvider = GMapProviders.GoogleMap;
            gMapControl2.Position = new PointLatLng(44.438226, 26.051790);
            gMapControl2.MinZoom = 8;
            gMapControl2.MaxZoom = 8;
            gMapControl2.Zoom = 8;
            gMapControl2.AutoScroll = true;
            GMapOverlay markersOverlay = new GMapOverlay("markers");
            GMarkerGoogle marker = new GMarkerGoogle(new PointLatLng(44.438226, 26.051790),
            GMarkerGoogleType.green);
            markersOverlay.Markers.Add(marker);
            gMapControl2.Overlays.Add(markersOverlay);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            bunifuCircleProgressbar1.Value = bunifuCircleProgressbar1.Value + 10;
            if(bunifuCircleProgressbar1.Value >=50)
            {
                timer1.Stop();
                bunifuCircleProgressbar1.animated = false;
            }
        }

        private void Home_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
      

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            panel32.Visible = true;
            panel32.Location = new Point(panel32.Location.X, panel32.Location.Y-3);
            panel32.Visible = false;
            panel32.Height = 210;
            bunifuFlatButton14.Visible = false;
            bunifuTransition1.ShowSync(panel32);      
            bunifuFlatButton28.Visible = true;
            
            
        }

        private void bunifuFlatButton28_Click(object sender, EventArgs e)
        {           
            panel32.Height = 10;
            bunifuTransition2.ShowSync(panel32);          
            bunifuFlatButton28.Visible = false;
            panel32.Visible = false;
            panel32.Location = new Point(panel32.Location.X, panel32.Location.Y + 3);
            bunifuFlatButton14.Visible = true;
        }

        private void bunifuFlatButton7_Click_2(object sender, EventArgs e)
        {
            panel32.Visible = true;
            panel32.Location = new Point(panel32.Location.X, panel32.Location.Y -3);
            panel32.Visible = false;
            panel32.Height = 210;
            bunifuFlatButton14.Visible = false;
            bunifuTransition1.ShowSync(panel32);
            bunifuFlatButton28.Visible = true;
        }

        private void bunifuFlatButton13_Click_1(object sender, EventArgs e)
        {
            panel32.Visible = true;
            panel32.Location = new Point(panel32.Location.X, panel32.Location.Y -3);
            panel32.Visible = false;
            panel32.Height = 210;
            bunifuFlatButton14.Visible = false;
            bunifuTransition1.ShowSync(panel32);
            bunifuFlatButton28.Visible = true;
        }

        private void bunifuFlatButton14_Click_1(object sender, EventArgs e)
        {
            panel32.Visible = true;
            panel32.Location = new Point(panel32.Location.X, panel32.Location.Y -3);
            panel32.Visible = false;
            panel32.Height = 210;
            bunifuFlatButton14.Visible = false;
            bunifuTransition1.ShowSync(panel32);
            bunifuFlatButton28.Visible = true;
        }

        private void bunifuFlatButton17_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (bunifuCheckbox21.Checked)
            {
                richTextBox1.SelectionStart = richTextBox1.Text.Length;
                richTextBox1.ScrollToCaret();
            }
        }

        private void bunifuCustomLabel5_Click(object sender, EventArgs e)
        {

        }

        private void bunifuCustomLabel6_Click(object sender, EventArgs e)
        {

        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton17_Click_1(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage3);
        }

        private void bunifuFlatButton16_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage2);
        }

        private void bunifuFlatButton20_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage1);
        }

        private void bunifuSlider1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton22_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton18_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage4);
        }

        private void bunifuFlatButton19_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage5);
        }

        private void bunifuFlatButton25_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage1);
        }

        private void bunifuFlatButton24_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage1);
        }

        private void bunifuFlatButton23_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage1);
        }

        private void bunifuTextbox1_OnTextChange(object sender, EventArgs e)
        {                       
            
        }

        private void panel30_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void panel30_Click(object sender, EventArgs e)
        {
            
            
        }

        //serial///////////////////////////////////////////////////////////////////////// 

        
        async void myport_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            in_data = myport.ReadLine();
            await Foo();
            if (IsHandleCreated)
            {
                if (InvokeRequired)
                    Invoke(new EventHandler(displaydata_event));
            }
            else
            {
                // Handle the error case, or do nothing.
            }

            /////////////////////////////////////////
            int i, k = 0, k1 = 0, j = 0, k2 = 0, k3 = 0, k4 = 0, k5 = 0, k6 = 0, k7 = 0;
            temp = "";
            turb = "";
            pH = "";
            EC = "";
            Waterlvl = "";
            

            for (i = 0; i < in_data.Length - 1; i++)
            {

                //turb
                if (in_data[i] == '(' && in_data[i + 1] != '(' && in_data[i - 1] != '(')
                {
                    k = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] != ')' && in_data[i - 1] != ')')
                {
                    k1 = i;

                }
                //
                //pH
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(')
                {
                    k2 = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')')
                {
                    k3 = i;

                }
                //
                // EC
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] == '(' && in_data[i + 3] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(' && in_data[i - 3] != '(')
                {
                    k4 = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] == ')' && in_data[i + 3] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')' && in_data[i - 3] != ')')
                {
                    k5 = i;

                }
                if (in_data[i] == '*' && in_data[i + 1] != '*' && in_data[i - 1] != '*')
                {
                    k6 = i;
                }

                if (in_data[i] == '^')
                {
                    k7 = i;

                }
                //

            }

            if (k > 0 && k1 > 0)
            {
                for (j = (k + 1); j < k1 ; j++)
                {
                    turb += in_data[j];
                }
            }
            for (j = 0; j < k; j++)
            {
                temp += in_data[j];
            }

            for (j = k2 + 2; j < k3; j++)
            {
                pH += in_data[j];
            }

            for (j = k4 + 3; j < k5; j++)
            {
                EC += in_data[j];
            }

            for (j = k6 + 1; j < k7; j++)
            {
                Waterlvl += in_data[j];
            }

            if (IsHandleCreated)
            {
                if (InvokeRequired)
                    Invoke(new EventHandler(displaydata_event));
            }
            else
            {
                // Handle the error case, or do nothing.
            }
        }
       
        private async void displaydata_event(object sender, EventArgs e)
        {
            richTextBox1.AppendText(in_data + "\n");
            /////
            chart1.Series["Temperature"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), temp);
            chart2.Series["Turbidity"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), turb);
            chart3.Series["pH"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), pH);
            chart4.Series["ELC"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), EC);
            chart5.Series["Temperature"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), temp);
            chart5.Series["Turbidity"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), turb);
            chart5.Series["pH"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), pH);
            chart5.Series["ELC"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), EC);
            //
            label44.Text = temp.Trim();
            label45.Text = turb.Trim();
            label46.Text = pH.Trim();
            await a();        
           
            //bunifuCircleProgressbar3.Value = Convert.ToInt32(temp.Trim());
            label57.Text = temp.Trim();
            //bunifuCircleProgressbar4.Value = Convert.ToInt32(turb.Trim());
            label58.Text = turb.Trim();
            //bunifuCircleProgressbar5.Value = Convert.ToInt32(pH.Trim());
            label59.Text = pH.Trim();
            //bunifuCircleProgressbar6.Value = Convert.ToInt32(EC.Trim()); ;
            label60.Text = EC.Trim();

            bunifuCustomLabel8.Text = temp.Trim();
          //  bunifuCircleProgressbar14.Value = Convert.ToInt32(temp.Trim());
            bunifuCustomLabel9.Text = turb.Trim();
            //bunifuCircleProgressbar13.Value = Convert.ToInt32(temp.Trim());
            bunifuCustomLabel10.Text = pH.Trim();
            //bunifuCircleProgressbar12.Value = Convert.ToInt32(temp.Trim());
            bunifuCustomLabel11.Text = EC.Trim();
            //bunifuCircleProgressbar11.Value = Convert.ToInt32(temp.Trim());
            bunifuCustomLabel1.Text = temp.Trim() + "C";

        }

        private void richTextBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (bunifuCheckbox21.Checked)
            {
                richTextBox1.SelectionStart = richTextBox1.Text.Length;
                richTextBox1.ScrollToCaret();
            }
        }

        private void bunifuImageButton6_Click(object sender, EventArgs e)
        {
            int count = 0;
            int start = 0;
            int endpoz = 0;
            string cuvant = bunifuTextbox1.Text.Trim();
            int endtext = richTextBox1.Text.Length;
            for (int i = 0; i <= endtext; i = start)
            {
                if (i == -1)
                {
                    break;
                }
                start = richTextBox1.Find(cuvant, start, endtext, RichTextBoxFinds.WholeWord);
                if (start >= 0)
                {
                    count++;
                    richTextBox1.SelectionBackColor = Color.Yellow;
                    endpoz = bunifuTextbox1.Text.Length;
                    start = start + endpoz;
                }
            }
            if (count == 0)
            {
                MessageBox.Show("No Match Found!");//daca  nu gaseste un caracter din textbox.text 
            }          
        }

        private void bunifuCheckbox21_OnChange(object sender, EventArgs e)
        {
            
        }

        private void bunifuTextbox5_OnTextChange(object sender, EventArgs e)
        {
                                                           
        }

        private void bunifuFlatButton26_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage6);
        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton27_Click(object sender, EventArgs e)
        {
            tabControl2.SelectTab(tabPage1);
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton6_MouseHover(object sender, EventArgs e)
        {
           
        }

        

        private void panel32_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Serial_Monitor_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Settings_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTextbox12_OnTextChange(object sender, EventArgs e)
        {

        }

        private void label52_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void bunifuFlatButton21_Click(object sender, EventArgs e)
        {

        }

        private void bunifuCustomLabel2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuSwitch2_Click(object sender, EventArgs e)
        {
            if (bunifuSwitch2.Value == true)
            {

                chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
                chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = true;

                chart2.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
                chart2.ChartAreas[0].AxisY.MajorGrid.Enabled = true;

                chart3.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
                chart3.ChartAreas[0].AxisY.MajorGrid.Enabled = true;

                chart4.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
                chart4.ChartAreas[0].AxisY.MajorGrid.Enabled = true;

                chart5.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
                chart5.ChartAreas[0].AxisY.MajorGrid.Enabled = true;
                

            }
            else
            {
                chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;

                chart2.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chart2.ChartAreas[0].AxisY.MajorGrid.Enabled = false;

                chart3.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chart3.ChartAreas[0].AxisY.MajorGrid.Enabled = false;

                chart4.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chart4.ChartAreas[0].AxisY.MajorGrid.Enabled = false;

                chart5.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chart5.ChartAreas[0].AxisY.MajorGrid.Enabled = false;

            }
        }

       

        private void panel34_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuGauge1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void panel33_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label72_Click(object sender, EventArgs e)
        {

        }

        private async void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            panel35.Visible = true;
            label51.Visible = true;
            panel35.BackColor = Color.Green;
            label51.Text = "Done";
            pictureBox6.Image = Image.FromFile("F:/Andrei/Andrei/BucurestiSalon/done.png");
            pictureBox6.Visible = true;
            await b();
            panel35.BackColor = Color.FromArgb(36, 40, 105);
            label51.Visible = false;
            pictureBox6.Visible = false;

        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

        }

        private async void bunifuTileButton3_Click(object sender, EventArgs e)
        {
           
            try
            {

                panel35.Visible = true;
                panel35.BackColor = Color.Green;
                label51.Visible = true;
                label51.Text = "Done";
                pictureBox6.Image = Image.FromFile("F:/Andrei/Andrei/BucurestiSalon/done.png");
                pictureBox6.Visible = true;
                await b();
                panel35.BackColor = Color.FromArgb(36, 40, 105);
                label51.Visible = false;
                pictureBox6.Visible = false;

                int F1, F2;
                string Watlvl, temptxt, turbtxt, pHtxt, ECtxt, good;
                F1 = (int)(7 * 1.8) + 32;
                F2 = (int)(15 * 1.8) + 32;
                using (MailMessage mail = new MailMessage())
                {
                    mail.From = new MailAddress("AtlasTeamCL@gmail.com");
                    mail.To.Add("andrei.t.ventuneac@gmail.com");
                    mail.Subject = "Calypo - water quality";
                    if (Convert.ToInt32(Waterlvl) < 100)
                    {
                        Watlvl = "Also Calypso is protected!";
                    }
                    else
                    {
                        Watlvl = "Be careful Calypso is not protected!";
                    }
                    int ok = 1;
                    if (Convert.ToSingle(temp.Trim()) >= 7 && Convert.ToSingle(temp.Trim()) <= 15)
                    {
                        temptxt = " which is ok because is between 7° C and 15° C (" + F1 + "° F and " + F2 + "° F)";
                    }
                    else
                    {
                        temptxt = " which should be between 7° C and 15° C (" + F1 + "° F and " + F2 + "° F)";
                        ok = 0;
                    }

                    if (Convert.ToSingle(turb.Trim()) >= 0 && Convert.ToSingle(turb.Trim()) <= 150)
                    {
                        turbtxt = " which is ok because is between 0 NTU and 150 NTU";
                    }
                    else
                    {
                        turbtxt = " which should be between 0 NTU and 150 NTU";
                        ok = 0;
                    }

                    if (Convert.ToSingle(pH.Trim()) >= 6 && Convert.ToSingle(pH.Trim()) <= 8)
                    {
                        pHtxt = " which is ok because is between 6 and 8";
                    }
                    else
                    {
                        pHtxt = " which should be between 6 and 8";
                        ok = 0;
                    }

                    if (Convert.ToSingle(EC.Trim()) >= 5 && Convert.ToSingle(EC.Trim()) <= 50)
                    {
                        ECtxt = " which is ok because is between 5 and 50";
                    }
                    else
                    {
                        ECtxt = " which should be between 5 and 50";
                        ok = 0;
                    }
                    if (ok == 1)
                    {
                        good = "Water quality is good.";
                    }
                    else
                    {
                        good = "Water quality is bad.";
                    }


                    mail.Body = good + "\nTemperature is " + temp.Trim() + temptxt + " \nTurbidity is " + turb.Trim() + turbtxt + " \npH is " + pH.Trim() + pHtxt + " \nElectrical Conductivity is " + EC.Trim() + ECtxt + " \n" + Watlvl;

                    // mail.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("AtlasTeamCL@gmail.com", "calypsovs");
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                    MessageBox.Show("E-mail sent!");
                }


            }catch(Exception ex)
            {
                panel35.Visible = true;
                panel35.BackColor = Color.Red;
                label51.Visible = true;
                label51.Text = "Error";
                pictureBox6.Image = Image.FromFile("F:/Andrei/Andrei/BucurestiSalon/ndone.png");
                pictureBox6.Visible = true;
                await b();
                panel35.BackColor = Color.FromArgb(36, 40, 105);
                label51.Visible = false;
                pictureBox6.Visible = false;
                MessageBox.Show(ex.Message);
            }

            }

        private async void bunifuTileButton2_Click(object sender, EventArgs e)
        {
            panel35.Visible = true;
            panel35.BackColor = Color.Red;
            label51.Visible = true;
            label51.Text = "Error";
            pictureBox6.Image = Image.FromFile("F:/Andrei/Andrei/BucurestiSalon/ndone.png");
            pictureBox6.Visible = true;
            await b();
            panel35.BackColor = Color.FromArgb(36, 40, 105);
            label51.Visible = false;
            pictureBox6.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
              //  myport.PortName = comboBox1.SelectedItem.ToString();                    
                   
      
        }

        private void pictureBox6_Click_1(object sender, EventArgs e)
        {

        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {

            comboBox1.Items.Clear();
            string[] ports = SerialPort.GetPortNames();



            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            Form14  f = new Form14();
            f.Show();
        }

        private void panel35_Paint(object sender, PaintEventArgs e)
        {

        }




        //serial//////////////////////////////////////////////////////////////////////////////////////


    }
}
