﻿using System;
using System.Windows.Forms;
using System.IO.Ports;
using System.Windows.Forms.DataVisualization.Charting;

namespace temperaturedata
{
    public partial class Form4 : Form
    {
        
        private SerialPort myport;
        private string in_data;
        String turb = "";
        String temp = "";
        String pH = "";
        String EC = "";
        String Waterlvl = "";
        float rezultatconv = 0 , rezultatconv1 = 0;  
       
        public Form4()
        {
            InitializeComponent();
            Form3.myport.DataReceived += myport_DataReceived;
            label27.Text = DateTime.Today.ToString("dd-MM-yyyy"); 
        }
        

        private void chart1_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
           // Form3.myport.DataReceived += myport_DataReceived;
        }
       
        void myport_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int i, k = 0, k1 = 0, j = 0, k2 = 0, k3 = 0, k4 = 0, k5 = 0,k6 = 0,k7 = 0;
            temp = "";
            turb = "";
            pH = "";
            EC = "";
            Waterlvl = "";
            in_data = Form3.myport.ReadLine();

            for (i = 0; i < in_data.Length - 1; i++)
            {

                //turb
                if (in_data[i] == '(' && in_data[i + 1] != '(' && in_data[i - 1] != '(')
                {
                    k = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] != ')' && in_data[i - 1] != ')')
                {
                    k1 = i;

                }
                //
                //pH
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(')
                {
                    k2 = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')')
                {
                    k3 = i;

                }
                //
                // EC
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] == '(' && in_data[i + 3] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(' && in_data[i - 3] != '(')
                {
                    k4 = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] == ')' && in_data[i + 3] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')' && in_data[i - 3] != ')')
                {
                    k5 = i;
                   
                }
                if (in_data[i] == '*' && in_data[i + 1] != '*' && in_data[i - 1] != '*')
                {
                    k6 = i;
                }

                if (in_data[i] == '^')
                {
                    k7 = i;

                }
                //

            }

            if (k > 0 && k1 > 0)
            {
                for (j = (k + 1); j < k1 - 1; j++)
                {
                    turb += in_data[j];
                }
            }
            for (j = 0; j < k; j++)
            {
                temp += in_data[j];
            }

            for (j = k2 + 2; j < k3; j++)
            {
                pH += in_data[j];
            }

            for (j = k4 + 3; j < k5; j++)
            {
                EC += in_data[j];
            }

            for (j = k6 + 1; j < k7; j++)
            {
                Waterlvl += in_data[j];
            }

            if (IsHandleCreated)
            {
                if (InvokeRequired)
                Invoke(new EventHandler(displaydata_event));
            }
            else
            {
                // Handle the error case, or do nothing.
            }
            
        }

        private void displaydata_event(object sender, EventArgs e)
        {
            chart1.Series["Temperature"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), temp);
            chart3.Series["Turbidity"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), turb);
            chart4.Series["pH"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), pH);
            chart5.Series["Electrical conductivity"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), EC);

            chart6.Series["Temperature"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), temp);
            chart6.Series["Turbidity"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), turb);
            chart6.Series["pH"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), pH);
            chart6.Series["Electrical conductivity"].Points.AddXY(DateTime.Now.ToString("hh.mm.ss"), EC);

            label39.Text = "Value : " + temp.Trim();
            label40.Text = "Value : " + turb.Trim();
            label20.Text=  turb.Trim();
            label21.Text = pH.Trim();
            label22.Text = temp.Trim();
            label23.Text = EC.Trim();  
            label41.Text = "Value : " + pH.Trim();
            label42.Text = "Value : " + EC.Trim();

            /*if (Convert.ToInt32(label20.Text) >= 7 && Convert.ToInt32(label20.Text) <= 15)
            {
                pictureBox9.Visible = true;
                pictureBox13.Visible = false;
            }
            else
            {
                pictureBox9.Visible = false;
                pictureBox13.Visible = true;
            }

            if (Convert.ToInt32(turb.Trim()) >= 0 && Convert.ToInt32(turb.Trim()) <= 150)
            {
                pictureBox10.Visible = true;
                pictureBox14.Visible = false;
            }
            else
            {
                pictureBox10.Visible =false;
                pictureBox14.Visible = true;
            }

            if (Convert.ToInt32(pH.Trim()) >= 6 && Convert.ToInt32(pH.Trim()) <= 8)
            {
                pictureBox11.Visible = true;
                pictureBox15.Visible = false;
            }
            else
            {
                pictureBox11.Visible = false;
                pictureBox15.Visible = true;
            }

            if (Convert.ToInt32(EC.Trim()) >= 5 && Convert.ToInt32(EC.Trim()) <= 50)
            {
                pictureBox12.Visible = true;
                pictureBox15.Visible = false;
            }
            else
            {
                pictureBox12.Visible = false;
                pictureBox15.Visible = true;
            }*/

        }

        private void button2_Click(object sender, EventArgs e)
        {
           // chart1.ChartAreas[0].AxisY.Maximum = Convert.ToInt32(textBox1.Text);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //chart1.ChartAreas[0].AxisY.Minimum = Convert.ToInt32(textBox2.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisY.Maximum = 50;
            chart1.ChartAreas[0].AxisY.Minimum = 0;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //chart1.ChartAreas[0].AxisX.Maximum = Convert.ToInt32(textBox3.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // chart1.ChartAreas[0].AxisX.Minimum = Convert.ToInt32(textBox4.Text);
        }

        private void Form4_Load(object sender, EventArgs e)
        {
           
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            //myport.DataReceived += myport_DataReceived2;
        }

        
        private void button7_Click(object sender, EventArgs e)
        {
           // Form3.myport.Close();
        }

        private void button17_Click(object sender, EventArgs e)
        {
          //  Form3.myport.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
                chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
            }
            else
            {
                chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox2.Checked)
            {
               chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = true;
            }
            else
            {
                chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = false;
            }
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox3.Checked)
            {
                chart1.ChartAreas[0].AxisY.Minimum = 0;
                checkBox4.Checked = false;
                
            }
            if(checkBox3.Checked!=true  && checkBox4.Checked!=true)
            {
                checkBox3.Checked = true;
                
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        { 
           checkBox3.Checked = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                int temp;
                if( int.TryParse(textBox1.Text, out temp))
                {

                    if (Convert.ToSingle(textBox1.Text) < Convert.ToSingle(textBox2.Text))
                    {
                        chart1.ChartAreas[0].AxisY.Minimum = Convert.ToInt32(textBox1.Text);
                    }
                    else
                    {
                        MessageBox.Show("Y-MIN Value must be lower than Y-MAX!");
                    }
                }
            }
            }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
            {
                chart1.ChartAreas[0].AxisY.Maximum=50;
                checkBox5.Checked = false;

            }
            if (checkBox6.Checked != true && checkBox5.Checked != true)
            {
                checkBox6.Checked = true;

            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                int temp1;
                if (int.TryParse(textBox2.Text, out temp1))
                {

                   chart1.ChartAreas[0].AxisY.Maximum = Convert.ToInt32(textBox2.Text);
                    
                }
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            checkBox6.Checked = false;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            ControlBox = true;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            ControlBox = true;
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void chart4_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void chart6_Click(object sender, EventArgs e)
        {

        }
        //All parameters
        private void button24_Click(object sender, EventArgs e)
        {
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox20.Checked)
            {
                chart3.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
                chart3.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
            }
            else
            {
                chart3.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart3.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
            }
        }

        private void checkBox30_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox30.Checked)
            {
                chart4.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
                chart4.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
            }
            else
            {
                chart4.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart4.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
            }
        }

        private void checkBox40_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox40.Checked)
            {
                chart5.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
                chart5.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
            }
            else
            {
                chart5.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart5.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
            }
        }

        private void checkBox50_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox50.Checked)
            {
                chart6.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = true;
                chart6.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = true;
            }
            else
            {
                chart6.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart6.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
            }
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox19.Checked)
            {
                chart3.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = true;
            }
            else
            {
                chart3.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = false;
            }
        }

        private void checkBox29_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox29.Checked)
            {
                chart4.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = true;
            }
            else
            {
                chart4.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = false;
            }
        }

        private void checkBox39_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox39.Checked)
            {
                chart5.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = true;
            }
            else
            {
                chart5.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = false;
            }
        }

        private void checkBox49_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox49.Checked)
            {
                chart6.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = true;
            }
            else
            {
                chart6.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = false;
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                string folderPath = "D:\\turbidity_chart.png";
                this.chart3.SaveImage(folderPath, ChartImageFormat.Png);
                MessageBox.Show("Image saved !");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            try
            {
                string folderPath = "D:\\pH_chart.png";
                this.chart4.SaveImage(folderPath, ChartImageFormat.Png);
                MessageBox.Show("Image saved !");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                string folderPath = "D:\\ElCond_chart.png";
                this.chart5.SaveImage(folderPath, ChartImageFormat.Png);
                MessageBox.Show("Image saved !");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            try
            {
                string folderPath = "D:\\Allparam_chart.png";
                this.chart6.SaveImage(folderPath, ChartImageFormat.Png);
                MessageBox.Show("Image saved !");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            if (checkBox15.Checked)
            {
                int temp1;
                if (int.TryParse(textBox12.Text, out temp1))
                {

                    chart3.ChartAreas[0].AxisY.Maximum = Convert.ToInt32(textBox12.Text);

                }

            }
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox15.Checked == true)
            checkBox16.Checked = false;
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox16.Checked)
            {
                chart3.ChartAreas[0].AxisY.Maximum = 50;
                checkBox15.Checked = false;
            }
        }

        private void checkBox25_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox25.Checked == true)
                checkBox26.Checked = false;
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox17.Checked == true)
            checkBox18.Checked = false;
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox18.Checked)
            {
                chart3.ChartAreas[0].AxisY.Minimum = 0;
                checkBox17.Checked = false;

            }          
        }

        private void listView8_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
            if (checkBox17.Checked)
            {
                int temp;
                if (int.TryParse(textBox13.Text, out temp))
                {

                    if (Convert.ToSingle(textBox13.Text) < Convert.ToSingle(textBox12.Text))
                    {
                        chart3.ChartAreas[0].AxisY.Minimum = Convert.ToInt32(textBox13.Text);
                    }
                    else
                    {
                        MessageBox.Show("Y-MIN Value must be lower than Y-MAX!");
                    }
                }
            }
        }

        private void checkBox28_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox28.Checked)
            {
                chart4.ChartAreas[0].AxisY.Minimum = 0;
                checkBox27.Checked = false;

            }
        }

        private void checkBox27_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox27.Checked == true)
                checkBox28.Checked = false;
        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {
            if (checkBox27.Checked)
            {
                int temp;
                if (int.TryParse(textBox17.Text, out temp))
                {

                    if (Convert.ToSingle(textBox17.Text) < Convert.ToSingle(textBox16.Text))
                    {
                        chart4.ChartAreas[0].AxisY.Minimum = Convert.ToInt32(textBox17.Text);
                    }
                    else
                    {
                        MessageBox.Show("Y-MIN Value must be lower than Y-MAX!");
                    }
                }
            }
        }

        private void checkBox26_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox26.Checked)
            {
                chart4.ChartAreas[0].AxisY.Maximum = 50;
                checkBox25.Checked = false;
            }
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {
            if (checkBox25.Checked)
            {
                int temp1;
                if (int.TryParse(textBox16.Text, out temp1))
                {

                    chart4.ChartAreas[0].AxisY.Maximum = Convert.ToInt32(textBox16.Text);

                }

            }
        }

        private void checkBox38_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox38.Checked)
            {
                chart5.ChartAreas[0].AxisY.Minimum = 0;
                checkBox37.Checked = false;

            }
        }

        private void checkBox37_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox37.Checked == true)
                checkBox38.Checked = false;
        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {
            if (checkBox37.Checked)
            {
                int temp;
                if (int.TryParse(textBox21.Text, out temp))
                {

                    if (Convert.ToSingle(textBox21.Text) < Convert.ToSingle(textBox20.Text))
                    {
                        chart5.ChartAreas[0].AxisY.Minimum = Convert.ToInt32(textBox21.Text);
                    }
                    else
                    {
                        MessageBox.Show("Y-MIN Value must be lower than Y-MAX!");
                    }
                }
            }
        }

        private void checkBox36_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox36.Checked)
            {
                chart5.ChartAreas[0].AxisY.Maximum = 50;
                checkBox35.Checked = false;
            }
        }

        private void checkBox35_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox35.Checked == true)
                checkBox36.Checked = false;
        }

        private void textBox20_TextChanged(object sender, EventArgs e)
        {
            if (checkBox35.Checked)
            {
                int temp1;
                if (int.TryParse(textBox20.Text, out temp1))
                {

                    chart5.ChartAreas[0].AxisY.Maximum = Convert.ToInt32(textBox20.Text);

                }

            }
        }

        private void checkBox48_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox48.Checked)
            {
                chart6.ChartAreas[0].AxisY.Minimum = 0;
                checkBox47.Checked = false;

            }
        }

        private void checkBox47_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox47.Checked == true)
                checkBox48.Checked = false;
        }

        private void textBox25_TextChanged(object sender, EventArgs e)
        {
            if (checkBox47.Checked)
            {
                int temp;
                if (int.TryParse(textBox25.Text, out temp))
                {

                    if (Convert.ToSingle(textBox25.Text) < Convert.ToSingle(textBox24.Text))
                    {
                        chart6.ChartAreas[0].AxisY.Minimum = Convert.ToInt32(textBox25.Text);
                    }
                    else
                    {
                        MessageBox.Show("Y-MIN Value must be lower than Y-MAX!");
                    }
                }
            }
        }

        private void checkBox46_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox46.Checked)
            {
                chart6.ChartAreas[0].AxisY.Maximum = 50;
                checkBox45.Checked = false;
            }
        }

        private void checkBox45_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox45.Checked == true)
                checkBox46.Checked = false;
        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {
            if (checkBox45.Checked)
            {
                int temp1;
                if (int.TryParse(textBox24.Text, out temp1))
                {

                    chart6.ChartAreas[0].AxisY.Maximum = Convert.ToInt32(textBox24.Text);

                }

            }
        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void listView5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void listView6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void listView7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void chart3_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void label39_Click(object sender, EventArgs e)
        {

        }

        private void listView4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void chart2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void listView20_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void listView18_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void listView16_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void listView11_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void listView9_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView10_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void listView15_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void listView14_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void listView13_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView12_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_2(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox22_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void listView21_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox23_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox24_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void listView22_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void listView23_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void listView24_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chart4_Click_1(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {

        }

        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox31_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox32_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void listView25_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox33_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox34_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label32_Click(object sender, EventArgs e)
        {

        }

        private void listView26_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label33_Click(object sender, EventArgs e)
        {

        }

        private void listView27_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label34_Click(object sender, EventArgs e)
        {

        }

        private void listView28_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chart5_Click(object sender, EventArgs e)
        {

        }

        private void tabPage6_Click(object sender, EventArgs e)
        {

        }

        private void button23_Click(object sender, EventArgs e)
        {

        }

        private void button24_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox41_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox42_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }

        private void listView29_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox43_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox44_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label36_Click(object sender, EventArgs e)
        {

        }

        private void listView30_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label37_Click(object sender, EventArgs e)
        {

        }

        private void listView31_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label38_Click(object sender, EventArgs e)
        {

        }

        private void listView32_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            try
            {
                string folderPath = "D:\\temp_chart.png";
                this.chart1.SaveImage(folderPath, ChartImageFormat.Png); 
                MessageBox.Show("Image saved !");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

       
    }
}
