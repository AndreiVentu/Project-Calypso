﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace temperaturedata
{
    public partial class Form1 : Form
    {
        //private SerialPort port;
        private string in_data;      
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool HideCaret(IntPtr hWnd);

        [DllImport("user32")]
        static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);     

        public Form1()
        {
            InitializeComponent();                  
            var sm = GetSystemMenu(Handle, false);
            label4.Text = "Baud Rate : " + Convert.ToString(Form3.bdrate);
          
        }

        private void start_btn_Click(object sender, EventArgs e)
        {

            Form3.myport.DataReceived+= myport_DataReceived;
            richTextBox1.Text = "";
             
        }

        public async Task Foo()
        {
            await Task.Delay(3000);
        }

        async void myport_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            
            in_data = Form3.myport.ReadLine();
            await Foo();
            if (IsHandleCreated)
            {
                if (InvokeRequired)
                    Invoke(new EventHandler(displaydata_event));
            }
            else
            {
                // Handle the error case, or do nothing.
            }

        }

        private void displaydata_event(object sender, EventArgs e)
        {
            richTextBox1.AppendText(in_data+"\n");        
        }

         public void  stop_brn_Click(object sender, EventArgs e)
         {
            try{
                Form3.myport.Close();
                ControlBox = true;
               }
            catch(Exception ex2){
                MessageBox.Show(ex2.Message, "ERROR");
                                }
         }

        private void save_btn_Click(object sender, EventArgs e)
        {
            try
            {
                string pathfile = @"D:\Andrei";
                string filename = "data.txt";
                System.IO.File.WriteAllText(pathfile + filename, richTextBox1.Text);
                MessageBox.Show("Done!Just go to " + pathfile,"");

            }
            catch(Exception ex3){
                MessageBox.Show(ex3.Message, "ERROR");
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            HideCaret(richTextBox1.Handle);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*int len = this.richTextBox1.TextLength;
            int index = 0;
            int lastIndex = this.richTextBox1.Text.LastIndexOf(this.textBox1.Text);

            while (index < lastIndex)
            {
                this.richTextBox1.Find(this.textBox1.Text, index, len, RichTextBoxFinds.None);
                this.richTextBox1.SelectionBackColor = Color.Blue;
                index = this.richTextBox1.Text.IndexOf(this.textBox1.Text, index) + 1;
            }
            */

            int count = 0;
            int start = 0;
            int endpoz = 0;
            string cuvant = textBox1.Text.Trim();
            int endtext = richTextBox1.Text.Length;
            for(int i = 0; i <= endtext; i = start)
            {
                if(i == -1 )
                {
                    break;
                }
                start = richTextBox1.Find(cuvant, start, endtext, RichTextBoxFinds.WholeWord);
                if(start >= 0)
                {
                    count++;
                    richTextBox1.SelectionBackColor = Color.Yellow;
                    endpoz = textBox1.Text.Length;
                    start = start + endpoz;
                }
            }
            if(count == 0)
            {
                MessageBox.Show("No Match Found!");//daca  nu gaseste un caracter din textbox.text 
            }
                     
        }

        private void richTextBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                richTextBox1.SelectionStart = richTextBox1.Text.Length;
                richTextBox1.ScrollToCaret();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
