﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace temperaturedata
{
    public partial class Form11 : Form
    {
        private object newbal;
        string lines;
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {

        }
        static void lineChanger(string newText, string fileName, int line_to_edit)
        {
            string[] arrLine = File.ReadAllLines(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt");
            arrLine[line_to_edit - 1] = newText;
            File.WriteAllLines(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt", arrLine);
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lineChanger(textBox1.Text, @"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt", 1);
            this.Close();
            MessageBox.Show("E-mail saved!");
        }
    }
}
