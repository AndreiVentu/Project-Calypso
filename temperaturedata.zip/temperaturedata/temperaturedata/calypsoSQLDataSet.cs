﻿namespace temperaturedata
{
}

namespace temperaturedata
{


    public partial class calypsoSQLDataSet
    {
    }
}
