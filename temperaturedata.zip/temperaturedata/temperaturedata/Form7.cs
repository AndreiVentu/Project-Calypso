﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

delegate Color colorg();
namespace temperaturedata
{
    public partial class Form7 : Form
    {
        
        public static Color culoare;
        StreamReader r = new StreamReader(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\security.txt");
        private Timer timer1;

        public Form7()
        {
            InitializeComponent();
            timer1 = new Timer();
            timer1.Tick += new EventHandler(timer1_Tick);
            textBox4.Text = "10";
            timer1.Interval = Convert.ToInt32(textBox4.Text)*1000; // in miliseconds
            timer1.Start();
            //
            string last = "";
            while (r.EndOfStream == false)
            {
                last = r.ReadLine();
            }
            r.Close();
            //

            if (last=="Yes")
            {
                //checkBox3.ForeColor = Color.Red;
                checkBox3.Hide();
                label6.Show();
                label14.Text = "Secured";
                label14.ForeColor = Color.Green;

            }
            else
            {
                //checkBox4.ForeColor = Color.Red;
                checkBox4.Hide();
                label7.Show();
                label14.Text = "Not Secured";
                label14.ForeColor = Color.Red;
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                culoare = Color.Red;
                checkBox2.Checked = false;
                
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
            
            }
        }
        

        private void checkBox3_CheckedChanged_1(object sender, EventArgs e)
        {
            StreamWriter yn = new StreamWriter("security.txt", true);
            yn.WriteLine("Yes");
            yn.Close();
            var fileInfo = new FileInfo(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\password.txt");
            if (!File.Exists("password.txt"))
            {
                File.Create(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\password.txt").Close();
            }

                if (fileInfo.Length == 0)
                {
                    textBox1.Visible  = true;
                    button2.Visible   = true;
                    textBox2.Visible  = true;
                    label10.Visible   = true;
                    label11.Visible   = true;
                    // listView4.Visible = true;
                    // label5.Visible   = true
                }
                else
                {
                    textBox1.Visible  = false;
                    button2.Visible   = false;
                    textBox2.Visible  = false;
                    label10.Visible   = false;
                    label11.Visible   = false;
                    // listView4.Visible = false;
                    // label5.Visible = false;
                }

                if (checkBox3.Checked == true)
                {
                    checkBox4.Checked = false;
                }
           
        }

        private void checkBox4_CheckedChanged_1(object sender, EventArgs e)
        {
            StreamWriter yn = new StreamWriter("security.txt", true);
            yn.WriteLine("No");
            yn.Close();
            if (checkBox4.Checked == true)
            {
               checkBox3.Checked = false;
            }
       
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            StreamWriter yp = new StreamWriter("password.txt", true);
            yp.WriteLine(textBox1.Text);
            MessageBox.Show("Password created!");
            button2.Visible   = false;
            textBox1.Visible  = false;
            textBox2.Visible  = false;
            label10.Visible   = false;
            label11.Visible   = false;
            //listView4.Visible = false;
            yp.Close();
        }

       
       private void textBox1_TextChanged(object sender, EventArgs e)
       {
         /* if(textBox1.Text.Length!=0)
           {
               label5.Visible = false;
           }
           else
           {
               label5.Visible = true;
           }*/
       }

       private void textBox2_TextChanged(object sender, EventArgs e)
       {
          /* if (textBox2.Text.Length > 0)
           {
               label8.Visible = false;
           }
           else
           {
               label8.Visible = true;
           }
           */
       }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Not implemented yet!");
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Not implemented yet!");
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        string[] array = new string[] { "Close Settings Form", "Close settings form", "CLOSE SETTINGS FORM", "close settings form" };
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
          
            if(array.Any(textBox3.Text.Equals))
            {
                Close();
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void listView5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fileInfo = new FileInfo(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\password.txt");
            if (fileInfo.Length != 0)
            {
                textBox1.Visible = true;
                button2.Visible = true;
                textBox2.Visible = true;
                label10.Visible = true;
                label11.Visible = true;
            }
        }

        private void checkBox10_CheckedChanged_1(object sender, EventArgs e)
        {
            if(checkBox10.Checked == true)
            {
                checkBox11.Checked = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (checkBox10.Checked == true)
            {
                string line1;
                using (StreamReader reader = new StreamReader(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt"))
                {
                    line1 = reader.ReadLine();
                }

                using (MailMessage mail = new MailMessage())
                {
                    mail.From = new MailAddress("AtlasTeamCL@gmail.com");
                    mail.To.Add(line1);
                    mail.Subject = "Hello World";
                    mail.Body = "Daily data";
                    // mail.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("AtlasTeamCL@gmail.com", "calypsovs");
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                    //MessageBox.Show("E-mail sent!");

                }
            }
            else
            {
                //do something
            }
        }

        private void checkBox11_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox11.Checked == true)
            {
                checkBox10.Checked = false;
            }
        }

        private void checkBox2_CheckedChanged_1(object sender, EventArgs e)
        {
            if(checkBox2.Checked == true)
            {
                checkBox1.Checked = false;
            }
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                checkBox2.Checked = false;
            }        
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void checkBox9_CheckedChanged_1(object sender, EventArgs e)
        {
            if(checkBox9.Checked == true)
            {
                checkBox6.Checked = false;
            }
        }

        private void checkBox6_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                checkBox9.Checked = false;
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }
    }
}
