﻿using System;

namespace temperaturedata
{
    partial class New
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea31 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend31 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series49 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea32 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend32 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series50 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea33 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend33 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series51 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea34 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend34 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series52 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea35 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend35 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series53 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series54 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series55 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series56 = new System.Windows.Forms.DataVisualization.Charting.Series();
            BunifuAnimatorNS.Animation animation14 = new BunifuAnimatorNS.Animation();
            BunifuAnimatorNS.Animation animation13 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(New));
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton10 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuFlatButton9 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton8 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton5 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl3 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Home = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.gMapControl2 = new GMap.NET.WindowsForms.GMapControl();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.bunifuCircleProgressbar6 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuCircleProgressbar5 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuCircleProgressbar4 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuCircleProgressbar3 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton28 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuFlatButton14 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton13 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton7 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton6 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.bunifuFlatButton15 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCircleProgressbar2 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.bunifuCircleProgressbar8 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuCircleProgressbar7 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuCircleProgressbar9 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuCircleProgressbar10 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.bunifuCircleProgressbar1 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.bunifuFlatButton11 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton12 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Serial_Monitor = new System.Windows.Forms.TabPage();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuImageButton6 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuCheckbox21 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuTextbox1 = new Bunifu.Framework.UI.BunifuTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Charts = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.bunifuFlatButton26 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton21 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton22 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton19 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton18 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton17 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton16 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSwitch2 = new Bunifu.Framework.UI.BunifuSwitch();
            this.bunifuSwitch1 = new Bunifu.Framework.UI.BunifuSwitch();
            this.panel12 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCircleProgressbar11 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.panel11 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCircleProgressbar12 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.panel10 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCircleProgressbar13 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.panel9 = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCircleProgressbar14 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.bunifuCheckbox4 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox3 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox2 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox1 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuTextbox3 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuTextbox2 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel14 = new System.Windows.Forms.Panel();
            this.bunifuSwitch3 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label11 = new System.Windows.Forms.Label();
            this.bunifuSwitch4 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label10 = new System.Windows.Forms.Label();
            this.bunifuFlatButton20 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.bunifuFlatButton23 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.bunifuCheckbox5 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox6 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox7 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox8 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuTextbox4 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuTextbox5 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel19 = new System.Windows.Forms.Panel();
            this.bunifuSwitch5 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label21 = new System.Windows.Forms.Label();
            this.bunifuSwitch6 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label22 = new System.Windows.Forms.Label();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.bunifuFlatButton24 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.bunifuCheckbox9 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox10 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox11 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox12 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuTextbox6 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuTextbox7 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel22 = new System.Windows.Forms.Panel();
            this.bunifuSwitch7 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label28 = new System.Windows.Forms.Label();
            this.bunifuSwitch8 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label29 = new System.Windows.Forms.Label();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.bunifuFlatButton25 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.bunifuCheckbox13 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox14 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox15 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox16 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuTextbox8 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuTextbox9 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuImageButton4 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel25 = new System.Windows.Forms.Panel();
            this.bunifuSwitch9 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label35 = new System.Windows.Forms.Label();
            this.bunifuSwitch10 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label36 = new System.Windows.Forms.Label();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.bunifuFlatButton27 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.bunifuCheckbox17 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox18 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox19 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCheckbox20 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuTextbox10 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuTextbox11 = new Bunifu.Framework.UI.BunifuTextbox();
            this.bunifuImageButton5 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel28 = new System.Windows.Forms.Panel();
            this.bunifuSwitch11 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label42 = new System.Windows.Forms.Label();
            this.bunifuSwitch12 = new Bunifu.Framework.UI.BunifuSwitch();
            this.label43 = new System.Windows.Forms.Label();
            this.chart5 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Maps = new System.Windows.Forms.TabPage();
            this.gMapControl1 = new GMap.NET.WindowsForms.GMapControl();
            this.Database = new System.Windows.Forms.TabPage();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Settings = new System.Windows.Forms.TabPage();
            this.panel34 = new System.Windows.Forms.Panel();
            this.bunifuThinButton23 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.bunifuCircleProgressbar15 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.bunifuTileButton4 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton3 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton2 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton1 = new Bunifu.Framework.UI.BunifuTileButton();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.About = new System.Windows.Forms.TabPage();
            this.panel29 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuDragControl4 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.bunifuDragControl6 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuTransition1 = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.bunifuTransition2 = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.bunifuDragControl7 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl8 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl9 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl10 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl11 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl12 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl5 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.Home.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Serial_Monitor.SuspendLayout();
            this.panel30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).BeginInit();
            this.Charts.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).BeginInit();
            this.panel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).BeginInit();
            this.panel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).BeginInit();
            this.Maps.SuspendLayout();
            this.Database.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Settings.SuspendLayout();
            this.panel34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel33.SuspendLayout();
            this.panel35.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.About.SuspendLayout();
            this.panel29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.panel2.Controls.Add(this.bunifuFlatButton10);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.bunifuFlatButton9);
            this.panel2.Controls.Add(this.bunifuFlatButton8);
            this.panel2.Controls.Add(this.bunifuFlatButton5);
            this.panel2.Controls.Add(this.bunifuFlatButton4);
            this.panel2.Controls.Add(this.bunifuFlatButton3);
            this.panel2.Controls.Add(this.bunifuFlatButton2);
            this.panel2.Controls.Add(this.bunifuFlatButton1);
            this.bunifuTransition2.SetDecoration(this.panel2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel2, BunifuAnimatorNS.DecorationType.None);
            this.panel2.Location = new System.Drawing.Point(0, -4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(227, 721);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // bunifuFlatButton10
            // 
            this.bunifuFlatButton10.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuFlatButton10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton10.BorderRadius = 0;
            this.bunifuFlatButton10.ButtonText = "bunifuFlatButton10";
            this.bunifuFlatButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton10.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton10.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton10.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton10.Iconimage")));
            this.bunifuFlatButton10.Iconimage_right = null;
            this.bunifuFlatButton10.Iconimage_right_Selected = null;
            this.bunifuFlatButton10.Iconimage_Selected = null;
            this.bunifuFlatButton10.IconMarginLeft = 0;
            this.bunifuFlatButton10.IconMarginRight = 0;
            this.bunifuFlatButton10.IconRightVisible = true;
            this.bunifuFlatButton10.IconRightZoom = 0D;
            this.bunifuFlatButton10.IconVisible = true;
            this.bunifuFlatButton10.IconZoom = 50D;
            this.bunifuFlatButton10.IsTab = false;
            this.bunifuFlatButton10.Location = new System.Drawing.Point(185, 21);
            this.bunifuFlatButton10.Name = "bunifuFlatButton10";
            this.bunifuFlatButton10.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton10.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton10.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton10.selected = false;
            this.bunifuFlatButton10.Size = new System.Drawing.Size(30, 30);
            this.bunifuFlatButton10.TabIndex = 3;
            this.bunifuFlatButton10.Text = "bunifuFlatButton10";
            this.bunifuFlatButton10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton10.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton10.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton10.Click += new System.EventHandler(this.bunifuFlatButton10_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.bunifuTransition1.SetDecoration(this.pictureBox1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.pictureBox1, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox1.Location = new System.Drawing.Point(57, 56);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 106);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // bunifuFlatButton9
            // 
            this.bunifuFlatButton9.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton9.BorderRadius = 0;
            this.bunifuFlatButton9.ButtonText = "   About";
            this.bunifuFlatButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton9.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton9.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton9.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton9.Iconimage")));
            this.bunifuFlatButton9.Iconimage_right = null;
            this.bunifuFlatButton9.Iconimage_right_Selected = null;
            this.bunifuFlatButton9.Iconimage_Selected = null;
            this.bunifuFlatButton9.IconMarginLeft = 0;
            this.bunifuFlatButton9.IconMarginRight = 0;
            this.bunifuFlatButton9.IconRightVisible = true;
            this.bunifuFlatButton9.IconRightZoom = 0D;
            this.bunifuFlatButton9.IconVisible = true;
            this.bunifuFlatButton9.IconZoom = 55D;
            this.bunifuFlatButton9.IsTab = true;
            this.bunifuFlatButton9.Location = new System.Drawing.Point(0, 593);
            this.bunifuFlatButton9.Name = "bunifuFlatButton9";
            this.bunifuFlatButton9.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton9.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton9.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton9.selected = false;
            this.bunifuFlatButton9.Size = new System.Drawing.Size(228, 56);
            this.bunifuFlatButton9.TabIndex = 7;
            this.bunifuFlatButton9.Text = "   About";
            this.bunifuFlatButton9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton9.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton9.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton9.Click += new System.EventHandler(this.bunifuFlatButton9_Click);
            // 
            // bunifuFlatButton8
            // 
            this.bunifuFlatButton8.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton8.BorderRadius = 0;
            this.bunifuFlatButton8.ButtonText = "   Settings";
            this.bunifuFlatButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton8.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton8.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton8.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton8.Iconimage")));
            this.bunifuFlatButton8.Iconimage_right = null;
            this.bunifuFlatButton8.Iconimage_right_Selected = null;
            this.bunifuFlatButton8.Iconimage_Selected = null;
            this.bunifuFlatButton8.IconMarginLeft = 0;
            this.bunifuFlatButton8.IconMarginRight = 0;
            this.bunifuFlatButton8.IconRightVisible = true;
            this.bunifuFlatButton8.IconRightZoom = 0D;
            this.bunifuFlatButton8.IconVisible = true;
            this.bunifuFlatButton8.IconZoom = 55D;
            this.bunifuFlatButton8.IsTab = true;
            this.bunifuFlatButton8.Location = new System.Drawing.Point(0, 538);
            this.bunifuFlatButton8.Name = "bunifuFlatButton8";
            this.bunifuFlatButton8.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton8.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton8.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton8.selected = false;
            this.bunifuFlatButton8.Size = new System.Drawing.Size(228, 56);
            this.bunifuFlatButton8.TabIndex = 6;
            this.bunifuFlatButton8.Text = "   Settings";
            this.bunifuFlatButton8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton8.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton8.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton8.Click += new System.EventHandler(this.bunifuFlatButton8_Click);
            // 
            // bunifuFlatButton5
            // 
            this.bunifuFlatButton5.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton5.BorderRadius = 0;
            this.bunifuFlatButton5.ButtonText = "   Database";
            this.bunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton5.Iconimage")));
            this.bunifuFlatButton5.Iconimage_right = null;
            this.bunifuFlatButton5.Iconimage_right_Selected = null;
            this.bunifuFlatButton5.Iconimage_Selected = null;
            this.bunifuFlatButton5.IconMarginLeft = 0;
            this.bunifuFlatButton5.IconMarginRight = 0;
            this.bunifuFlatButton5.IconRightVisible = true;
            this.bunifuFlatButton5.IconRightZoom = 0D;
            this.bunifuFlatButton5.IconVisible = true;
            this.bunifuFlatButton5.IconZoom = 55D;
            this.bunifuFlatButton5.IsTab = true;
            this.bunifuFlatButton5.Location = new System.Drawing.Point(0, 483);
            this.bunifuFlatButton5.Name = "bunifuFlatButton5";
            this.bunifuFlatButton5.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton5.selected = false;
            this.bunifuFlatButton5.Size = new System.Drawing.Size(228, 56);
            this.bunifuFlatButton5.TabIndex = 5;
            this.bunifuFlatButton5.Text = "   Database";
            this.bunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton5.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton5.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton5.Click += new System.EventHandler(this.bunifuFlatButton5_Click);
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 0;
            this.bunifuFlatButton4.ButtonText = "   Maps";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton4.Iconimage")));
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 55D;
            this.bunifuFlatButton4.IsTab = true;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(0, 428);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(228, 56);
            this.bunifuFlatButton4.TabIndex = 4;
            this.bunifuFlatButton4.Text = "   Maps";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton4.Click += new System.EventHandler(this.bunifuFlatButton4_Click);
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "   Charts";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton3.Iconimage")));
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 55D;
            this.bunifuFlatButton3.IsTab = true;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(0, 373);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(228, 56);
            this.bunifuFlatButton3.TabIndex = 3;
            this.bunifuFlatButton3.Text = "   Charts";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton3.Click += new System.EventHandler(this.bunifuFlatButton3_Click);
            // 
            // bunifuFlatButton2
            // 
            this.bunifuFlatButton2.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton2.BorderRadius = 0;
            this.bunifuFlatButton2.ButtonText = "   Serial Monitor";
            this.bunifuFlatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton2.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton2.Iconimage")));
            this.bunifuFlatButton2.Iconimage_right = null;
            this.bunifuFlatButton2.Iconimage_right_Selected = null;
            this.bunifuFlatButton2.Iconimage_Selected = null;
            this.bunifuFlatButton2.IconMarginLeft = 0;
            this.bunifuFlatButton2.IconMarginRight = 0;
            this.bunifuFlatButton2.IconRightVisible = true;
            this.bunifuFlatButton2.IconRightZoom = 0D;
            this.bunifuFlatButton2.IconVisible = true;
            this.bunifuFlatButton2.IconZoom = 55D;
            this.bunifuFlatButton2.IsTab = true;
            this.bunifuFlatButton2.Location = new System.Drawing.Point(1, 318);
            this.bunifuFlatButton2.Name = "bunifuFlatButton2";
            this.bunifuFlatButton2.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton2.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton2.selected = false;
            this.bunifuFlatButton2.Size = new System.Drawing.Size(227, 56);
            this.bunifuFlatButton2.TabIndex = 2;
            this.bunifuFlatButton2.Text = "   Serial Monitor";
            this.bunifuFlatButton2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton2.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton2.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "   Home";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 55D;
            this.bunifuFlatButton1.IsTab = true;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(1, 263);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(227, 56);
            this.bunifuFlatButton1.TabIndex = 1;
            this.bunifuFlatButton1.Text = "   Home";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this;
            this.bunifuDragControl2.Vertical = true;
            // 
            // bunifuDragControl3
            // 
            this.bunifuDragControl3.Fixed = true;
            this.bunifuDragControl3.Horizontal = true;
            this.bunifuDragControl3.TargetControl = this.panel2;
            this.bunifuDragControl3.Vertical = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Home);
            this.tabControl1.Controls.Add(this.Serial_Monitor);
            this.tabControl1.Controls.Add(this.Charts);
            this.tabControl1.Controls.Add(this.Maps);
            this.tabControl1.Controls.Add(this.Database);
            this.tabControl1.Controls.Add(this.Settings);
            this.tabControl1.Controls.Add(this.About);
            this.bunifuTransition2.SetDecoration(this.tabControl1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabControl1, BunifuAnimatorNS.DecorationType.None);
            this.tabControl1.Location = new System.Drawing.Point(211, -22);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(971, 760);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.SystemColors.Control;
            this.Home.Controls.Add(this.panel6);
            this.Home.Controls.Add(this.panel7);
            this.Home.Controls.Add(this.panel8);
            this.Home.Controls.Add(this.panel5);
            this.Home.Controls.Add(this.panel4);
            this.Home.Controls.Add(this.panel3);
            this.Home.Controls.Add(this.bunifuFlatButton11);
            this.Home.Controls.Add(this.bunifuFlatButton12);
            this.bunifuTransition2.SetDecoration(this.Home, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.Home, BunifuAnimatorNS.DecorationType.None);
            this.Home.Location = new System.Drawing.Point(4, 22);
            this.Home.Name = "Home";
            this.Home.Padding = new System.Windows.Forms.Padding(3);
            this.Home.Size = new System.Drawing.Size(963, 734);
            this.Home.TabIndex = 1;
            this.Home.Text = "Home";
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.gMapControl2);
            this.bunifuTransition2.SetDecoration(this.panel6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel6, BunifuAnimatorNS.DecorationType.None);
            this.panel6.Location = new System.Drawing.Point(648, 396);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(280, 255);
            this.panel6.TabIndex = 12;
            // 
            // gMapControl2
            // 
            this.gMapControl2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.gMapControl2.Bearing = 0F;
            this.gMapControl2.CanDragMap = true;
            this.bunifuTransition2.SetDecoration(this.gMapControl2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.gMapControl2, BunifuAnimatorNS.DecorationType.None);
            this.gMapControl2.EmptyTileColor = System.Drawing.Color.Navy;
            this.gMapControl2.GrayScaleMode = false;
            this.gMapControl2.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gMapControl2.LevelsKeepInMemmory = 5;
            this.gMapControl2.Location = new System.Drawing.Point(0, 0);
            this.gMapControl2.MarkersEnabled = true;
            this.gMapControl2.MaxZoom = 2;
            this.gMapControl2.MinZoom = 2;
            this.gMapControl2.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gMapControl2.Name = "gMapControl2";
            this.gMapControl2.NegativeMode = false;
            this.gMapControl2.PolygonsEnabled = true;
            this.gMapControl2.RetryLoadTile = 0;
            this.gMapControl2.RoutesEnabled = true;
            this.gMapControl2.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gMapControl2.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gMapControl2.ShowTileGridLines = false;
            this.gMapControl2.Size = new System.Drawing.Size(280, 255);
            this.gMapControl2.TabIndex = 2;
            this.gMapControl2.Zoom = 0D;
            this.gMapControl2.Load += new System.EventHandler(this.gMapControl2_Load);
            // 
            // panel7
            // 
            this.panel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.panel7.Controls.Add(this.label60);
            this.panel7.Controls.Add(this.label59);
            this.panel7.Controls.Add(this.label58);
            this.panel7.Controls.Add(this.label57);
            this.panel7.Controls.Add(this.label56);
            this.panel7.Controls.Add(this.label55);
            this.panel7.Controls.Add(this.label54);
            this.panel7.Controls.Add(this.label53);
            this.panel7.Controls.Add(this.label48);
            this.panel7.Controls.Add(this.bunifuCircleProgressbar6);
            this.panel7.Controls.Add(this.bunifuCircleProgressbar5);
            this.panel7.Controls.Add(this.bunifuCircleProgressbar4);
            this.panel7.Controls.Add(this.bunifuCircleProgressbar3);
            this.bunifuTransition2.SetDecoration(this.panel7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel7, BunifuAnimatorNS.DecorationType.None);
            this.panel7.Location = new System.Drawing.Point(345, 396);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(280, 255);
            this.panel7.TabIndex = 11;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label60, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label60, BunifuAnimatorNS.DecorationType.None);
            this.label60.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label60.Location = new System.Drawing.Point(198, 180);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(15, 18);
            this.label60.TabIndex = 22;
            this.label60.Text = "-";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label59, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label59, BunifuAnimatorNS.DecorationType.None);
            this.label59.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label59.Location = new System.Drawing.Point(203, 57);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(15, 18);
            this.label59.TabIndex = 21;
            this.label59.Text = "-";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label58, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label58, BunifuAnimatorNS.DecorationType.None);
            this.label58.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label58.Location = new System.Drawing.Point(48, 180);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(15, 18);
            this.label58.TabIndex = 20;
            this.label58.Text = "-";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label57, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label57, BunifuAnimatorNS.DecorationType.None);
            this.label57.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label57.Location = new System.Drawing.Point(54, 57);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(15, 18);
            this.label57.TabIndex = 19;
            this.label57.Text = "-";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label56, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label56, BunifuAnimatorNS.DecorationType.None);
            this.label56.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.DarkGray;
            this.label56.Location = new System.Drawing.Point(201, 206);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(35, 18);
            this.label56.TabIndex = 18;
            this.label56.Text = "el. ";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label55, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label55, BunifuAnimatorNS.DecorationType.None);
            this.label55.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.DarkGray;
            this.label55.Location = new System.Drawing.Point(198, 81);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(30, 18);
            this.label55.TabIndex = 17;
            this.label55.Text = "pH";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label54, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label54, BunifuAnimatorNS.DecorationType.None);
            this.label54.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.DarkGray;
            this.label54.Location = new System.Drawing.Point(48, 206);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(42, 18);
            this.label54.TabIndex = 16;
            this.label54.Text = "Turb";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label53, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label53, BunifuAnimatorNS.DecorationType.None);
            this.label53.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.DarkGray;
            this.label53.Location = new System.Drawing.Point(44, 82);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(51, 18);
            this.label53.TabIndex = 15;
            this.label53.Text = "Temp";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label48, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label48, BunifuAnimatorNS.DecorationType.None);
            this.label48.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.DarkGray;
            this.label48.Location = new System.Drawing.Point(106, 111);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(72, 36);
            this.label48.TabIndex = 2;
            this.label48.Text = "Sensors\r\n values";
            // 
            // bunifuCircleProgressbar6
            // 
            this.bunifuCircleProgressbar6.animated = false;
            this.bunifuCircleProgressbar6.animationIterval = 1;
            this.bunifuCircleProgressbar6.animationSpeed = 50;
            this.bunifuCircleProgressbar6.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar6.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar6.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.bunifuCircleProgressbar6.LabelVisible = false;
            this.bunifuCircleProgressbar6.LineProgressThickness = 5;
            this.bunifuCircleProgressbar6.LineThickness = 4;
            this.bunifuCircleProgressbar6.Location = new System.Drawing.Point(154, 130);
            this.bunifuCircleProgressbar6.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar6.MaxValue = 100;
            this.bunifuCircleProgressbar6.Name = "bunifuCircleProgressbar6";
            this.bunifuCircleProgressbar6.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar6.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.bunifuCircleProgressbar6.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar6.TabIndex = 8;
            this.bunifuCircleProgressbar6.Value = 0;
            // 
            // bunifuCircleProgressbar5
            // 
            this.bunifuCircleProgressbar5.animated = false;
            this.bunifuCircleProgressbar5.animationIterval = 1;
            this.bunifuCircleProgressbar5.animationSpeed = 50;
            this.bunifuCircleProgressbar5.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar5.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar5.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar5.ForeColor = System.Drawing.Color.RoyalBlue;
            this.bunifuCircleProgressbar5.LabelVisible = false;
            this.bunifuCircleProgressbar5.LineProgressThickness = 5;
            this.bunifuCircleProgressbar5.LineThickness = 4;
            this.bunifuCircleProgressbar5.Location = new System.Drawing.Point(154, 9);
            this.bunifuCircleProgressbar5.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar5.MaxValue = 150;
            this.bunifuCircleProgressbar5.Name = "bunifuCircleProgressbar5";
            this.bunifuCircleProgressbar5.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar5.ProgressColor = System.Drawing.Color.RoyalBlue;
            this.bunifuCircleProgressbar5.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar5.TabIndex = 7;
            this.bunifuCircleProgressbar5.Value = 0;
            // 
            // bunifuCircleProgressbar4
            // 
            this.bunifuCircleProgressbar4.animated = false;
            this.bunifuCircleProgressbar4.animationIterval = 1;
            this.bunifuCircleProgressbar4.animationSpeed = 50;
            this.bunifuCircleProgressbar4.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar4.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar4.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar4.LabelVisible = false;
            this.bunifuCircleProgressbar4.LineProgressThickness = 5;
            this.bunifuCircleProgressbar4.LineThickness = 4;
            this.bunifuCircleProgressbar4.Location = new System.Drawing.Point(10, 130);
            this.bunifuCircleProgressbar4.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar4.MaxValue = 160;
            this.bunifuCircleProgressbar4.Name = "bunifuCircleProgressbar4";
            this.bunifuCircleProgressbar4.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar4.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar4.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar4.TabIndex = 6;
            this.bunifuCircleProgressbar4.Value = 0;
            // 
            // bunifuCircleProgressbar3
            // 
            this.bunifuCircleProgressbar3.animated = false;
            this.bunifuCircleProgressbar3.animationIterval = 1;
            this.bunifuCircleProgressbar3.animationSpeed = 50;
            this.bunifuCircleProgressbar3.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar3.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar3.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar3.LabelVisible = false;
            this.bunifuCircleProgressbar3.LineProgressThickness = 5;
            this.bunifuCircleProgressbar3.LineThickness = 4;
            this.bunifuCircleProgressbar3.Location = new System.Drawing.Point(10, 9);
            this.bunifuCircleProgressbar3.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar3.MaxValue = 30;
            this.bunifuCircleProgressbar3.Name = "bunifuCircleProgressbar3";
            this.bunifuCircleProgressbar3.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar3.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar3.TabIndex = 5;
            this.bunifuCircleProgressbar3.Value = 0;
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.panel8.Controls.Add(this.panel32);
            this.panel8.Controls.Add(this.bunifuFlatButton28);
            this.panel8.Controls.Add(this.bunifuCustomLabel2);
            this.panel8.Controls.Add(this.bunifuCustomLabel4);
            this.panel8.Controls.Add(this.bunifuCustomLabel3);
            this.panel8.Controls.Add(this.bunifuCustomLabel1);
            this.panel8.Controls.Add(this.bunifuFlatButton14);
            this.panel8.Controls.Add(this.bunifuFlatButton13);
            this.panel8.Controls.Add(this.bunifuFlatButton7);
            this.panel8.Controls.Add(this.bunifuFlatButton6);
            this.bunifuTransition2.SetDecoration(this.panel8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel8, BunifuAnimatorNS.DecorationType.None);
            this.panel8.Location = new System.Drawing.Point(36, 396);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(280, 255);
            this.panel8.TabIndex = 10;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuTransition2.SetDecoration(this.panel32, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel32, BunifuAnimatorNS.DecorationType.None);
            this.panel32.Location = new System.Drawing.Point(0, 3);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(280, 10);
            this.panel32.TabIndex = 10;
            this.panel32.Visible = false;
            this.panel32.Paint += new System.Windows.Forms.PaintEventHandler(this.panel32_Paint);
            // 
            // bunifuFlatButton28
            // 
            this.bunifuFlatButton28.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton28.BorderRadius = 0;
            this.bunifuFlatButton28.ButtonText = "                   Back";
            this.bunifuFlatButton28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton28, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton28, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton28.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton28.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bunifuFlatButton28.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton28.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton28.Iconimage")));
            this.bunifuFlatButton28.Iconimage_right = null;
            this.bunifuFlatButton28.Iconimage_right_Selected = null;
            this.bunifuFlatButton28.Iconimage_Selected = null;
            this.bunifuFlatButton28.IconMarginLeft = 0;
            this.bunifuFlatButton28.IconMarginRight = 0;
            this.bunifuFlatButton28.IconRightVisible = false;
            this.bunifuFlatButton28.IconRightZoom = 0D;
            this.bunifuFlatButton28.IconVisible = false;
            this.bunifuFlatButton28.IconZoom = 90D;
            this.bunifuFlatButton28.IsTab = false;
            this.bunifuFlatButton28.Location = new System.Drawing.Point(0, 210);
            this.bunifuFlatButton28.Name = "bunifuFlatButton28";
            this.bunifuFlatButton28.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton28.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton28.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton28.selected = false;
            this.bunifuFlatButton28.Size = new System.Drawing.Size(280, 45);
            this.bunifuFlatButton28.TabIndex = 10;
            this.bunifuFlatButton28.Text = "                   Back";
            this.bunifuFlatButton28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton28.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton28.TextFont = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton28.Visible = false;
            this.bunifuFlatButton28.Click += new System.EventHandler(this.bunifuFlatButton28_Click);
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(97, 197);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(179, 23);
            this.bunifuCustomLabel2.TabIndex = 9;
            this.bunifuCustomLabel2.Text = "Spanel connected";
            this.bunifuCustomLabel2.Click += new System.EventHandler(this.bunifuCustomLabel2_Click);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(100, 89);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(177, 23);
            this.bunifuCustomLabel4.TabIndex = 8;
            this.bunifuCustomLabel4.Text = "System protected";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(105, 141);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(171, 23);
            this.bunifuCustomLabel3.TabIndex = 7;
            this.bunifuCustomLabel3.Text = "Device protected";
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(225, 35);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(19, 23);
            this.bunifuCustomLabel1.TabIndex = 5;
            this.bunifuCustomLabel1.Text = "-";
            // 
            // bunifuFlatButton14
            // 
            this.bunifuFlatButton14.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton14.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton14.BorderRadius = 0;
            this.bunifuFlatButton14.ButtonText = "";
            this.bunifuFlatButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton14.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton14.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton14.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton14.Iconimage")));
            this.bunifuFlatButton14.Iconimage_right = null;
            this.bunifuFlatButton14.Iconimage_right_Selected = null;
            this.bunifuFlatButton14.Iconimage_Selected = null;
            this.bunifuFlatButton14.IconMarginLeft = 0;
            this.bunifuFlatButton14.IconMarginRight = 0;
            this.bunifuFlatButton14.IconRightVisible = false;
            this.bunifuFlatButton14.IconRightZoom = 0D;
            this.bunifuFlatButton14.IconVisible = false;
            this.bunifuFlatButton14.IconZoom = 60D;
            this.bunifuFlatButton14.IsTab = false;
            this.bunifuFlatButton14.Location = new System.Drawing.Point(25, 184);
            this.bunifuFlatButton14.Name = "bunifuFlatButton14";
            this.bunifuFlatButton14.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton14.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton14.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton14.selected = false;
            this.bunifuFlatButton14.Size = new System.Drawing.Size(49, 48);
            this.bunifuFlatButton14.TabIndex = 3;
            this.bunifuFlatButton14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton14.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton14.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton14.Click += new System.EventHandler(this.bunifuFlatButton14_Click_1);
            // 
            // bunifuFlatButton13
            // 
            this.bunifuFlatButton13.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton13.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton13.BorderRadius = 0;
            this.bunifuFlatButton13.ButtonText = "";
            this.bunifuFlatButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton13.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton13.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton13.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton13.Iconimage")));
            this.bunifuFlatButton13.Iconimage_right = null;
            this.bunifuFlatButton13.Iconimage_right_Selected = null;
            this.bunifuFlatButton13.Iconimage_Selected = null;
            this.bunifuFlatButton13.IconMarginLeft = 0;
            this.bunifuFlatButton13.IconMarginRight = 0;
            this.bunifuFlatButton13.IconRightVisible = false;
            this.bunifuFlatButton13.IconRightZoom = 0D;
            this.bunifuFlatButton13.IconVisible = false;
            this.bunifuFlatButton13.IconZoom = 60D;
            this.bunifuFlatButton13.IsTab = false;
            this.bunifuFlatButton13.Location = new System.Drawing.Point(25, 130);
            this.bunifuFlatButton13.Name = "bunifuFlatButton13";
            this.bunifuFlatButton13.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton13.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton13.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton13.selected = false;
            this.bunifuFlatButton13.Size = new System.Drawing.Size(49, 48);
            this.bunifuFlatButton13.TabIndex = 2;
            this.bunifuFlatButton13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton13.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton13.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton13.Click += new System.EventHandler(this.bunifuFlatButton13_Click_1);
            // 
            // bunifuFlatButton7
            // 
            this.bunifuFlatButton7.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton7.BorderRadius = 0;
            this.bunifuFlatButton7.ButtonText = "";
            this.bunifuFlatButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton7.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton7.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton7.Iconimage")));
            this.bunifuFlatButton7.Iconimage_right = null;
            this.bunifuFlatButton7.Iconimage_right_Selected = null;
            this.bunifuFlatButton7.Iconimage_Selected = null;
            this.bunifuFlatButton7.IconMarginLeft = 0;
            this.bunifuFlatButton7.IconMarginRight = 0;
            this.bunifuFlatButton7.IconRightVisible = false;
            this.bunifuFlatButton7.IconRightZoom = 0D;
            this.bunifuFlatButton7.IconVisible = false;
            this.bunifuFlatButton7.IconZoom = 60D;
            this.bunifuFlatButton7.IsTab = false;
            this.bunifuFlatButton7.Location = new System.Drawing.Point(25, 76);
            this.bunifuFlatButton7.Name = "bunifuFlatButton7";
            this.bunifuFlatButton7.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton7.selected = false;
            this.bunifuFlatButton7.Size = new System.Drawing.Size(49, 48);
            this.bunifuFlatButton7.TabIndex = 1;
            this.bunifuFlatButton7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton7.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton7.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton7.Click += new System.EventHandler(this.bunifuFlatButton7_Click_2);
            // 
            // bunifuFlatButton6
            // 
            this.bunifuFlatButton6.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton6.BorderRadius = 0;
            this.bunifuFlatButton6.ButtonText = "";
            this.bunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton6.Iconimage")));
            this.bunifuFlatButton6.Iconimage_right = null;
            this.bunifuFlatButton6.Iconimage_right_Selected = null;
            this.bunifuFlatButton6.Iconimage_Selected = null;
            this.bunifuFlatButton6.IconMarginLeft = 0;
            this.bunifuFlatButton6.IconMarginRight = 0;
            this.bunifuFlatButton6.IconRightVisible = false;
            this.bunifuFlatButton6.IconRightZoom = 0D;
            this.bunifuFlatButton6.IconVisible = false;
            this.bunifuFlatButton6.IconZoom = 60D;
            this.bunifuFlatButton6.IsTab = false;
            this.bunifuFlatButton6.Location = new System.Drawing.Point(25, 22);
            this.bunifuFlatButton6.Name = "bunifuFlatButton6";
            this.bunifuFlatButton6.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton6.selected = false;
            this.bunifuFlatButton6.Size = new System.Drawing.Size(49, 48);
            this.bunifuFlatButton6.TabIndex = 0;
            this.bunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton6.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton6.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton6.Click += new System.EventHandler(this.bunifuFlatButton6_Click);
            this.bunifuFlatButton6.MouseHover += new System.EventHandler(this.bunifuFlatButton6_MouseHover);
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel5.BackColor = System.Drawing.Color.Gainsboro;
            this.panel5.Controls.Add(this.label50);
            this.panel5.Controls.Add(this.label47);
            this.panel5.Controls.Add(this.bunifuFlatButton15);
            this.panel5.Controls.Add(this.bunifuCircleProgressbar2);
            this.bunifuTransition2.SetDecoration(this.panel5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel5, BunifuAnimatorNS.DecorationType.None);
            this.panel5.Location = new System.Drawing.Point(648, 77);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(280, 255);
            this.panel5.TabIndex = 9;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label50, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label50, BunifuAnimatorNS.DecorationType.None);
            this.label50.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.DarkGray;
            this.label50.Location = new System.Drawing.Point(20, 22);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(99, 18);
            this.label50.TabIndex = 14;
            this.label50.Text = "Connection";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label47, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label47, BunifuAnimatorNS.DecorationType.None);
            this.label47.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label47.Location = new System.Drawing.Point(88, 117);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(110, 23);
            this.label47.TabIndex = 13;
            this.label47.Text = "Connected";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuFlatButton15
            // 
            this.bunifuFlatButton15.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton15.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton15.BorderRadius = 0;
            this.bunifuFlatButton15.ButtonText = "";
            this.bunifuFlatButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton15.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton15.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton15.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton15.Iconimage")));
            this.bunifuFlatButton15.Iconimage_right = null;
            this.bunifuFlatButton15.Iconimage_right_Selected = null;
            this.bunifuFlatButton15.Iconimage_Selected = null;
            this.bunifuFlatButton15.IconMarginLeft = 0;
            this.bunifuFlatButton15.IconMarginRight = 0;
            this.bunifuFlatButton15.IconRightVisible = false;
            this.bunifuFlatButton15.IconRightZoom = 0D;
            this.bunifuFlatButton15.IconVisible = false;
            this.bunifuFlatButton15.IconZoom = 90D;
            this.bunifuFlatButton15.IsTab = false;
            this.bunifuFlatButton15.Location = new System.Drawing.Point(121, 105);
            this.bunifuFlatButton15.Name = "bunifuFlatButton15";
            this.bunifuFlatButton15.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton15.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton15.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton15.selected = false;
            this.bunifuFlatButton15.Size = new System.Drawing.Size(49, 48);
            this.bunifuFlatButton15.TabIndex = 10;
            this.bunifuFlatButton15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton15.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton15.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuCircleProgressbar2
            // 
            this.bunifuCircleProgressbar2.animated = true;
            this.bunifuCircleProgressbar2.animationIterval = 1;
            this.bunifuCircleProgressbar2.animationSpeed = 1;
            this.bunifuCircleProgressbar2.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar2.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.bunifuCircleProgressbar2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar2.LabelVisible = false;
            this.bunifuCircleProgressbar2.LineProgressThickness = 8;
            this.bunifuCircleProgressbar2.LineThickness = 6;
            this.bunifuCircleProgressbar2.Location = new System.Drawing.Point(61, 48);
            this.bunifuCircleProgressbar2.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar2.MaxValue = 100;
            this.bunifuCircleProgressbar2.Name = "bunifuCircleProgressbar2";
            this.bunifuCircleProgressbar2.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar2.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar2.Size = new System.Drawing.Size(159, 159);
            this.bunifuCircleProgressbar2.TabIndex = 1;
            this.bunifuCircleProgressbar2.Value = 50;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.label71);
            this.panel4.Controls.Add(this.label70);
            this.panel4.Controls.Add(this.label69);
            this.panel4.Controls.Add(this.label68);
            this.panel4.Controls.Add(this.label49);
            this.panel4.Controls.Add(this.bunifuCircleProgressbar8);
            this.panel4.Controls.Add(this.bunifuCircleProgressbar7);
            this.panel4.Controls.Add(this.bunifuCircleProgressbar9);
            this.panel4.Controls.Add(this.bunifuCircleProgressbar10);
            this.bunifuTransition2.SetDecoration(this.panel4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel4, BunifuAnimatorNS.DecorationType.None);
            this.panel4.Location = new System.Drawing.Point(342, 77);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(280, 255);
            this.panel4.TabIndex = 8;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransition1.SetDecoration(this.label71, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label71, BunifuAnimatorNS.DecorationType.None);
            this.label71.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.Gray;
            this.label71.Location = new System.Drawing.Point(198, 181);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(28, 18);
            this.label71.TabIndex = 23;
            this.label71.Text = "50";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransition1.SetDecoration(this.label70, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label70, BunifuAnimatorNS.DecorationType.None);
            this.label70.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.Color.Gray;
            this.label70.Location = new System.Drawing.Point(49, 181);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(38, 18);
            this.label70.TabIndex = 22;
            this.label70.Text = "130";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransition1.SetDecoration(this.label69, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label69, BunifuAnimatorNS.DecorationType.None);
            this.label69.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.Gray;
            this.label69.Location = new System.Drawing.Point(204, 59);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(18, 18);
            this.label69.TabIndex = 21;
            this.label69.Text = "6";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransition1.SetDecoration(this.label68, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label68, BunifuAnimatorNS.DecorationType.None);
            this.label68.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.Gray;
            this.label68.Location = new System.Drawing.Point(54, 59);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(28, 18);
            this.label68.TabIndex = 20;
            this.label68.Text = "11";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransition1.SetDecoration(this.label49, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label49, BunifuAnimatorNS.DecorationType.None);
            this.label49.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.DarkGray;
            this.label49.Location = new System.Drawing.Point(98, 110);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(88, 36);
            this.label49.TabIndex = 13;
            this.label49.Text = "  History\r\n(last day)";
            // 
            // bunifuCircleProgressbar8
            // 
            this.bunifuCircleProgressbar8.animated = false;
            this.bunifuCircleProgressbar8.animationIterval = 1;
            this.bunifuCircleProgressbar8.animationSpeed = 50;
            this.bunifuCircleProgressbar8.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar8.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar8.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar8.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar8.LabelVisible = false;
            this.bunifuCircleProgressbar8.LineProgressThickness = 5;
            this.bunifuCircleProgressbar8.LineThickness = 4;
            this.bunifuCircleProgressbar8.Location = new System.Drawing.Point(154, 9);
            this.bunifuCircleProgressbar8.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar8.MaxValue = 100;
            this.bunifuCircleProgressbar8.Name = "bunifuCircleProgressbar8";
            this.bunifuCircleProgressbar8.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar8.ProgressColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar8.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar8.TabIndex = 11;
            this.bunifuCircleProgressbar8.Value = 50;
            // 
            // bunifuCircleProgressbar7
            // 
            this.bunifuCircleProgressbar7.animated = false;
            this.bunifuCircleProgressbar7.animationIterval = 1;
            this.bunifuCircleProgressbar7.animationSpeed = 50;
            this.bunifuCircleProgressbar7.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar7.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar7.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar7.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar7.LabelVisible = false;
            this.bunifuCircleProgressbar7.LineProgressThickness = 5;
            this.bunifuCircleProgressbar7.LineThickness = 4;
            this.bunifuCircleProgressbar7.Location = new System.Drawing.Point(154, 130);
            this.bunifuCircleProgressbar7.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar7.MaxValue = 100;
            this.bunifuCircleProgressbar7.Name = "bunifuCircleProgressbar7";
            this.bunifuCircleProgressbar7.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar7.ProgressColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar7.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar7.TabIndex = 12;
            this.bunifuCircleProgressbar7.Value = 55;
            // 
            // bunifuCircleProgressbar9
            // 
            this.bunifuCircleProgressbar9.animated = false;
            this.bunifuCircleProgressbar9.animationIterval = 1;
            this.bunifuCircleProgressbar9.animationSpeed = 50;
            this.bunifuCircleProgressbar9.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar9.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar9.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar9.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar9.LabelVisible = false;
            this.bunifuCircleProgressbar9.LineProgressThickness = 5;
            this.bunifuCircleProgressbar9.LineThickness = 4;
            this.bunifuCircleProgressbar9.Location = new System.Drawing.Point(10, 130);
            this.bunifuCircleProgressbar9.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar9.MaxValue = 150;
            this.bunifuCircleProgressbar9.Name = "bunifuCircleProgressbar9";
            this.bunifuCircleProgressbar9.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar9.ProgressColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar9.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar9.TabIndex = 10;
            this.bunifuCircleProgressbar9.Value = 130;
            // 
            // bunifuCircleProgressbar10
            // 
            this.bunifuCircleProgressbar10.animated = false;
            this.bunifuCircleProgressbar10.animationIterval = 1;
            this.bunifuCircleProgressbar10.animationSpeed = 50;
            this.bunifuCircleProgressbar10.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar10.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar10.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar10.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar10.LabelVisible = false;
            this.bunifuCircleProgressbar10.LineProgressThickness = 5;
            this.bunifuCircleProgressbar10.LineThickness = 4;
            this.bunifuCircleProgressbar10.Location = new System.Drawing.Point(10, 9);
            this.bunifuCircleProgressbar10.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar10.MaxValue = 100;
            this.bunifuCircleProgressbar10.Name = "bunifuCircleProgressbar10";
            this.bunifuCircleProgressbar10.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar10.ProgressColor = System.Drawing.Color.Gray;
            this.bunifuCircleProgressbar10.Size = new System.Drawing.Size(116, 116);
            this.bunifuCircleProgressbar10.TabIndex = 9;
            this.bunifuCircleProgressbar10.Value = 11;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.label37);
            this.panel3.Controls.Add(this.bunifuCircleProgressbar1);
            this.bunifuTransition2.SetDecoration(this.panel3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel3, BunifuAnimatorNS.DecorationType.None);
            this.panel3.Location = new System.Drawing.Point(36, 77);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(280, 255);
            this.panel3.TabIndex = 7;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label37, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label37, BunifuAnimatorNS.DecorationType.None);
            this.label37.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.DarkGray;
            this.label37.Location = new System.Drawing.Point(18, 22);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(68, 18);
            this.label37.TabIndex = 1;
            this.label37.Text = "Battery";
            // 
            // bunifuCircleProgressbar1
            // 
            this.bunifuCircleProgressbar1.animated = true;
            this.bunifuCircleProgressbar1.animationIterval = 1;
            this.bunifuCircleProgressbar1.animationSpeed = 50;
            this.bunifuCircleProgressbar1.BackColor = System.Drawing.Color.Gainsboro;
            this.bunifuCircleProgressbar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar1.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.bunifuCircleProgressbar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar1.LabelVisible = false;
            this.bunifuCircleProgressbar1.LineProgressThickness = 8;
            this.bunifuCircleProgressbar1.LineThickness = 6;
            this.bunifuCircleProgressbar1.Location = new System.Drawing.Point(58, 44);
            this.bunifuCircleProgressbar1.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar1.MaxValue = 100;
            this.bunifuCircleProgressbar1.Name = "bunifuCircleProgressbar1";
            this.bunifuCircleProgressbar1.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar1.Size = new System.Drawing.Size(159, 159);
            this.bunifuCircleProgressbar1.TabIndex = 0;
            this.bunifuCircleProgressbar1.Value = 0;
            // 
            // bunifuFlatButton11
            // 
            this.bunifuFlatButton11.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuFlatButton11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton11.BorderRadius = 0;
            this.bunifuFlatButton11.ButtonText = "";
            this.bunifuFlatButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton11.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton11.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton11.Iconimage")));
            this.bunifuFlatButton11.Iconimage_right = null;
            this.bunifuFlatButton11.Iconimage_right_Selected = null;
            this.bunifuFlatButton11.Iconimage_Selected = null;
            this.bunifuFlatButton11.IconMarginLeft = 0;
            this.bunifuFlatButton11.IconMarginRight = 0;
            this.bunifuFlatButton11.IconRightVisible = false;
            this.bunifuFlatButton11.IconRightZoom = 0D;
            this.bunifuFlatButton11.IconVisible = false;
            this.bunifuFlatButton11.IconZoom = 45D;
            this.bunifuFlatButton11.IsTab = false;
            this.bunifuFlatButton11.Location = new System.Drawing.Point(880, 6);
            this.bunifuFlatButton11.Name = "bunifuFlatButton11";
            this.bunifuFlatButton11.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton11.selected = false;
            this.bunifuFlatButton11.Size = new System.Drawing.Size(30, 30);
            this.bunifuFlatButton11.TabIndex = 6;
            this.bunifuFlatButton11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton11.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton11.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton11.Click += new System.EventHandler(this.bunifuFlatButton11_Click);
            // 
            // bunifuFlatButton12
            // 
            this.bunifuFlatButton12.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuFlatButton12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton12.BorderRadius = 0;
            this.bunifuFlatButton12.ButtonText = "";
            this.bunifuFlatButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton12.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton12.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton12.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton12.Iconimage")));
            this.bunifuFlatButton12.Iconimage_right = null;
            this.bunifuFlatButton12.Iconimage_right_Selected = null;
            this.bunifuFlatButton12.Iconimage_Selected = null;
            this.bunifuFlatButton12.IconMarginLeft = 0;
            this.bunifuFlatButton12.IconMarginRight = 0;
            this.bunifuFlatButton12.IconRightVisible = false;
            this.bunifuFlatButton12.IconRightZoom = 0D;
            this.bunifuFlatButton12.IconVisible = false;
            this.bunifuFlatButton12.IconZoom = 45D;
            this.bunifuFlatButton12.IsTab = false;
            this.bunifuFlatButton12.Location = new System.Drawing.Point(916, 6);
            this.bunifuFlatButton12.Name = "bunifuFlatButton12";
            this.bunifuFlatButton12.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton12.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton12.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton12.selected = false;
            this.bunifuFlatButton12.Size = new System.Drawing.Size(30, 30);
            this.bunifuFlatButton12.TabIndex = 5;
            this.bunifuFlatButton12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton12.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton12.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton12.Click += new System.EventHandler(this.bunifuFlatButton12_Click);
            // 
            // Serial_Monitor
            // 
            this.Serial_Monitor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.Serial_Monitor.Controls.Add(this.panel30);
            this.Serial_Monitor.Controls.Add(this.label7);
            this.Serial_Monitor.Controls.Add(this.label6);
            this.Serial_Monitor.Controls.Add(this.label5);
            this.Serial_Monitor.Controls.Add(this.label3);
            this.Serial_Monitor.Controls.Add(this.label2);
            this.Serial_Monitor.Controls.Add(this.label4);
            this.Serial_Monitor.Controls.Add(this.richTextBox1);
            this.bunifuTransition2.SetDecoration(this.Serial_Monitor, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.Serial_Monitor, BunifuAnimatorNS.DecorationType.None);
            this.Serial_Monitor.Location = new System.Drawing.Point(4, 22);
            this.Serial_Monitor.Name = "Serial_Monitor";
            this.Serial_Monitor.Padding = new System.Windows.Forms.Padding(3);
            this.Serial_Monitor.Size = new System.Drawing.Size(963, 734);
            this.Serial_Monitor.TabIndex = 0;
            this.Serial_Monitor.Text = "Serial Monitor";
            this.Serial_Monitor.Click += new System.EventHandler(this.Serial_Monitor_Click);
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Controls.Add(this.bunifuCustomLabel7);
            this.panel30.Controls.Add(this.bunifuImageButton6);
            this.panel30.Controls.Add(this.bunifuCheckbox21);
            this.panel30.Controls.Add(this.bunifuTextbox1);
            this.bunifuTransition2.SetDecoration(this.panel30, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel30, BunifuAnimatorNS.DecorationType.None);
            this.panel30.Location = new System.Drawing.Point(0, 665);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(960, 45);
            this.panel30.TabIndex = 31;
            // 
            // panel31
            // 
            this.bunifuTransition2.SetDecoration(this.panel31, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel31, BunifuAnimatorNS.DecorationType.None);
            this.panel31.Location = new System.Drawing.Point(656, 0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(106, 88);
            this.panel31.TabIndex = 31;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(43, 14);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(88, 18);
            this.bunifuCustomLabel7.TabIndex = 29;
            this.bunifuCustomLabel7.Text = "Auto Scroll";
            this.bunifuCustomLabel7.Click += new System.EventHandler(this.bunifuCustomLabel7_Click);
            // 
            // bunifuImageButton6
            // 
            this.bunifuImageButton6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.bunifuImageButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuTransition2.SetDecoration(this.bunifuImageButton6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuImageButton6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton6.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton6.Image")));
            this.bunifuImageButton6.ImageActive = null;
            this.bunifuImageButton6.Location = new System.Drawing.Point(913, 4);
            this.bunifuImageButton6.Name = "bunifuImageButton6";
            this.bunifuImageButton6.Size = new System.Drawing.Size(41, 38);
            this.bunifuImageButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton6.TabIndex = 30;
            this.bunifuImageButton6.TabStop = false;
            this.bunifuImageButton6.Zoom = 10;
            this.bunifuImageButton6.Click += new System.EventHandler(this.bunifuImageButton6_Click);
            // 
            // bunifuCheckbox21
            // 
            this.bunifuCheckbox21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCheckbox21.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.bunifuCheckbox21.Checked = true;
            this.bunifuCheckbox21.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox21.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox21.Location = new System.Drawing.Point(18, 14);
            this.bunifuCheckbox21.Name = "bunifuCheckbox21";
            this.bunifuCheckbox21.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox21.TabIndex = 28;
            this.bunifuCheckbox21.OnChange += new System.EventHandler(this.bunifuCheckbox21_OnChange);
            // 
            // bunifuTextbox1
            // 
            this.bunifuTextbox1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.bunifuTextbox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuTextbox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox1.BackgroundImage")));
            this.bunifuTextbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuTextbox1.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox1.Icon")));
            this.bunifuTextbox1.Location = new System.Drawing.Point(759, 2);
            this.bunifuTextbox1.Name = "bunifuTextbox1";
            this.bunifuTextbox1.Size = new System.Drawing.Size(198, 42);
            this.bunifuTextbox1.TabIndex = 27;
            this.bunifuTextbox1.text = "";
            this.bunifuTextbox1.OnTextChange += new System.EventHandler(this.bunifuTextbox1_OnTextChange);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label7, BunifuAnimatorNS.DecorationType.None);
            this.label7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(830, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 18);
            this.label7.TabIndex = 26;
            this.label7.Text = "Water level";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label6, BunifuAnimatorNS.DecorationType.None);
            this.label6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(281, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 18);
            this.label6.TabIndex = 25;
            this.label6.Text = "pH";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label5, BunifuAnimatorNS.DecorationType.None);
            this.label5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(365, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(169, 18);
            this.label5.TabIndex = 24;
            this.label5.Text = "Electrical Conductivity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label3, BunifuAnimatorNS.DecorationType.None);
            this.label3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(617, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 18);
            this.label3.TabIndex = 23;
            this.label3.Text = "location";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label2, BunifuAnimatorNS.DecorationType.None);
            this.label2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(144, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "Turbidity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label4, BunifuAnimatorNS.DecorationType.None);
            this.label4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(23, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 18);
            this.label4.TabIndex = 21;
            this.label4.Text = "Temperature";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuTransition2.SetDecoration(this.richTextBox1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.richTextBox1, BunifuAnimatorNS.DecorationType.None);
            this.richTextBox1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.ForeColor = System.Drawing.Color.Silver;
            this.richTextBox1.Location = new System.Drawing.Point(0, 43);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(963, 685);
            this.richTextBox1.TabIndex = 16;
            this.richTextBox1.TabStop = false;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Charts
            // 
            this.Charts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.Charts.Controls.Add(this.tabControl2);
            this.bunifuTransition2.SetDecoration(this.Charts, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.Charts, BunifuAnimatorNS.DecorationType.None);
            this.Charts.Location = new System.Drawing.Point(4, 22);
            this.Charts.Name = "Charts";
            this.Charts.Size = new System.Drawing.Size(963, 734);
            this.Charts.TabIndex = 2;
            this.Charts.Text = "Charts";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.bunifuTransition2.SetDecoration(this.tabControl2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabControl2, BunifuAnimatorNS.DecorationType.None);
            this.tabControl2.Location = new System.Drawing.Point(-1, -22);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(968, 756);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.tabPage1.Controls.Add(this.panel13);
            this.tabPage1.Controls.Add(this.panel12);
            this.tabPage1.Controls.Add(this.panel11);
            this.tabPage1.Controls.Add(this.panel10);
            this.tabPage1.Controls.Add(this.panel9);
            this.bunifuTransition2.SetDecoration(this.tabPage1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabPage1, BunifuAnimatorNS.DecorationType.None);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(960, 730);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Values";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel13.Controls.Add(this.bunifuFlatButton26);
            this.panel13.Controls.Add(this.bunifuFlatButton21);
            this.panel13.Controls.Add(this.bunifuFlatButton22);
            this.panel13.Controls.Add(this.bunifuFlatButton19);
            this.panel13.Controls.Add(this.bunifuFlatButton18);
            this.panel13.Controls.Add(this.bunifuFlatButton17);
            this.panel13.Controls.Add(this.bunifuFlatButton16);
            this.panel13.Controls.Add(this.pictureBox3);
            this.panel13.Controls.Add(this.label8);
            this.panel13.Controls.Add(this.bunifuCustomLabel6);
            this.panel13.Controls.Add(this.bunifuCustomLabel5);
            this.panel13.Controls.Add(this.bunifuSwitch2);
            this.panel13.Controls.Add(this.bunifuSwitch1);
            this.bunifuTransition2.SetDecoration(this.panel13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel13, BunifuAnimatorNS.DecorationType.None);
            this.panel13.Location = new System.Drawing.Point(-220, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(1184, 331);
            this.panel13.TabIndex = 15;
            this.panel13.Paint += new System.Windows.Forms.PaintEventHandler(this.panel13_Paint);
            // 
            // bunifuFlatButton26
            // 
            this.bunifuFlatButton26.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(145)))));
            this.bunifuFlatButton26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(145)))));
            this.bunifuFlatButton26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton26.BorderRadius = 0;
            this.bunifuFlatButton26.ButtonText = "    All values";
            this.bunifuFlatButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton26, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton26, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton26.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton26.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton26.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton26.Iconimage")));
            this.bunifuFlatButton26.Iconimage_right = null;
            this.bunifuFlatButton26.Iconimage_right_Selected = null;
            this.bunifuFlatButton26.Iconimage_Selected = null;
            this.bunifuFlatButton26.IconMarginLeft = 0;
            this.bunifuFlatButton26.IconMarginRight = 0;
            this.bunifuFlatButton26.IconRightVisible = false;
            this.bunifuFlatButton26.IconRightZoom = 0D;
            this.bunifuFlatButton26.IconVisible = false;
            this.bunifuFlatButton26.IconZoom = 90D;
            this.bunifuFlatButton26.IsTab = false;
            this.bunifuFlatButton26.Location = new System.Drawing.Point(836, 275);
            this.bunifuFlatButton26.Name = "bunifuFlatButton26";
            this.bunifuFlatButton26.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(145)))));
            this.bunifuFlatButton26.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(145)))));
            this.bunifuFlatButton26.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton26.selected = false;
            this.bunifuFlatButton26.Size = new System.Drawing.Size(120, 41);
            this.bunifuFlatButton26.TabIndex = 15;
            this.bunifuFlatButton26.Text = "    All values";
            this.bunifuFlatButton26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton26.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton26.TextFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton26.Click += new System.EventHandler(this.bunifuFlatButton26_Click);
            // 
            // bunifuFlatButton21
            // 
            this.bunifuFlatButton21.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuFlatButton21.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton21.BorderRadius = 0;
            this.bunifuFlatButton21.ButtonText = "";
            this.bunifuFlatButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton21.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton21.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton21.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton21.Iconimage")));
            this.bunifuFlatButton21.Iconimage_right = null;
            this.bunifuFlatButton21.Iconimage_right_Selected = null;
            this.bunifuFlatButton21.Iconimage_Selected = null;
            this.bunifuFlatButton21.IconMarginLeft = 0;
            this.bunifuFlatButton21.IconMarginRight = 0;
            this.bunifuFlatButton21.IconRightVisible = false;
            this.bunifuFlatButton21.IconRightZoom = 0D;
            this.bunifuFlatButton21.IconVisible = false;
            this.bunifuFlatButton21.IconZoom = 45D;
            this.bunifuFlatButton21.IsTab = false;
            this.bunifuFlatButton21.Location = new System.Drawing.Point(1100, 9);
            this.bunifuFlatButton21.Name = "bunifuFlatButton21";
            this.bunifuFlatButton21.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton21.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton21.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton21.selected = false;
            this.bunifuFlatButton21.Size = new System.Drawing.Size(30, 30);
            this.bunifuFlatButton21.TabIndex = 14;
            this.bunifuFlatButton21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton21.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton21.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton21.Click += new System.EventHandler(this.bunifuFlatButton21_Click);
            // 
            // bunifuFlatButton22
            // 
            this.bunifuFlatButton22.Activecolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuFlatButton22.BackColor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton22.BorderRadius = 0;
            this.bunifuFlatButton22.ButtonText = "";
            this.bunifuFlatButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton22, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton22, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton22.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton22.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton22.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton22.Iconimage")));
            this.bunifuFlatButton22.Iconimage_right = null;
            this.bunifuFlatButton22.Iconimage_right_Selected = null;
            this.bunifuFlatButton22.Iconimage_Selected = null;
            this.bunifuFlatButton22.IconMarginLeft = 0;
            this.bunifuFlatButton22.IconMarginRight = 0;
            this.bunifuFlatButton22.IconRightVisible = false;
            this.bunifuFlatButton22.IconRightZoom = 0D;
            this.bunifuFlatButton22.IconVisible = false;
            this.bunifuFlatButton22.IconZoom = 45D;
            this.bunifuFlatButton22.IsTab = false;
            this.bunifuFlatButton22.Location = new System.Drawing.Point(1136, 9);
            this.bunifuFlatButton22.Name = "bunifuFlatButton22";
            this.bunifuFlatButton22.Normalcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton22.OnHovercolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton22.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton22.selected = false;
            this.bunifuFlatButton22.Size = new System.Drawing.Size(30, 30);
            this.bunifuFlatButton22.TabIndex = 13;
            this.bunifuFlatButton22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton22.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton22.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton22.Click += new System.EventHandler(this.bunifuFlatButton22_Click);
            // 
            // bunifuFlatButton19
            // 
            this.bunifuFlatButton19.Activecolor = System.Drawing.Color.DarkOrchid;
            this.bunifuFlatButton19.BackColor = System.Drawing.Color.DarkOrchid;
            this.bunifuFlatButton19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton19.BorderRadius = 0;
            this.bunifuFlatButton19.ButtonText = "E. Conductivity";
            this.bunifuFlatButton19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton19, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton19, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton19.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton19.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton19.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton19.Iconimage")));
            this.bunifuFlatButton19.Iconimage_right = null;
            this.bunifuFlatButton19.Iconimage_right_Selected = null;
            this.bunifuFlatButton19.Iconimage_Selected = null;
            this.bunifuFlatButton19.IconMarginLeft = 0;
            this.bunifuFlatButton19.IconMarginRight = 0;
            this.bunifuFlatButton19.IconRightVisible = false;
            this.bunifuFlatButton19.IconRightZoom = 0D;
            this.bunifuFlatButton19.IconVisible = false;
            this.bunifuFlatButton19.IconZoom = 90D;
            this.bunifuFlatButton19.IsTab = false;
            this.bunifuFlatButton19.Location = new System.Drawing.Point(692, 275);
            this.bunifuFlatButton19.Name = "bunifuFlatButton19";
            this.bunifuFlatButton19.Normalcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuFlatButton19.OnHovercolor = System.Drawing.Color.DarkOrchid;
            this.bunifuFlatButton19.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton19.selected = false;
            this.bunifuFlatButton19.Size = new System.Drawing.Size(120, 41);
            this.bunifuFlatButton19.TabIndex = 12;
            this.bunifuFlatButton19.Text = "E. Conductivity";
            this.bunifuFlatButton19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton19.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton19.TextFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton19.Click += new System.EventHandler(this.bunifuFlatButton19_Click);
            // 
            // bunifuFlatButton18
            // 
            this.bunifuFlatButton18.Activecolor = System.Drawing.Color.RoyalBlue;
            this.bunifuFlatButton18.BackColor = System.Drawing.Color.RoyalBlue;
            this.bunifuFlatButton18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton18.BorderRadius = 0;
            this.bunifuFlatButton18.ButtonText = "         pH";
            this.bunifuFlatButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton18, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton18, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton18.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton18.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton18.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton18.Iconimage")));
            this.bunifuFlatButton18.Iconimage_right = null;
            this.bunifuFlatButton18.Iconimage_right_Selected = null;
            this.bunifuFlatButton18.Iconimage_Selected = null;
            this.bunifuFlatButton18.IconMarginLeft = 0;
            this.bunifuFlatButton18.IconMarginRight = 0;
            this.bunifuFlatButton18.IconRightVisible = false;
            this.bunifuFlatButton18.IconRightZoom = 0D;
            this.bunifuFlatButton18.IconVisible = false;
            this.bunifuFlatButton18.IconZoom = 90D;
            this.bunifuFlatButton18.IsTab = false;
            this.bunifuFlatButton18.Location = new System.Drawing.Point(549, 275);
            this.bunifuFlatButton18.Name = "bunifuFlatButton18";
            this.bunifuFlatButton18.Normalcolor = System.Drawing.Color.RoyalBlue;
            this.bunifuFlatButton18.OnHovercolor = System.Drawing.Color.RoyalBlue;
            this.bunifuFlatButton18.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton18.selected = false;
            this.bunifuFlatButton18.Size = new System.Drawing.Size(120, 41);
            this.bunifuFlatButton18.TabIndex = 11;
            this.bunifuFlatButton18.Text = "         pH";
            this.bunifuFlatButton18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton18.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton18.TextFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton18.Click += new System.EventHandler(this.bunifuFlatButton18_Click);
            // 
            // bunifuFlatButton17
            // 
            this.bunifuFlatButton17.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton17.BorderRadius = 0;
            this.bunifuFlatButton17.ButtonText = "     Turbidity";
            this.bunifuFlatButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton17, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton17, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton17.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton17.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton17.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton17.Iconimage")));
            this.bunifuFlatButton17.Iconimage_right = null;
            this.bunifuFlatButton17.Iconimage_right_Selected = null;
            this.bunifuFlatButton17.Iconimage_Selected = null;
            this.bunifuFlatButton17.IconMarginLeft = 0;
            this.bunifuFlatButton17.IconMarginRight = 0;
            this.bunifuFlatButton17.IconRightVisible = false;
            this.bunifuFlatButton17.IconRightZoom = 0D;
            this.bunifuFlatButton17.IconVisible = false;
            this.bunifuFlatButton17.IconZoom = 90D;
            this.bunifuFlatButton17.IsTab = false;
            this.bunifuFlatButton17.Location = new System.Drawing.Point(404, 275);
            this.bunifuFlatButton17.Name = "bunifuFlatButton17";
            this.bunifuFlatButton17.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton17.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton17.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton17.selected = false;
            this.bunifuFlatButton17.Size = new System.Drawing.Size(120, 41);
            this.bunifuFlatButton17.TabIndex = 10;
            this.bunifuFlatButton17.Text = "     Turbidity";
            this.bunifuFlatButton17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton17.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton17.TextFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton17.Click += new System.EventHandler(this.bunifuFlatButton17_Click_1);
            // 
            // bunifuFlatButton16
            // 
            this.bunifuFlatButton16.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton16.BorderRadius = 0;
            this.bunifuFlatButton16.ButtonText = "  Temperature";
            this.bunifuFlatButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton16, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton16, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton16.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton16.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton16.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton16.Iconimage")));
            this.bunifuFlatButton16.Iconimage_right = null;
            this.bunifuFlatButton16.Iconimage_right_Selected = null;
            this.bunifuFlatButton16.Iconimage_Selected = null;
            this.bunifuFlatButton16.IconMarginLeft = 0;
            this.bunifuFlatButton16.IconMarginRight = 0;
            this.bunifuFlatButton16.IconRightVisible = false;
            this.bunifuFlatButton16.IconRightZoom = 0D;
            this.bunifuFlatButton16.IconVisible = false;
            this.bunifuFlatButton16.IconZoom = 90D;
            this.bunifuFlatButton16.IsTab = false;
            this.bunifuFlatButton16.Location = new System.Drawing.Point(260, 275);
            this.bunifuFlatButton16.Name = "bunifuFlatButton16";
            this.bunifuFlatButton16.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton16.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuFlatButton16.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton16.selected = false;
            this.bunifuFlatButton16.Size = new System.Drawing.Size(120, 41);
            this.bunifuFlatButton16.TabIndex = 9;
            this.bunifuFlatButton16.Text = "  Temperature";
            this.bunifuFlatButton16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton16.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton16.TextFont = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton16.Click += new System.EventHandler(this.bunifuFlatButton16_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTransition1.SetDecoration(this.pictureBox3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.pictureBox3, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(305, 63);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(96, 96);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label8, BunifuAnimatorNS.DecorationType.None);
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Silver;
            this.label8.Location = new System.Drawing.Point(430, 98);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(497, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "The values of water quality are in the normal range";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(891, 230);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(203, 18);
            this.bunifuCustomLabel6.TabIndex = 6;
            this.bunifuCustomLabel6.Text = "Notify when a value is bad";
            this.bunifuCustomLabel6.Click += new System.EventHandler(this.bunifuCustomLabel6_Click);
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.Gainsboro;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(1013, 184);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(81, 18);
            this.bunifuCustomLabel5.TabIndex = 5;
            this.bunifuCustomLabel5.Text = "Chart grid";
            this.bunifuCustomLabel5.Click += new System.EventHandler(this.bunifuCustomLabel5_Click);
            // 
            // bunifuSwitch2
            // 
            this.bunifuSwitch2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSwitch2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch2.BorderRadius = 0;
            this.bunifuSwitch2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch2.Location = new System.Drawing.Point(1100, 185);
            this.bunifuSwitch2.Name = "bunifuSwitch2";
            this.bunifuSwitch2.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch2.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch2.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch2.TabIndex = 3;
            this.bunifuSwitch2.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch2.Value = true;
            this.bunifuSwitch2.Click += new System.EventHandler(this.bunifuSwitch2_Click);
            // 
            // bunifuSwitch1
            // 
            this.bunifuSwitch1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSwitch1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch1.BorderRadius = 0;
            this.bunifuSwitch1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch1.Location = new System.Drawing.Point(1100, 230);
            this.bunifuSwitch1.Name = "bunifuSwitch1";
            this.bunifuSwitch1.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch1.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch1.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch1.TabIndex = 2;
            this.bunifuSwitch1.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch1.Value = false;
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel12.Controls.Add(this.bunifuCustomLabel11);
            this.panel12.Controls.Add(this.bunifuCircleProgressbar11);
            this.bunifuTransition2.SetDecoration(this.panel12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel12, BunifuAnimatorNS.DecorationType.None);
            this.panel12.Location = new System.Drawing.Point(721, 478);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(220, 220);
            this.panel12.TabIndex = 14;
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(87, 99);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(27, 32);
            this.bunifuCustomLabel11.TabIndex = 13;
            this.bunifuCustomLabel11.Text = "-";
            // 
            // bunifuCircleProgressbar11
            // 
            this.bunifuCircleProgressbar11.animated = false;
            this.bunifuCircleProgressbar11.animationIterval = 1;
            this.bunifuCircleProgressbar11.animationSpeed = 50;
            this.bunifuCircleProgressbar11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuCircleProgressbar11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar11.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar11.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar11.ForeColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCircleProgressbar11.LabelVisible = false;
            this.bunifuCircleProgressbar11.LineProgressThickness = 10;
            this.bunifuCircleProgressbar11.LineThickness = 8;
            this.bunifuCircleProgressbar11.Location = new System.Drawing.Point(10, 12);
            this.bunifuCircleProgressbar11.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar11.MaxValue = 100;
            this.bunifuCircleProgressbar11.Name = "bunifuCircleProgressbar11";
            this.bunifuCircleProgressbar11.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar11.ProgressColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCircleProgressbar11.Size = new System.Drawing.Size(200, 200);
            this.bunifuCircleProgressbar11.TabIndex = 12;
            this.bunifuCircleProgressbar11.Value = 0;
            // 
            // panel11
            // 
            this.panel11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel11.Controls.Add(this.bunifuCustomLabel10);
            this.panel11.Controls.Add(this.bunifuCircleProgressbar12);
            this.bunifuTransition2.SetDecoration(this.panel11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel11, BunifuAnimatorNS.DecorationType.None);
            this.panel11.Location = new System.Drawing.Point(487, 479);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(220, 220);
            this.panel11.TabIndex = 14;
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.ForeColor = System.Drawing.Color.RoyalBlue;
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(93, 99);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(27, 32);
            this.bunifuCustomLabel10.TabIndex = 12;
            this.bunifuCustomLabel10.Text = "-";
            // 
            // bunifuCircleProgressbar12
            // 
            this.bunifuCircleProgressbar12.animated = false;
            this.bunifuCircleProgressbar12.animationIterval = 1;
            this.bunifuCircleProgressbar12.animationSpeed = 50;
            this.bunifuCircleProgressbar12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuCircleProgressbar12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar12.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar12.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar12.ForeColor = System.Drawing.Color.RoyalBlue;
            this.bunifuCircleProgressbar12.LabelVisible = false;
            this.bunifuCircleProgressbar12.LineProgressThickness = 10;
            this.bunifuCircleProgressbar12.LineThickness = 8;
            this.bunifuCircleProgressbar12.Location = new System.Drawing.Point(10, 11);
            this.bunifuCircleProgressbar12.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar12.MaxValue = 150;
            this.bunifuCircleProgressbar12.Name = "bunifuCircleProgressbar12";
            this.bunifuCircleProgressbar12.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar12.ProgressColor = System.Drawing.Color.RoyalBlue;
            this.bunifuCircleProgressbar12.Size = new System.Drawing.Size(200, 200);
            this.bunifuCircleProgressbar12.TabIndex = 11;
            this.bunifuCircleProgressbar12.Value = 0;
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel10.Controls.Add(this.bunifuCustomLabel9);
            this.panel10.Controls.Add(this.bunifuCircleProgressbar13);
            this.bunifuTransition2.SetDecoration(this.panel10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel10, BunifuAnimatorNS.DecorationType.None);
            this.panel10.Location = new System.Drawing.Point(250, 478);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(220, 220);
            this.panel10.TabIndex = 14;
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(77, 99);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(27, 32);
            this.bunifuCustomLabel9.TabIndex = 11;
            this.bunifuCustomLabel9.Text = "-";
            // 
            // bunifuCircleProgressbar13
            // 
            this.bunifuCircleProgressbar13.animated = false;
            this.bunifuCircleProgressbar13.animationIterval = 1;
            this.bunifuCircleProgressbar13.animationSpeed = 50;
            this.bunifuCircleProgressbar13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuCircleProgressbar13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar13.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar13.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar13.LabelVisible = false;
            this.bunifuCircleProgressbar13.LineProgressThickness = 10;
            this.bunifuCircleProgressbar13.LineThickness = 8;
            this.bunifuCircleProgressbar13.Location = new System.Drawing.Point(10, 11);
            this.bunifuCircleProgressbar13.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar13.MaxValue = 160;
            this.bunifuCircleProgressbar13.Name = "bunifuCircleProgressbar13";
            this.bunifuCircleProgressbar13.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar13.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar13.Size = new System.Drawing.Size(200, 200);
            this.bunifuCircleProgressbar13.TabIndex = 10;
            this.bunifuCircleProgressbar13.Value = 0;
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel9.Controls.Add(this.bunifuCustomLabel8);
            this.panel9.Controls.Add(this.bunifuCircleProgressbar14);
            this.bunifuTransition2.SetDecoration(this.panel9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel9, BunifuAnimatorNS.DecorationType.None);
            this.panel9.Location = new System.Drawing.Point(13, 479);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(220, 220);
            this.panel9.TabIndex = 13;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(84, 99);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(27, 32);
            this.bunifuCustomLabel8.TabIndex = 10;
            this.bunifuCustomLabel8.Text = "-";
            // 
            // bunifuCircleProgressbar14
            // 
            this.bunifuCircleProgressbar14.animated = false;
            this.bunifuCircleProgressbar14.animationIterval = 1;
            this.bunifuCircleProgressbar14.animationSpeed = 50;
            this.bunifuCircleProgressbar14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuCircleProgressbar14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar14.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar14.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar14.LabelVisible = false;
            this.bunifuCircleProgressbar14.LineProgressThickness = 10;
            this.bunifuCircleProgressbar14.LineThickness = 8;
            this.bunifuCircleProgressbar14.Location = new System.Drawing.Point(10, 11);
            this.bunifuCircleProgressbar14.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar14.MaxValue = 30;
            this.bunifuCircleProgressbar14.Name = "bunifuCircleProgressbar14";
            this.bunifuCircleProgressbar14.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar14.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuCircleProgressbar14.Size = new System.Drawing.Size(200, 200);
            this.bunifuCircleProgressbar14.TabIndex = 9;
            this.bunifuCircleProgressbar14.Value = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.tabPage2.Controls.Add(this.panel16);
            this.tabPage2.Controls.Add(this.panel15);
            this.tabPage2.Controls.Add(this.bunifuImageButton1);
            this.tabPage2.Controls.Add(this.panel14);
            this.tabPage2.Controls.Add(this.bunifuFlatButton20);
            this.tabPage2.Controls.Add(this.chart1);
            this.bunifuTransition2.SetDecoration(this.tabPage2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabPage2, BunifuAnimatorNS.DecorationType.None);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(960, 730);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Temperature";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel16.Controls.Add(this.label44);
            this.panel16.Controls.Add(this.label9);
            this.bunifuTransition2.SetDecoration(this.panel16, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel16, BunifuAnimatorNS.DecorationType.None);
            this.panel16.Location = new System.Drawing.Point(14, 573);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(218, 115);
            this.panel16.TabIndex = 10;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label44, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label44, BunifuAnimatorNS.DecorationType.None);
            this.label44.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(134, 47);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(22, 25);
            this.label44.TabIndex = 5;
            this.label44.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label9, BunifuAnimatorNS.DecorationType.None);
            this.label9.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(14, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 35);
            this.label9.TabIndex = 4;
            this.label9.Text = "Value:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel15.Controls.Add(this.label15);
            this.panel15.Controls.Add(this.label14);
            this.panel15.Controls.Add(this.label13);
            this.panel15.Controls.Add(this.label12);
            this.panel15.Controls.Add(this.bunifuCheckbox4);
            this.panel15.Controls.Add(this.bunifuCheckbox3);
            this.panel15.Controls.Add(this.bunifuCheckbox2);
            this.panel15.Controls.Add(this.bunifuCheckbox1);
            this.panel15.Controls.Add(this.bunifuTextbox3);
            this.panel15.Controls.Add(this.bunifuTextbox2);
            this.bunifuTransition2.SetDecoration(this.panel15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel15, BunifuAnimatorNS.DecorationType.None);
            this.panel15.Location = new System.Drawing.Point(238, 573);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(380, 115);
            this.panel15.TabIndex = 9;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label15, BunifuAnimatorNS.DecorationType.None);
            this.label15.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(60, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 18);
            this.label15.TabIndex = 9;
            this.label15.Text = "Auto";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label14, BunifuAnimatorNS.DecorationType.None);
            this.label14.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(168, 75);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 18);
            this.label14.TabIndex = 8;
            this.label14.Text = "Manual";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label13, BunifuAnimatorNS.DecorationType.None);
            this.label13.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(168, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 18);
            this.label13.TabIndex = 7;
            this.label13.Text = "Manual";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label12, BunifuAnimatorNS.DecorationType.None);
            this.label12.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(60, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 18);
            this.label12.TabIndex = 6;
            this.label12.Text = "Auto";
            // 
            // bunifuCheckbox4
            // 
            this.bunifuCheckbox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox4.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox4.Checked = true;
            this.bunifuCheckbox4.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox4.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox4.Location = new System.Drawing.Point(144, 23);
            this.bunifuCheckbox4.Name = "bunifuCheckbox4";
            this.bunifuCheckbox4.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox4.TabIndex = 5;
            // 
            // bunifuCheckbox3
            // 
            this.bunifuCheckbox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox3.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox3.Checked = true;
            this.bunifuCheckbox3.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox3.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox3.Location = new System.Drawing.Point(144, 75);
            this.bunifuCheckbox3.Name = "bunifuCheckbox3";
            this.bunifuCheckbox3.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox3.TabIndex = 4;
            // 
            // bunifuCheckbox2
            // 
            this.bunifuCheckbox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox2.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox2.Checked = true;
            this.bunifuCheckbox2.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox2.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox2.Location = new System.Drawing.Point(34, 75);
            this.bunifuCheckbox2.Name = "bunifuCheckbox2";
            this.bunifuCheckbox2.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox2.TabIndex = 3;
            // 
            // bunifuCheckbox1
            // 
            this.bunifuCheckbox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox1.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox1.Checked = true;
            this.bunifuCheckbox1.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox1.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox1.Location = new System.Drawing.Point(34, 23);
            this.bunifuCheckbox1.Name = "bunifuCheckbox1";
            this.bunifuCheckbox1.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox1.TabIndex = 2;
            // 
            // bunifuTextbox3
            // 
            this.bunifuTextbox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox3.BackgroundImage")));
            this.bunifuTextbox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox3.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox3.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox3.Icon")));
            this.bunifuTextbox3.Location = new System.Drawing.Point(234, 65);
            this.bunifuTextbox3.Name = "bunifuTextbox3";
            this.bunifuTextbox3.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox3.TabIndex = 1;
            this.bunifuTextbox3.text = "";
            // 
            // bunifuTextbox2
            // 
            this.bunifuTextbox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox2.BackgroundImage")));
            this.bunifuTextbox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox2.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox2.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox2.Icon")));
            this.bunifuTextbox2.Location = new System.Drawing.Point(234, 19);
            this.bunifuTextbox2.Name = "bunifuTextbox2";
            this.bunifuTextbox2.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox2.TabIndex = 0;
            this.bunifuTextbox2.text = "";
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTransition2.SetDecoration(this.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(624, 573);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(115, 115);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.bunifuImageButton1.TabIndex = 9;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 3;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel14.Controls.Add(this.bunifuSwitch3);
            this.panel14.Controls.Add(this.label11);
            this.panel14.Controls.Add(this.bunifuSwitch4);
            this.panel14.Controls.Add(this.label10);
            this.bunifuTransition2.SetDecoration(this.panel14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel14, BunifuAnimatorNS.DecorationType.None);
            this.panel14.Location = new System.Drawing.Point(745, 573);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(200, 115);
            this.panel14.TabIndex = 8;
            // 
            // bunifuSwitch3
            // 
            this.bunifuSwitch3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch3.BorderRadius = 0;
            this.bunifuSwitch3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch3.Location = new System.Drawing.Point(129, 23);
            this.bunifuSwitch3.Name = "bunifuSwitch3";
            this.bunifuSwitch3.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch3.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch3.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch3.TabIndex = 3;
            this.bunifuSwitch3.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch3.Value = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label11, BunifuAnimatorNS.DecorationType.None);
            this.label11.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(17, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 18);
            this.label11.TabIndex = 7;
            this.label11.Text = "Show labels";
            // 
            // bunifuSwitch4
            // 
            this.bunifuSwitch4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch4.BorderRadius = 0;
            this.bunifuSwitch4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch4.Location = new System.Drawing.Point(129, 70);
            this.bunifuSwitch4.Name = "bunifuSwitch4";
            this.bunifuSwitch4.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch4.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch4.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch4.TabIndex = 5;
            this.bunifuSwitch4.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch4.Value = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label10, BunifuAnimatorNS.DecorationType.None);
            this.label10.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(17, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 18);
            this.label10.TabIndex = 6;
            this.label10.Text = "Show grid";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // bunifuFlatButton20
            // 
            this.bunifuFlatButton20.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton20.BorderRadius = 0;
            this.bunifuFlatButton20.ButtonText = "";
            this.bunifuFlatButton20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton20, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton20, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton20.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton20.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton20.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton20.Iconimage")));
            this.bunifuFlatButton20.Iconimage_right = null;
            this.bunifuFlatButton20.Iconimage_right_Selected = null;
            this.bunifuFlatButton20.Iconimage_Selected = null;
            this.bunifuFlatButton20.IconMarginLeft = 0;
            this.bunifuFlatButton20.IconMarginRight = 0;
            this.bunifuFlatButton20.IconRightVisible = false;
            this.bunifuFlatButton20.IconRightZoom = 0D;
            this.bunifuFlatButton20.IconVisible = false;
            this.bunifuFlatButton20.IconZoom = 40D;
            this.bunifuFlatButton20.IsTab = false;
            this.bunifuFlatButton20.Location = new System.Drawing.Point(5, 1);
            this.bunifuFlatButton20.Name = "bunifuFlatButton20";
            this.bunifuFlatButton20.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton20.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton20.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton20.selected = false;
            this.bunifuFlatButton20.Size = new System.Drawing.Size(50, 48);
            this.bunifuFlatButton20.TabIndex = 2;
            this.bunifuFlatButton20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton20.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton20.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton20.Click += new System.EventHandler(this.bunifuFlatButton20_Click);
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.chart1.BackSecondaryColor = System.Drawing.Color.White;
            this.chart1.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea31.AxisX.InterlacedColor = System.Drawing.Color.Green;
            chartArea31.AxisX.LineColor = System.Drawing.Color.Gray;
            chartArea31.AxisX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea31.AxisX.TitleForeColor = System.Drawing.Color.DarkGray;
            chartArea31.AxisX2.LineColor = System.Drawing.Color.Gray;
            chartArea31.AxisX2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea31.AxisX2.LineWidth = 5;
            chartArea31.AxisY.LineColor = System.Drawing.Color.Gray;
            chartArea31.AxisY.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea31.AxisY.LineWidth = 5;
            chartArea31.AxisY.Maximum = 50D;
            chartArea31.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea31.AxisY2.LineColor = System.Drawing.Color.Gray;
            chartArea31.AxisY2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea31.AxisY2.LineWidth = 5;
            chartArea31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            chartArea31.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea31.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea31);
            this.bunifuTransition2.SetDecoration(this.chart1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.chart1, BunifuAnimatorNS.DecorationType.None);
            legend31.BackColor = System.Drawing.Color.Transparent;
            legend31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            legend31.InterlacedRowsColor = System.Drawing.Color.White;
            legend31.Name = "Legend1";
            this.chart1.Legends.Add(legend31);
            this.chart1.Location = new System.Drawing.Point(6, 0);
            this.chart1.Name = "chart1";
            series49.ChartArea = "ChartArea1";
            series49.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series49.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            series49.LabelBackColor = System.Drawing.Color.Transparent;
            series49.Legend = "Legend1";
            series49.MarkerSize = 8;
            series49.MarkerStep = 7;
            series49.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series49.Name = "Temperature";
            this.chart1.Series.Add(series49);
            this.chart1.Size = new System.Drawing.Size(951, 496);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.tabPage3.Controls.Add(this.bunifuFlatButton23);
            this.tabPage3.Controls.Add(this.panel17);
            this.tabPage3.Controls.Add(this.panel18);
            this.tabPage3.Controls.Add(this.bunifuImageButton2);
            this.tabPage3.Controls.Add(this.panel19);
            this.tabPage3.Controls.Add(this.chart2);
            this.bunifuTransition2.SetDecoration(this.tabPage3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabPage3, BunifuAnimatorNS.DecorationType.None);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(960, 730);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Turbidity";
            // 
            // bunifuFlatButton23
            // 
            this.bunifuFlatButton23.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton23.BorderRadius = 0;
            this.bunifuFlatButton23.ButtonText = "";
            this.bunifuFlatButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton23, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton23, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton23.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton23.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton23.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton23.Iconimage")));
            this.bunifuFlatButton23.Iconimage_right = null;
            this.bunifuFlatButton23.Iconimage_right_Selected = null;
            this.bunifuFlatButton23.Iconimage_Selected = null;
            this.bunifuFlatButton23.IconMarginLeft = 0;
            this.bunifuFlatButton23.IconMarginRight = 0;
            this.bunifuFlatButton23.IconRightVisible = false;
            this.bunifuFlatButton23.IconRightZoom = 0D;
            this.bunifuFlatButton23.IconVisible = false;
            this.bunifuFlatButton23.IconZoom = 40D;
            this.bunifuFlatButton23.IsTab = false;
            this.bunifuFlatButton23.Location = new System.Drawing.Point(5, 1);
            this.bunifuFlatButton23.Name = "bunifuFlatButton23";
            this.bunifuFlatButton23.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton23.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton23.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton23.selected = false;
            this.bunifuFlatButton23.Size = new System.Drawing.Size(50, 48);
            this.bunifuFlatButton23.TabIndex = 16;
            this.bunifuFlatButton23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton23.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton23.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton23.Click += new System.EventHandler(this.bunifuFlatButton23_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel17.Controls.Add(this.label45);
            this.panel17.Controls.Add(this.label16);
            this.bunifuTransition2.SetDecoration(this.panel17, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel17, BunifuAnimatorNS.DecorationType.None);
            this.panel17.Location = new System.Drawing.Point(14, 573);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(218, 115);
            this.panel17.TabIndex = 15;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label45, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label45, BunifuAnimatorNS.DecorationType.None);
            this.label45.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(134, 47);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(22, 25);
            this.label45.TabIndex = 6;
            this.label45.Text = "-";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label16, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label16, BunifuAnimatorNS.DecorationType.None);
            this.label16.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(14, 39);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(108, 35);
            this.label16.TabIndex = 4;
            this.label16.Text = "Value:";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel18.Controls.Add(this.label17);
            this.panel18.Controls.Add(this.label18);
            this.panel18.Controls.Add(this.label19);
            this.panel18.Controls.Add(this.label20);
            this.panel18.Controls.Add(this.bunifuCheckbox5);
            this.panel18.Controls.Add(this.bunifuCheckbox6);
            this.panel18.Controls.Add(this.bunifuCheckbox7);
            this.panel18.Controls.Add(this.bunifuCheckbox8);
            this.panel18.Controls.Add(this.bunifuTextbox4);
            this.panel18.Controls.Add(this.bunifuTextbox5);
            this.bunifuTransition2.SetDecoration(this.panel18, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel18, BunifuAnimatorNS.DecorationType.None);
            this.panel18.Location = new System.Drawing.Point(238, 573);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(380, 115);
            this.panel18.TabIndex = 13;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label17, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label17, BunifuAnimatorNS.DecorationType.None);
            this.label17.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(60, 75);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 18);
            this.label17.TabIndex = 9;
            this.label17.Text = "Auto";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label18, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label18, BunifuAnimatorNS.DecorationType.None);
            this.label18.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(168, 75);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 18);
            this.label18.TabIndex = 8;
            this.label18.Text = "Manual";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label19, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label19, BunifuAnimatorNS.DecorationType.None);
            this.label19.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(168, 24);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(60, 18);
            this.label19.TabIndex = 7;
            this.label19.Text = "Manual";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label20, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label20, BunifuAnimatorNS.DecorationType.None);
            this.label20.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(60, 23);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 18);
            this.label20.TabIndex = 6;
            this.label20.Text = "Auto";
            // 
            // bunifuCheckbox5
            // 
            this.bunifuCheckbox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox5.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox5.Checked = true;
            this.bunifuCheckbox5.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox5.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox5.Location = new System.Drawing.Point(144, 23);
            this.bunifuCheckbox5.Name = "bunifuCheckbox5";
            this.bunifuCheckbox5.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox5.TabIndex = 5;
            // 
            // bunifuCheckbox6
            // 
            this.bunifuCheckbox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox6.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox6.Checked = true;
            this.bunifuCheckbox6.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox6.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox6.Location = new System.Drawing.Point(144, 75);
            this.bunifuCheckbox6.Name = "bunifuCheckbox6";
            this.bunifuCheckbox6.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox6.TabIndex = 4;
            // 
            // bunifuCheckbox7
            // 
            this.bunifuCheckbox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox7.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox7.Checked = true;
            this.bunifuCheckbox7.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox7.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox7.Location = new System.Drawing.Point(34, 75);
            this.bunifuCheckbox7.Name = "bunifuCheckbox7";
            this.bunifuCheckbox7.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox7.TabIndex = 3;
            // 
            // bunifuCheckbox8
            // 
            this.bunifuCheckbox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox8.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox8.Checked = true;
            this.bunifuCheckbox8.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox8.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox8.Location = new System.Drawing.Point(34, 23);
            this.bunifuCheckbox8.Name = "bunifuCheckbox8";
            this.bunifuCheckbox8.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox8.TabIndex = 2;
            // 
            // bunifuTextbox4
            // 
            this.bunifuTextbox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox4.BackgroundImage")));
            this.bunifuTextbox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox4.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox4.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox4.Icon")));
            this.bunifuTextbox4.Location = new System.Drawing.Point(234, 65);
            this.bunifuTextbox4.Name = "bunifuTextbox4";
            this.bunifuTextbox4.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox4.TabIndex = 1;
            this.bunifuTextbox4.text = "";
            // 
            // bunifuTextbox5
            // 
            this.bunifuTextbox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox5.BackgroundImage")));
            this.bunifuTextbox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox5.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox5.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox5.Icon")));
            this.bunifuTextbox5.Location = new System.Drawing.Point(234, 19);
            this.bunifuTextbox5.Name = "bunifuTextbox5";
            this.bunifuTextbox5.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox5.TabIndex = 0;
            this.bunifuTextbox5.text = "";
            this.bunifuTextbox5.OnTextChange += new System.EventHandler(this.bunifuTextbox5_OnTextChange);
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTransition2.SetDecoration(this.bunifuImageButton2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuImageButton2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(624, 573);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(115, 115);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.bunifuImageButton2.TabIndex = 14;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 3;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel19.Controls.Add(this.bunifuSwitch5);
            this.panel19.Controls.Add(this.label21);
            this.panel19.Controls.Add(this.bunifuSwitch6);
            this.panel19.Controls.Add(this.label22);
            this.bunifuTransition2.SetDecoration(this.panel19, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel19, BunifuAnimatorNS.DecorationType.None);
            this.panel19.Location = new System.Drawing.Point(745, 573);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(200, 115);
            this.panel19.TabIndex = 12;
            // 
            // bunifuSwitch5
            // 
            this.bunifuSwitch5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch5.BorderRadius = 0;
            this.bunifuSwitch5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch5.Location = new System.Drawing.Point(129, 23);
            this.bunifuSwitch5.Name = "bunifuSwitch5";
            this.bunifuSwitch5.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch5.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch5.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch5.TabIndex = 3;
            this.bunifuSwitch5.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch5.Value = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label21, BunifuAnimatorNS.DecorationType.None);
            this.label21.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(17, 70);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 18);
            this.label21.TabIndex = 7;
            this.label21.Text = "Show labels";
            // 
            // bunifuSwitch6
            // 
            this.bunifuSwitch6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch6.BorderRadius = 0;
            this.bunifuSwitch6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch6.Location = new System.Drawing.Point(129, 70);
            this.bunifuSwitch6.Name = "bunifuSwitch6";
            this.bunifuSwitch6.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch6.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch6.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch6.TabIndex = 5;
            this.bunifuSwitch6.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch6.Value = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label22, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label22, BunifuAnimatorNS.DecorationType.None);
            this.label22.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(17, 24);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 18);
            this.label22.TabIndex = 6;
            this.label22.Text = "Show grid";
            // 
            // chart2
            // 
            this.chart2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.chart2.BackSecondaryColor = System.Drawing.Color.White;
            this.chart2.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea32.AxisX.InterlacedColor = System.Drawing.Color.Green;
            chartArea32.AxisX.LineColor = System.Drawing.Color.Gray;
            chartArea32.AxisX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea32.AxisX.TitleForeColor = System.Drawing.Color.DarkGray;
            chartArea32.AxisX2.LineColor = System.Drawing.Color.Gray;
            chartArea32.AxisX2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea32.AxisX2.LineWidth = 5;
            chartArea32.AxisY.LineColor = System.Drawing.Color.Gray;
            chartArea32.AxisY.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea32.AxisY.LineWidth = 5;
            chartArea32.AxisY.Maximum = 160D;
            chartArea32.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea32.AxisY2.LineColor = System.Drawing.Color.Gray;
            chartArea32.AxisY2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea32.AxisY2.LineWidth = 5;
            chartArea32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            chartArea32.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea32.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea32);
            this.bunifuTransition2.SetDecoration(this.chart2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.chart2, BunifuAnimatorNS.DecorationType.None);
            legend32.BackColor = System.Drawing.Color.Transparent;
            legend32.BorderColor = System.Drawing.Color.Transparent;
            legend32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            legend32.InterlacedRowsColor = System.Drawing.Color.White;
            legend32.Name = "Legend1";
            this.chart2.Legends.Add(legend32);
            this.chart2.Location = new System.Drawing.Point(6, 0);
            this.chart2.Name = "chart2";
            series50.ChartArea = "ChartArea1";
            series50.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series50.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            series50.LabelBackColor = System.Drawing.Color.White;
            series50.Legend = "Legend1";
            series50.MarkerSize = 8;
            series50.MarkerStep = 7;
            series50.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series50.Name = "Turbidity";
            this.chart2.Series.Add(series50);
            this.chart2.Size = new System.Drawing.Size(951, 496);
            this.chart2.TabIndex = 11;
            this.chart2.Text = "chart2";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.tabPage4.Controls.Add(this.bunifuFlatButton24);
            this.tabPage4.Controls.Add(this.panel20);
            this.tabPage4.Controls.Add(this.panel21);
            this.tabPage4.Controls.Add(this.bunifuImageButton3);
            this.tabPage4.Controls.Add(this.panel22);
            this.tabPage4.Controls.Add(this.chart3);
            this.bunifuTransition2.SetDecoration(this.tabPage4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabPage4, BunifuAnimatorNS.DecorationType.None);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(960, 730);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "pH";
            // 
            // bunifuFlatButton24
            // 
            this.bunifuFlatButton24.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton24.BorderRadius = 0;
            this.bunifuFlatButton24.ButtonText = "";
            this.bunifuFlatButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton24, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton24, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton24.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton24.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton24.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton24.Iconimage")));
            this.bunifuFlatButton24.Iconimage_right = null;
            this.bunifuFlatButton24.Iconimage_right_Selected = null;
            this.bunifuFlatButton24.Iconimage_Selected = null;
            this.bunifuFlatButton24.IconMarginLeft = 0;
            this.bunifuFlatButton24.IconMarginRight = 0;
            this.bunifuFlatButton24.IconRightVisible = false;
            this.bunifuFlatButton24.IconRightZoom = 0D;
            this.bunifuFlatButton24.IconVisible = false;
            this.bunifuFlatButton24.IconZoom = 40D;
            this.bunifuFlatButton24.IsTab = false;
            this.bunifuFlatButton24.Location = new System.Drawing.Point(5, 1);
            this.bunifuFlatButton24.Name = "bunifuFlatButton24";
            this.bunifuFlatButton24.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton24.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton24.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton24.selected = false;
            this.bunifuFlatButton24.Size = new System.Drawing.Size(50, 48);
            this.bunifuFlatButton24.TabIndex = 21;
            this.bunifuFlatButton24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton24.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton24.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton24.Click += new System.EventHandler(this.bunifuFlatButton24_Click);
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel20.Controls.Add(this.label46);
            this.panel20.Controls.Add(this.label23);
            this.bunifuTransition2.SetDecoration(this.panel20, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel20, BunifuAnimatorNS.DecorationType.None);
            this.panel20.Location = new System.Drawing.Point(14, 573);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(218, 115);
            this.panel20.TabIndex = 20;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label46, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label46, BunifuAnimatorNS.DecorationType.None);
            this.label46.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(134, 47);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(22, 25);
            this.label46.TabIndex = 6;
            this.label46.Text = "-";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label23, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label23, BunifuAnimatorNS.DecorationType.None);
            this.label23.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(14, 39);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(108, 35);
            this.label23.TabIndex = 4;
            this.label23.Text = "Value:";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel21.Controls.Add(this.label24);
            this.panel21.Controls.Add(this.label25);
            this.panel21.Controls.Add(this.label26);
            this.panel21.Controls.Add(this.label27);
            this.panel21.Controls.Add(this.bunifuCheckbox9);
            this.panel21.Controls.Add(this.bunifuCheckbox10);
            this.panel21.Controls.Add(this.bunifuCheckbox11);
            this.panel21.Controls.Add(this.bunifuCheckbox12);
            this.panel21.Controls.Add(this.bunifuTextbox6);
            this.panel21.Controls.Add(this.bunifuTextbox7);
            this.bunifuTransition2.SetDecoration(this.panel21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel21, BunifuAnimatorNS.DecorationType.None);
            this.panel21.Location = new System.Drawing.Point(238, 573);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(380, 115);
            this.panel21.TabIndex = 18;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label24, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label24, BunifuAnimatorNS.DecorationType.None);
            this.label24.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(60, 75);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 18);
            this.label24.TabIndex = 9;
            this.label24.Text = "Auto";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label25, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label25, BunifuAnimatorNS.DecorationType.None);
            this.label25.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(168, 75);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 18);
            this.label25.TabIndex = 8;
            this.label25.Text = "Manual";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label26, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label26, BunifuAnimatorNS.DecorationType.None);
            this.label26.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(168, 24);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 18);
            this.label26.TabIndex = 7;
            this.label26.Text = "Manual";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label27, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label27, BunifuAnimatorNS.DecorationType.None);
            this.label27.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(60, 23);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(43, 18);
            this.label27.TabIndex = 6;
            this.label27.Text = "Auto";
            // 
            // bunifuCheckbox9
            // 
            this.bunifuCheckbox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox9.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox9.Checked = true;
            this.bunifuCheckbox9.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox9.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox9.Location = new System.Drawing.Point(144, 23);
            this.bunifuCheckbox9.Name = "bunifuCheckbox9";
            this.bunifuCheckbox9.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox9.TabIndex = 5;
            // 
            // bunifuCheckbox10
            // 
            this.bunifuCheckbox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox10.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox10.Checked = true;
            this.bunifuCheckbox10.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox10.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox10.Location = new System.Drawing.Point(144, 75);
            this.bunifuCheckbox10.Name = "bunifuCheckbox10";
            this.bunifuCheckbox10.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox10.TabIndex = 4;
            // 
            // bunifuCheckbox11
            // 
            this.bunifuCheckbox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox11.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox11.Checked = true;
            this.bunifuCheckbox11.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox11.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox11.Location = new System.Drawing.Point(34, 75);
            this.bunifuCheckbox11.Name = "bunifuCheckbox11";
            this.bunifuCheckbox11.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox11.TabIndex = 3;
            // 
            // bunifuCheckbox12
            // 
            this.bunifuCheckbox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox12.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox12.Checked = true;
            this.bunifuCheckbox12.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox12.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox12.Location = new System.Drawing.Point(34, 23);
            this.bunifuCheckbox12.Name = "bunifuCheckbox12";
            this.bunifuCheckbox12.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox12.TabIndex = 2;
            // 
            // bunifuTextbox6
            // 
            this.bunifuTextbox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox6.BackgroundImage")));
            this.bunifuTextbox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox6.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox6.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox6.Icon")));
            this.bunifuTextbox6.Location = new System.Drawing.Point(234, 65);
            this.bunifuTextbox6.Name = "bunifuTextbox6";
            this.bunifuTextbox6.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox6.TabIndex = 1;
            this.bunifuTextbox6.text = "";
            // 
            // bunifuTextbox7
            // 
            this.bunifuTextbox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox7.BackgroundImage")));
            this.bunifuTextbox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox7.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox7.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox7.Icon")));
            this.bunifuTextbox7.Location = new System.Drawing.Point(234, 19);
            this.bunifuTextbox7.Name = "bunifuTextbox7";
            this.bunifuTextbox7.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox7.TabIndex = 0;
            this.bunifuTextbox7.text = "";
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTransition2.SetDecoration(this.bunifuImageButton3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuImageButton3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.Image")));
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.Location = new System.Drawing.Point(624, 573);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(115, 115);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.bunifuImageButton3.TabIndex = 19;
            this.bunifuImageButton3.TabStop = false;
            this.bunifuImageButton3.Zoom = 3;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel22.Controls.Add(this.bunifuSwitch7);
            this.panel22.Controls.Add(this.label28);
            this.panel22.Controls.Add(this.bunifuSwitch8);
            this.panel22.Controls.Add(this.label29);
            this.bunifuTransition2.SetDecoration(this.panel22, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel22, BunifuAnimatorNS.DecorationType.None);
            this.panel22.Location = new System.Drawing.Point(745, 573);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(200, 115);
            this.panel22.TabIndex = 17;
            // 
            // bunifuSwitch7
            // 
            this.bunifuSwitch7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch7.BorderRadius = 0;
            this.bunifuSwitch7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch7.Location = new System.Drawing.Point(129, 23);
            this.bunifuSwitch7.Name = "bunifuSwitch7";
            this.bunifuSwitch7.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch7.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch7.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch7.TabIndex = 3;
            this.bunifuSwitch7.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch7.Value = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label28, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label28, BunifuAnimatorNS.DecorationType.None);
            this.label28.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(17, 70);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(96, 18);
            this.label28.TabIndex = 7;
            this.label28.Text = "Show labels";
            // 
            // bunifuSwitch8
            // 
            this.bunifuSwitch8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch8.BorderRadius = 0;
            this.bunifuSwitch8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch8.Location = new System.Drawing.Point(129, 70);
            this.bunifuSwitch8.Name = "bunifuSwitch8";
            this.bunifuSwitch8.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch8.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch8.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch8.TabIndex = 5;
            this.bunifuSwitch8.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch8.Value = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label29, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label29, BunifuAnimatorNS.DecorationType.None);
            this.label29.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(17, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(82, 18);
            this.label29.TabIndex = 6;
            this.label29.Text = "Show grid";
            // 
            // chart3
            // 
            this.chart3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.chart3.BackSecondaryColor = System.Drawing.Color.White;
            this.chart3.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea33.AxisX.InterlacedColor = System.Drawing.Color.Green;
            chartArea33.AxisX.LineColor = System.Drawing.Color.Gray;
            chartArea33.AxisX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea33.AxisX.TitleForeColor = System.Drawing.Color.DarkGray;
            chartArea33.AxisX2.LineColor = System.Drawing.Color.Gray;
            chartArea33.AxisX2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea33.AxisX2.LineWidth = 5;
            chartArea33.AxisY.LineColor = System.Drawing.Color.Gray;
            chartArea33.AxisY.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea33.AxisY.LineWidth = 5;
            chartArea33.AxisY.Maximum = 50D;
            chartArea33.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea33.AxisY2.LineColor = System.Drawing.Color.Gray;
            chartArea33.AxisY2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea33.AxisY2.LineWidth = 5;
            chartArea33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            chartArea33.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea33.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea33);
            this.bunifuTransition2.SetDecoration(this.chart3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.chart3, BunifuAnimatorNS.DecorationType.None);
            legend33.BackColor = System.Drawing.Color.Transparent;
            legend33.ForeColor = System.Drawing.Color.RoyalBlue;
            legend33.InterlacedRowsColor = System.Drawing.Color.White;
            legend33.Name = "Legend1";
            this.chart3.Legends.Add(legend33);
            this.chart3.Location = new System.Drawing.Point(6, 0);
            this.chart3.Name = "chart3";
            series51.ChartArea = "ChartArea1";
            series51.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series51.Color = System.Drawing.Color.RoyalBlue;
            series51.LabelBackColor = System.Drawing.Color.White;
            series51.Legend = "Legend1";
            series51.MarkerSize = 8;
            series51.MarkerStep = 7;
            series51.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series51.Name = "pH";
            this.chart3.Series.Add(series51);
            this.chart3.Size = new System.Drawing.Size(951, 496);
            this.chart3.TabIndex = 16;
            this.chart3.Text = "chart3";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.tabPage5.Controls.Add(this.bunifuFlatButton25);
            this.tabPage5.Controls.Add(this.panel23);
            this.tabPage5.Controls.Add(this.panel24);
            this.tabPage5.Controls.Add(this.bunifuImageButton4);
            this.tabPage5.Controls.Add(this.panel25);
            this.tabPage5.Controls.Add(this.chart4);
            this.bunifuTransition2.SetDecoration(this.tabPage5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabPage5, BunifuAnimatorNS.DecorationType.None);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(960, 730);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "El. conductivity";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // bunifuFlatButton25
            // 
            this.bunifuFlatButton25.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton25.BorderRadius = 0;
            this.bunifuFlatButton25.ButtonText = "";
            this.bunifuFlatButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton25, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton25, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton25.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton25.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton25.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton25.Iconimage")));
            this.bunifuFlatButton25.Iconimage_right = null;
            this.bunifuFlatButton25.Iconimage_right_Selected = null;
            this.bunifuFlatButton25.Iconimage_Selected = null;
            this.bunifuFlatButton25.IconMarginLeft = 0;
            this.bunifuFlatButton25.IconMarginRight = 0;
            this.bunifuFlatButton25.IconRightVisible = false;
            this.bunifuFlatButton25.IconRightZoom = 0D;
            this.bunifuFlatButton25.IconVisible = false;
            this.bunifuFlatButton25.IconZoom = 40D;
            this.bunifuFlatButton25.IsTab = false;
            this.bunifuFlatButton25.Location = new System.Drawing.Point(5, 1);
            this.bunifuFlatButton25.Name = "bunifuFlatButton25";
            this.bunifuFlatButton25.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton25.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton25.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton25.selected = false;
            this.bunifuFlatButton25.Size = new System.Drawing.Size(50, 48);
            this.bunifuFlatButton25.TabIndex = 26;
            this.bunifuFlatButton25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton25.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton25.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton25.Click += new System.EventHandler(this.bunifuFlatButton25_Click);
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel23.Controls.Add(this.label30);
            this.bunifuTransition2.SetDecoration(this.panel23, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel23, BunifuAnimatorNS.DecorationType.None);
            this.panel23.Location = new System.Drawing.Point(14, 573);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(218, 115);
            this.panel23.TabIndex = 25;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label30, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label30, BunifuAnimatorNS.DecorationType.None);
            this.label30.Font = new System.Drawing.Font("Verdana", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(14, 39);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(108, 35);
            this.label30.TabIndex = 4;
            this.label30.Text = "Value:";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel24.Controls.Add(this.label31);
            this.panel24.Controls.Add(this.label32);
            this.panel24.Controls.Add(this.label33);
            this.panel24.Controls.Add(this.label34);
            this.panel24.Controls.Add(this.bunifuCheckbox13);
            this.panel24.Controls.Add(this.bunifuCheckbox14);
            this.panel24.Controls.Add(this.bunifuCheckbox15);
            this.panel24.Controls.Add(this.bunifuCheckbox16);
            this.panel24.Controls.Add(this.bunifuTextbox8);
            this.panel24.Controls.Add(this.bunifuTextbox9);
            this.bunifuTransition2.SetDecoration(this.panel24, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel24, BunifuAnimatorNS.DecorationType.None);
            this.panel24.Location = new System.Drawing.Point(238, 573);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(380, 115);
            this.panel24.TabIndex = 23;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label31, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label31, BunifuAnimatorNS.DecorationType.None);
            this.label31.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(60, 75);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(43, 18);
            this.label31.TabIndex = 9;
            this.label31.Text = "Auto";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label32, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label32, BunifuAnimatorNS.DecorationType.None);
            this.label32.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(168, 75);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 18);
            this.label32.TabIndex = 8;
            this.label32.Text = "Manual";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label33, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label33, BunifuAnimatorNS.DecorationType.None);
            this.label33.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(168, 24);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(60, 18);
            this.label33.TabIndex = 7;
            this.label33.Text = "Manual";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label34, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label34, BunifuAnimatorNS.DecorationType.None);
            this.label34.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(60, 23);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(43, 18);
            this.label34.TabIndex = 6;
            this.label34.Text = "Auto";
            // 
            // bunifuCheckbox13
            // 
            this.bunifuCheckbox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox13.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox13.Checked = true;
            this.bunifuCheckbox13.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox13, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox13.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox13.Location = new System.Drawing.Point(144, 23);
            this.bunifuCheckbox13.Name = "bunifuCheckbox13";
            this.bunifuCheckbox13.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox13.TabIndex = 5;
            // 
            // bunifuCheckbox14
            // 
            this.bunifuCheckbox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox14.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox14.Checked = true;
            this.bunifuCheckbox14.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox14, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox14.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox14.Location = new System.Drawing.Point(144, 75);
            this.bunifuCheckbox14.Name = "bunifuCheckbox14";
            this.bunifuCheckbox14.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox14.TabIndex = 4;
            // 
            // bunifuCheckbox15
            // 
            this.bunifuCheckbox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox15.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox15.Checked = true;
            this.bunifuCheckbox15.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox15.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox15.Location = new System.Drawing.Point(34, 75);
            this.bunifuCheckbox15.Name = "bunifuCheckbox15";
            this.bunifuCheckbox15.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox15.TabIndex = 3;
            // 
            // bunifuCheckbox16
            // 
            this.bunifuCheckbox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox16.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox16.Checked = true;
            this.bunifuCheckbox16.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox16, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox16, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox16.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox16.Location = new System.Drawing.Point(34, 23);
            this.bunifuCheckbox16.Name = "bunifuCheckbox16";
            this.bunifuCheckbox16.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox16.TabIndex = 2;
            // 
            // bunifuTextbox8
            // 
            this.bunifuTextbox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox8.BackgroundImage")));
            this.bunifuTextbox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox8.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox8.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox8.Icon")));
            this.bunifuTextbox8.Location = new System.Drawing.Point(234, 65);
            this.bunifuTextbox8.Name = "bunifuTextbox8";
            this.bunifuTextbox8.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox8.TabIndex = 1;
            this.bunifuTextbox8.text = "";
            // 
            // bunifuTextbox9
            // 
            this.bunifuTextbox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox9.BackgroundImage")));
            this.bunifuTextbox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox9.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox9.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox9.Icon")));
            this.bunifuTextbox9.Location = new System.Drawing.Point(234, 19);
            this.bunifuTextbox9.Name = "bunifuTextbox9";
            this.bunifuTextbox9.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox9.TabIndex = 0;
            this.bunifuTextbox9.text = "";
            // 
            // bunifuImageButton4
            // 
            this.bunifuImageButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTransition2.SetDecoration(this.bunifuImageButton4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuImageButton4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton4.Image")));
            this.bunifuImageButton4.ImageActive = null;
            this.bunifuImageButton4.Location = new System.Drawing.Point(624, 573);
            this.bunifuImageButton4.Name = "bunifuImageButton4";
            this.bunifuImageButton4.Size = new System.Drawing.Size(115, 115);
            this.bunifuImageButton4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.bunifuImageButton4.TabIndex = 24;
            this.bunifuImageButton4.TabStop = false;
            this.bunifuImageButton4.Zoom = 3;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel25.Controls.Add(this.bunifuSwitch9);
            this.panel25.Controls.Add(this.label35);
            this.panel25.Controls.Add(this.bunifuSwitch10);
            this.panel25.Controls.Add(this.label36);
            this.bunifuTransition2.SetDecoration(this.panel25, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel25, BunifuAnimatorNS.DecorationType.None);
            this.panel25.Location = new System.Drawing.Point(745, 573);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(200, 115);
            this.panel25.TabIndex = 22;
            // 
            // bunifuSwitch9
            // 
            this.bunifuSwitch9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch9.BorderRadius = 0;
            this.bunifuSwitch9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch9, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch9.Location = new System.Drawing.Point(129, 23);
            this.bunifuSwitch9.Name = "bunifuSwitch9";
            this.bunifuSwitch9.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch9.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch9.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch9.TabIndex = 3;
            this.bunifuSwitch9.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch9.Value = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label35, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label35, BunifuAnimatorNS.DecorationType.None);
            this.label35.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(17, 70);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(96, 18);
            this.label35.TabIndex = 7;
            this.label35.Text = "Show labels";
            // 
            // bunifuSwitch10
            // 
            this.bunifuSwitch10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch10.BorderRadius = 0;
            this.bunifuSwitch10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch10.Location = new System.Drawing.Point(129, 70);
            this.bunifuSwitch10.Name = "bunifuSwitch10";
            this.bunifuSwitch10.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch10.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch10.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch10.TabIndex = 5;
            this.bunifuSwitch10.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch10.Value = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label36, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label36, BunifuAnimatorNS.DecorationType.None);
            this.label36.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(17, 24);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 18);
            this.label36.TabIndex = 6;
            this.label36.Text = "Show grid";
            // 
            // chart4
            // 
            this.chart4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.chart4.BackSecondaryColor = System.Drawing.Color.White;
            this.chart4.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea34.AxisX.InterlacedColor = System.Drawing.Color.Green;
            chartArea34.AxisX.LineColor = System.Drawing.Color.Gray;
            chartArea34.AxisX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea34.AxisX.TitleForeColor = System.Drawing.Color.DarkGray;
            chartArea34.AxisX2.LineColor = System.Drawing.Color.Gray;
            chartArea34.AxisX2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea34.AxisX2.LineWidth = 5;
            chartArea34.AxisY.LineColor = System.Drawing.Color.Gray;
            chartArea34.AxisY.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea34.AxisY.LineWidth = 5;
            chartArea34.AxisY.Maximum = 110D;
            chartArea34.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea34.AxisY2.LineColor = System.Drawing.Color.Gray;
            chartArea34.AxisY2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea34.AxisY2.LineWidth = 5;
            chartArea34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            chartArea34.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea34.Name = "ChartArea1";
            this.chart4.ChartAreas.Add(chartArea34);
            this.bunifuTransition2.SetDecoration(this.chart4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.chart4, BunifuAnimatorNS.DecorationType.None);
            legend34.BackColor = System.Drawing.Color.Transparent;
            legend34.ForeColor = System.Drawing.Color.DarkOrchid;
            legend34.InterlacedRowsColor = System.Drawing.Color.White;
            legend34.Name = "Legend1";
            this.chart4.Legends.Add(legend34);
            this.chart4.Location = new System.Drawing.Point(6, 0);
            this.chart4.Name = "chart4";
            series52.ChartArea = "ChartArea1";
            series52.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series52.Color = System.Drawing.Color.DarkOrchid;
            series52.LabelBackColor = System.Drawing.Color.White;
            series52.Legend = "Legend1";
            series52.MarkerSize = 8;
            series52.MarkerStep = 4;
            series52.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series52.Name = "ELC";
            this.chart4.Series.Add(series52);
            this.chart4.Size = new System.Drawing.Size(951, 496);
            this.chart4.TabIndex = 21;
            this.chart4.Text = "chart4";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.tabPage6.Controls.Add(this.bunifuFlatButton27);
            this.tabPage6.Controls.Add(this.panel26);
            this.tabPage6.Controls.Add(this.panel27);
            this.tabPage6.Controls.Add(this.bunifuImageButton5);
            this.tabPage6.Controls.Add(this.panel28);
            this.tabPage6.Controls.Add(this.chart5);
            this.bunifuTransition2.SetDecoration(this.tabPage6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.tabPage6, BunifuAnimatorNS.DecorationType.None);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(960, 730);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "All values";
            // 
            // bunifuFlatButton27
            // 
            this.bunifuFlatButton27.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton27.BorderRadius = 0;
            this.bunifuFlatButton27.ButtonText = "";
            this.bunifuFlatButton27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuFlatButton27, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuFlatButton27, BunifuAnimatorNS.DecorationType.None);
            this.bunifuFlatButton27.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton27.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton27.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton27.Iconimage")));
            this.bunifuFlatButton27.Iconimage_right = null;
            this.bunifuFlatButton27.Iconimage_right_Selected = null;
            this.bunifuFlatButton27.Iconimage_Selected = null;
            this.bunifuFlatButton27.IconMarginLeft = 0;
            this.bunifuFlatButton27.IconMarginRight = 0;
            this.bunifuFlatButton27.IconRightVisible = false;
            this.bunifuFlatButton27.IconRightZoom = 0D;
            this.bunifuFlatButton27.IconVisible = false;
            this.bunifuFlatButton27.IconZoom = 40D;
            this.bunifuFlatButton27.IsTab = false;
            this.bunifuFlatButton27.Location = new System.Drawing.Point(5, 1);
            this.bunifuFlatButton27.Name = "bunifuFlatButton27";
            this.bunifuFlatButton27.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton27.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuFlatButton27.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton27.selected = false;
            this.bunifuFlatButton27.Size = new System.Drawing.Size(50, 48);
            this.bunifuFlatButton27.TabIndex = 31;
            this.bunifuFlatButton27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton27.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton27.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton27.Click += new System.EventHandler(this.bunifuFlatButton27_Click);
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTransition2.SetDecoration(this.panel26, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel26, BunifuAnimatorNS.DecorationType.None);
            this.panel26.Location = new System.Drawing.Point(14, 573);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(218, 115);
            this.panel26.TabIndex = 30;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel27.Controls.Add(this.label38);
            this.panel27.Controls.Add(this.label39);
            this.panel27.Controls.Add(this.label40);
            this.panel27.Controls.Add(this.label41);
            this.panel27.Controls.Add(this.bunifuCheckbox17);
            this.panel27.Controls.Add(this.bunifuCheckbox18);
            this.panel27.Controls.Add(this.bunifuCheckbox19);
            this.panel27.Controls.Add(this.bunifuCheckbox20);
            this.panel27.Controls.Add(this.bunifuTextbox10);
            this.panel27.Controls.Add(this.bunifuTextbox11);
            this.bunifuTransition2.SetDecoration(this.panel27, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel27, BunifuAnimatorNS.DecorationType.None);
            this.panel27.Location = new System.Drawing.Point(238, 573);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(380, 115);
            this.panel27.TabIndex = 28;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label38, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label38, BunifuAnimatorNS.DecorationType.None);
            this.label38.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(60, 75);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(43, 18);
            this.label38.TabIndex = 9;
            this.label38.Text = "Auto";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label39, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label39, BunifuAnimatorNS.DecorationType.None);
            this.label39.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(168, 75);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(60, 18);
            this.label39.TabIndex = 8;
            this.label39.Text = "Manual";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label40, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label40, BunifuAnimatorNS.DecorationType.None);
            this.label40.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(168, 24);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(60, 18);
            this.label40.TabIndex = 7;
            this.label40.Text = "Manual";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label41, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label41, BunifuAnimatorNS.DecorationType.None);
            this.label41.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(60, 23);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(43, 18);
            this.label41.TabIndex = 6;
            this.label41.Text = "Auto";
            // 
            // bunifuCheckbox17
            // 
            this.bunifuCheckbox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox17.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox17.Checked = true;
            this.bunifuCheckbox17.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox17, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox17, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox17.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox17.Location = new System.Drawing.Point(144, 23);
            this.bunifuCheckbox17.Name = "bunifuCheckbox17";
            this.bunifuCheckbox17.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox17.TabIndex = 5;
            // 
            // bunifuCheckbox18
            // 
            this.bunifuCheckbox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox18.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox18.Checked = true;
            this.bunifuCheckbox18.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox18, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox18, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox18.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox18.Location = new System.Drawing.Point(144, 75);
            this.bunifuCheckbox18.Name = "bunifuCheckbox18";
            this.bunifuCheckbox18.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox18.TabIndex = 4;
            // 
            // bunifuCheckbox19
            // 
            this.bunifuCheckbox19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox19.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox19.Checked = true;
            this.bunifuCheckbox19.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox19, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox19, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox19.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox19.Location = new System.Drawing.Point(34, 75);
            this.bunifuCheckbox19.Name = "bunifuCheckbox19";
            this.bunifuCheckbox19.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox19.TabIndex = 3;
            // 
            // bunifuCheckbox20
            // 
            this.bunifuCheckbox20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuCheckbox20.ChechedOffColor = System.Drawing.Color.DarkOrchid;
            this.bunifuCheckbox20.Checked = true;
            this.bunifuCheckbox20.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.bunifuTransition1.SetDecoration(this.bunifuCheckbox20, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCheckbox20, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCheckbox20.ForeColor = System.Drawing.Color.White;
            this.bunifuCheckbox20.Location = new System.Drawing.Point(34, 23);
            this.bunifuCheckbox20.Name = "bunifuCheckbox20";
            this.bunifuCheckbox20.Size = new System.Drawing.Size(20, 20);
            this.bunifuCheckbox20.TabIndex = 2;
            // 
            // bunifuTextbox10
            // 
            this.bunifuTextbox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox10.BackgroundImage")));
            this.bunifuTextbox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox10, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox10.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox10.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox10.Icon")));
            this.bunifuTextbox10.Location = new System.Drawing.Point(234, 65);
            this.bunifuTextbox10.Name = "bunifuTextbox10";
            this.bunifuTextbox10.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox10.TabIndex = 1;
            this.bunifuTextbox10.text = "";
            // 
            // bunifuTextbox11
            // 
            this.bunifuTextbox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTextbox11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox11.BackgroundImage")));
            this.bunifuTextbox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuTransition2.SetDecoration(this.bunifuTextbox11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTextbox11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTextbox11.ForeColor = System.Drawing.Color.Silver;
            this.bunifuTextbox11.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuTextbox11.Icon")));
            this.bunifuTextbox11.Location = new System.Drawing.Point(234, 19);
            this.bunifuTextbox11.Name = "bunifuTextbox11";
            this.bunifuTextbox11.Size = new System.Drawing.Size(133, 30);
            this.bunifuTextbox11.TabIndex = 0;
            this.bunifuTextbox11.text = "";
            // 
            // bunifuImageButton5
            // 
            this.bunifuImageButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.bunifuTransition2.SetDecoration(this.bunifuImageButton5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuImageButton5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton5.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.Image")));
            this.bunifuImageButton5.ImageActive = null;
            this.bunifuImageButton5.Location = new System.Drawing.Point(624, 573);
            this.bunifuImageButton5.Name = "bunifuImageButton5";
            this.bunifuImageButton5.Size = new System.Drawing.Size(115, 115);
            this.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.bunifuImageButton5.TabIndex = 29;
            this.bunifuImageButton5.TabStop = false;
            this.bunifuImageButton5.Zoom = 3;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.panel28.Controls.Add(this.bunifuSwitch11);
            this.panel28.Controls.Add(this.label42);
            this.panel28.Controls.Add(this.bunifuSwitch12);
            this.panel28.Controls.Add(this.label43);
            this.bunifuTransition2.SetDecoration(this.panel28, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel28, BunifuAnimatorNS.DecorationType.None);
            this.panel28.Location = new System.Drawing.Point(745, 573);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(200, 115);
            this.panel28.TabIndex = 27;
            // 
            // bunifuSwitch11
            // 
            this.bunifuSwitch11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch11.BorderRadius = 0;
            this.bunifuSwitch11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch11, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch11.Location = new System.Drawing.Point(129, 23);
            this.bunifuSwitch11.Name = "bunifuSwitch11";
            this.bunifuSwitch11.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch11.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch11.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch11.TabIndex = 3;
            this.bunifuSwitch11.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch11.Value = true;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label42, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label42, BunifuAnimatorNS.DecorationType.None);
            this.label42.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(17, 70);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(96, 18);
            this.label42.TabIndex = 7;
            this.label42.Text = "Show labels";
            // 
            // bunifuSwitch12
            // 
            this.bunifuSwitch12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuSwitch12.BorderRadius = 0;
            this.bunifuSwitch12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuSwitch12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuSwitch12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSwitch12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch12.Location = new System.Drawing.Point(129, 70);
            this.bunifuSwitch12.Name = "bunifuSwitch12";
            this.bunifuSwitch12.Oncolor = System.Drawing.Color.RoyalBlue;
            this.bunifuSwitch12.Onoffcolor = System.Drawing.Color.DarkOrchid;
            this.bunifuSwitch12.Size = new System.Drawing.Size(51, 19);
            this.bunifuSwitch12.TabIndex = 5;
            this.bunifuSwitch12.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bunifuSwitch12.Value = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label43, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label43, BunifuAnimatorNS.DecorationType.None);
            this.label43.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(17, 24);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(82, 18);
            this.label43.TabIndex = 6;
            this.label43.Text = "Show grid";
            // 
            // chart5
            // 
            this.chart5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            this.chart5.BackSecondaryColor = System.Drawing.Color.White;
            this.chart5.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea35.AxisX.InterlacedColor = System.Drawing.Color.Green;
            chartArea35.AxisX.LineColor = System.Drawing.Color.Gray;
            chartArea35.AxisX.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            chartArea35.AxisX.TitleForeColor = System.Drawing.Color.DarkGray;
            chartArea35.AxisX2.LineColor = System.Drawing.Color.Gray;
            chartArea35.AxisX2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea35.AxisX2.LineWidth = 5;
            chartArea35.AxisY.LineColor = System.Drawing.Color.Gray;
            chartArea35.AxisY.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea35.AxisY.LineWidth = 5;
            chartArea35.AxisY.Maximum = 160D;
            chartArea35.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea35.AxisY2.LineColor = System.Drawing.Color.Gray;
            chartArea35.AxisY2.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            chartArea35.AxisY2.LineWidth = 5;
            chartArea35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(32)))), ((int)(((byte)(84)))));
            chartArea35.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea35.Name = "ChartArea1";
            this.chart5.ChartAreas.Add(chartArea35);
            this.bunifuTransition2.SetDecoration(this.chart5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.chart5, BunifuAnimatorNS.DecorationType.None);
            legend35.BackColor = System.Drawing.Color.Transparent;
            legend35.ForeColor = System.Drawing.Color.White;
            legend35.InterlacedRowsColor = System.Drawing.Color.White;
            legend35.Name = "Legend1";
            this.chart5.Legends.Add(legend35);
            this.chart5.Location = new System.Drawing.Point(6, 0);
            this.chart5.Name = "chart5";
            series53.ChartArea = "ChartArea1";
            series53.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series53.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            series53.LabelBackColor = System.Drawing.Color.White;
            series53.Legend = "Legend1";
            series53.MarkerSize = 8;
            series53.MarkerStep = 7;
            series53.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series53.Name = "Temperature";
            series54.ChartArea = "ChartArea1";
            series54.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series54.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            series54.Legend = "Legend1";
            series54.MarkerSize = 8;
            series54.MarkerStep = 2;
            series54.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series54.Name = "Turbidity";
            series55.ChartArea = "ChartArea1";
            series55.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series55.Color = System.Drawing.Color.RoyalBlue;
            series55.Legend = "Legend1";
            series55.MarkerSize = 8;
            series55.MarkerStep = 2;
            series55.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series55.Name = "pH";
            series56.ChartArea = "ChartArea1";
            series56.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series56.Color = System.Drawing.Color.DarkOrchid;
            series56.Legend = "Legend1";
            series56.MarkerSize = 8;
            series56.MarkerStep = 2;
            series56.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series56.Name = "ELC";
            this.chart5.Series.Add(series53);
            this.chart5.Series.Add(series54);
            this.chart5.Series.Add(series55);
            this.chart5.Series.Add(series56);
            this.chart5.Size = new System.Drawing.Size(951, 496);
            this.chart5.TabIndex = 26;
            this.chart5.Text = "chart5";
            // 
            // Maps
            // 
            this.Maps.BackColor = System.Drawing.SystemColors.Control;
            this.Maps.Controls.Add(this.gMapControl1);
            this.bunifuTransition2.SetDecoration(this.Maps, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.Maps, BunifuAnimatorNS.DecorationType.None);
            this.Maps.Location = new System.Drawing.Point(4, 22);
            this.Maps.Name = "Maps";
            this.Maps.Size = new System.Drawing.Size(963, 734);
            this.Maps.TabIndex = 3;
            this.Maps.Text = "Maps";
            // 
            // gMapControl1
            // 
            this.gMapControl1.Bearing = 0F;
            this.gMapControl1.CanDragMap = true;
            this.bunifuTransition2.SetDecoration(this.gMapControl1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.gMapControl1, BunifuAnimatorNS.DecorationType.None);
            this.gMapControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gMapControl1.EmptyTileColor = System.Drawing.Color.Navy;
            this.gMapControl1.GrayScaleMode = false;
            this.gMapControl1.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gMapControl1.LevelsKeepInMemmory = 5;
            this.gMapControl1.Location = new System.Drawing.Point(0, 0);
            this.gMapControl1.MarkersEnabled = true;
            this.gMapControl1.MaxZoom = 2;
            this.gMapControl1.MinZoom = 2;
            this.gMapControl1.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gMapControl1.Name = "gMapControl1";
            this.gMapControl1.NegativeMode = false;
            this.gMapControl1.PolygonsEnabled = true;
            this.gMapControl1.RetryLoadTile = 0;
            this.gMapControl1.RoutesEnabled = true;
            this.gMapControl1.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gMapControl1.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gMapControl1.ShowTileGridLines = false;
            this.gMapControl1.Size = new System.Drawing.Size(963, 734);
            this.gMapControl1.TabIndex = 1;
            this.gMapControl1.Zoom = 0D;
            this.gMapControl1.Load += new System.EventHandler(this.gMapControl1_Load);
            // 
            // Database
            // 
            this.Database.BackColor = System.Drawing.SystemColors.Control;
            this.Database.Controls.Add(this.label61);
            this.Database.Controls.Add(this.textBox17);
            this.Database.Controls.Add(this.label62);
            this.Database.Controls.Add(this.textBox16);
            this.Database.Controls.Add(this.textBox8);
            this.Database.Controls.Add(this.label63);
            this.Database.Controls.Add(this.textBox7);
            this.Database.Controls.Add(this.label64);
            this.Database.Controls.Add(this.textBox2);
            this.Database.Controls.Add(this.textBox3);
            this.Database.Controls.Add(this.label65);
            this.Database.Controls.Add(this.label66);
            this.Database.Controls.Add(this.label67);
            this.Database.Controls.Add(this.textBox4);
            this.Database.Controls.Add(this.dataGridView1);
            this.bunifuTransition2.SetDecoration(this.Database, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.Database, BunifuAnimatorNS.DecorationType.None);
            this.Database.Location = new System.Drawing.Point(4, 22);
            this.Database.Name = "Database";
            this.Database.Size = new System.Drawing.Size(963, 734);
            this.Database.TabIndex = 4;
            this.Database.Text = "DataBase";
            // 
            // label61
            // 
            this.label61.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label61.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label61, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label61, BunifuAnimatorNS.DecorationType.None);
            this.label61.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(527, 673);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(25, 15);
            this.label61.TabIndex = 62;
            this.label61.Text = "Loc";
            // 
            // textBox17
            // 
            this.textBox17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTransition1.SetDecoration(this.textBox17, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.textBox17, BunifuAnimatorNS.DecorationType.None);
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.ForeColor = System.Drawing.Color.Green;
            this.textBox17.Location = new System.Drawing.Point(556, 673);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(69, 17);
            this.textBox17.TabIndex = 61;
            // 
            // label62
            // 
            this.label62.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label62.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label62, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label62, BunifuAnimatorNS.DecorationType.None);
            this.label62.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(426, 673);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(20, 15);
            this.label62.TabIndex = 60;
            this.label62.Text = "EC";
            // 
            // textBox16
            // 
            this.textBox16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTransition1.SetDecoration(this.textBox16, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.textBox16, BunifuAnimatorNS.DecorationType.None);
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.ForeColor = System.Drawing.Color.Green;
            this.textBox16.Location = new System.Drawing.Point(452, 673);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(69, 17);
            this.textBox16.TabIndex = 59;
            // 
            // textBox8
            // 
            this.textBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTransition1.SetDecoration(this.textBox8, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.textBox8, BunifuAnimatorNS.DecorationType.None);
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.ForeColor = System.Drawing.Color.Green;
            this.textBox8.Location = new System.Drawing.Point(784, 673);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(69, 17);
            this.textBox8.TabIndex = 58;
            // 
            // label63
            // 
            this.label63.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label63.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label63, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label63, BunifuAnimatorNS.DecorationType.None);
            this.label63.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(746, 673);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(32, 15);
            this.label63.TabIndex = 57;
            this.label63.Text = "Date";
            // 
            // textBox7
            // 
            this.textBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTransition1.SetDecoration(this.textBox7, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.textBox7, BunifuAnimatorNS.DecorationType.None);
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.ForeColor = System.Drawing.Color.Green;
            this.textBox7.Location = new System.Drawing.Point(666, 673);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(69, 17);
            this.textBox7.TabIndex = 56;
            // 
            // label64
            // 
            this.label64.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label64.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label64, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label64, BunifuAnimatorNS.DecorationType.None);
            this.label64.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(627, 673);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(33, 15);
            this.label64.TabIndex = 55;
            this.label64.Text = "Time";
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTransition1.SetDecoration(this.textBox2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.textBox2, BunifuAnimatorNS.DecorationType.None);
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Green;
            this.textBox2.Location = new System.Drawing.Point(344, 673);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(69, 17);
            this.textBox2.TabIndex = 54;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTransition1.SetDecoration(this.textBox3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.textBox3, BunifuAnimatorNS.DecorationType.None);
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Green;
            this.textBox3.Location = new System.Drawing.Point(234, 673);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(69, 17);
            this.textBox3.TabIndex = 53;
            // 
            // label65
            // 
            this.label65.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label65.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label65, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label65, BunifuAnimatorNS.DecorationType.None);
            this.label65.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(316, 673);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(22, 15);
            this.label65.TabIndex = 52;
            this.label65.Text = "pH";
            // 
            // label66
            // 
            this.label66.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label66.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label66, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label66, BunifuAnimatorNS.DecorationType.None);
            this.label66.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(172, 673);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(56, 15);
            this.label66.TabIndex = 51;
            this.label66.Text = "Turbidity";
            // 
            // label67
            // 
            this.label67.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label67.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label67, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label67, BunifuAnimatorNS.DecorationType.None);
            this.label67.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(11, 673);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(75, 15);
            this.label67.TabIndex = 50;
            this.label67.Text = "Temperature";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bunifuTransition1.SetDecoration(this.textBox4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.textBox4, BunifuAnimatorNS.DecorationType.None);
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Green;
            this.textBox4.Location = new System.Drawing.Point(92, 673);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(69, 17);
            this.textBox4.TabIndex = 49;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.location});
            this.bunifuTransition2.SetDecoration(this.dataGridView1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.dataGridView1, BunifuAnimatorNS.DecorationType.None);
            this.dataGridView1.Location = new System.Drawing.Point(11, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(842, 667);
            this.dataGridView1.TabIndex = 1;
            // 
            // location
            // 
            this.location.DataPropertyName = "location";
            this.location.HeaderText = "location";
            this.location.Name = "location";
            // 
            // Settings
            // 
            this.Settings.BackColor = System.Drawing.SystemColors.Control;
            this.Settings.Controls.Add(this.panel34);
            this.Settings.Controls.Add(this.bunifuTileButton4);
            this.Settings.Controls.Add(this.bunifuTileButton3);
            this.Settings.Controls.Add(this.bunifuTileButton2);
            this.Settings.Controls.Add(this.bunifuTileButton1);
            this.Settings.Controls.Add(this.panel33);
            this.bunifuTransition2.SetDecoration(this.Settings, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.Settings, BunifuAnimatorNS.DecorationType.None);
            this.Settings.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.Settings.Location = new System.Drawing.Point(4, 22);
            this.Settings.Name = "Settings";
            this.Settings.Size = new System.Drawing.Size(963, 734);
            this.Settings.TabIndex = 5;
            this.Settings.Text = "Settings";
            this.Settings.Click += new System.EventHandler(this.Settings_Click);
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel34.Controls.Add(this.bunifuThinButton23);
            this.panel34.Controls.Add(this.bunifuThinButton22);
            this.panel34.Controls.Add(this.bunifuThinButton21);
            this.panel34.Controls.Add(this.bunifuCustomLabel12);
            this.panel34.Controls.Add(this.pictureBox5);
            this.panel34.Controls.Add(this.bunifuCircleProgressbar15);
            this.panel34.Controls.Add(this.comboBox1);
            this.panel34.Controls.Add(this.label52);
            this.bunifuTransition2.SetDecoration(this.panel34, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel34, BunifuAnimatorNS.DecorationType.None);
            this.panel34.Location = new System.Drawing.Point(11, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(953, 354);
            this.panel34.TabIndex = 10;
            this.panel34.Paint += new System.Windows.Forms.PaintEventHandler(this.panel34_Paint);
            // 
            // bunifuThinButton23
            // 
            this.bunifuThinButton23.ActiveBorderThickness = 1;
            this.bunifuThinButton23.ActiveCornerRadius = 20;
            this.bunifuThinButton23.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton23.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton23.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton23.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuThinButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton23.BackgroundImage")));
            this.bunifuThinButton23.ButtonText = "Secure Calypso";
            this.bunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuThinButton23, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuThinButton23, BunifuAnimatorNS.DecorationType.None);
            this.bunifuThinButton23.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton23.IdleBorderThickness = 1;
            this.bunifuThinButton23.IdleCornerRadius = 20;
            this.bunifuThinButton23.IdleFillColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton23.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton23.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton23.Location = new System.Drawing.Point(22, 308);
            this.bunifuThinButton23.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton23.Name = "bunifuThinButton23";
            this.bunifuThinButton23.Size = new System.Drawing.Size(130, 41);
            this.bunifuThinButton23.TabIndex = 13;
            this.bunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton23.Click += new System.EventHandler(this.bunifuThinButton23_Click);
            // 
            // bunifuThinButton22
            // 
            this.bunifuThinButton22.ActiveBorderThickness = 1;
            this.bunifuThinButton22.ActiveCornerRadius = 20;
            this.bunifuThinButton22.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton22.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton22.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton22.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton22.BackgroundImage")));
            this.bunifuThinButton22.ButtonText = "Set the baud rate";
            this.bunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuThinButton22, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuThinButton22, BunifuAnimatorNS.DecorationType.None);
            this.bunifuThinButton22.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton22.IdleBorderThickness = 1;
            this.bunifuThinButton22.IdleCornerRadius = 20;
            this.bunifuThinButton22.IdleFillColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton22.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton22.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton22.Location = new System.Drawing.Point(763, 270);
            this.bunifuThinButton22.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton22.Name = "bunifuThinButton22";
            this.bunifuThinButton22.Size = new System.Drawing.Size(174, 41);
            this.bunifuThinButton22.TabIndex = 12;
            this.bunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton22.Click += new System.EventHandler(this.bunifuThinButton22_Click);
            // 
            // bunifuThinButton21
            // 
            this.bunifuThinButton21.ActiveBorderThickness = 1;
            this.bunifuThinButton21.ActiveCornerRadius = 20;
            this.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.White;
            this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton21.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
            this.bunifuThinButton21.ButtonText = "Set the time interval";
            this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuThinButton21.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton21.IdleBorderThickness = 1;
            this.bunifuThinButton21.IdleCornerRadius = 20;
            this.bunifuThinButton21.IdleFillColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuThinButton21.Location = new System.Drawing.Point(763, 308);
            this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton21.Name = "bunifuThinButton21";
            this.bunifuThinButton21.Size = new System.Drawing.Size(174, 41);
            this.bunifuThinButton21.TabIndex = 11;
            this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton21.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.bunifuCustomLabel12, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(415, 222);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(110, 23);
            this.bunifuCustomLabel12.TabIndex = 1;
            this.bunifuCustomLabel12.Text = "Connected";
            // 
            // pictureBox5
            // 
            this.bunifuTransition1.SetDecoration(this.pictureBox5, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.pictureBox5, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(418, 119);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 100);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // bunifuCircleProgressbar15
            // 
            this.bunifuCircleProgressbar15.animated = false;
            this.bunifuCircleProgressbar15.animationIterval = 5;
            this.bunifuCircleProgressbar15.animationSpeed = 300;
            this.bunifuCircleProgressbar15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar15.BackgroundImage")));
            this.bunifuTransition2.SetDecoration(this.bunifuCircleProgressbar15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar15, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar15.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.bunifuCircleProgressbar15.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar15.LabelVisible = false;
            this.bunifuCircleProgressbar15.LineProgressThickness = 8;
            this.bunifuCircleProgressbar15.LineThickness = 12;
            this.bunifuCircleProgressbar15.Location = new System.Drawing.Point(312, 23);
            this.bunifuCircleProgressbar15.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.bunifuCircleProgressbar15.MaxValue = 100;
            this.bunifuCircleProgressbar15.Name = "bunifuCircleProgressbar15";
            this.bunifuCircleProgressbar15.ProgressBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuCircleProgressbar15.ProgressColor = System.Drawing.Color.SeaGreen;
            this.bunifuCircleProgressbar15.Size = new System.Drawing.Size(308, 308);
            this.bunifuCircleProgressbar15.TabIndex = 2;
            this.bunifuCircleProgressbar15.Value = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuTransition2.SetDecoration(this.comboBox1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.comboBox1, BunifuAnimatorNS.DecorationType.None);
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "COM1"});
            this.comboBox1.Location = new System.Drawing.Point(828, 17);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(109, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.Click += new System.EventHandler(this.comboBox1_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTransition1.SetDecoration(this.label52, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label52, BunifuAnimatorNS.DecorationType.None);
            this.label52.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.Gray;
            this.label52.Location = new System.Drawing.Point(772, 18);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(46, 18);
            this.label52.TabIndex = 5;
            this.label52.Text = "Port:";
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // bunifuTileButton4
            // 
            this.bunifuTileButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuTileButton4.color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuTileButton4.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.bunifuTileButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuTileButton4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTileButton4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTileButton4.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton4.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton4.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton4.Image")));
            this.bunifuTileButton4.ImagePosition = 20;
            this.bunifuTileButton4.ImageZoom = 45;
            this.bunifuTileButton4.LabelPosition = 41;
            this.bunifuTileButton4.LabelText = "Send data";
            this.bunifuTileButton4.Location = new System.Drawing.Point(362, 471);
            this.bunifuTileButton4.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton4.Name = "bunifuTileButton4";
            this.bunifuTileButton4.Size = new System.Drawing.Size(128, 129);
            this.bunifuTileButton4.TabIndex = 9;
            this.bunifuTileButton4.Click += new System.EventHandler(this.bunifuTileButton4_Click);
            // 
            // bunifuTileButton3
            // 
            this.bunifuTileButton3.BackColor = System.Drawing.Color.DarkViolet;
            this.bunifuTileButton3.color = System.Drawing.Color.DarkViolet;
            this.bunifuTileButton3.colorActive = System.Drawing.Color.DarkViolet;
            this.bunifuTileButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuTileButton3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTileButton3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTileButton3.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton3.Image")));
            this.bunifuTileButton3.ImagePosition = 20;
            this.bunifuTileButton3.ImageZoom = 45;
            this.bunifuTileButton3.LabelPosition = 41;
            this.bunifuTileButton3.LabelText = "Send data";
            this.bunifuTileButton3.Location = new System.Drawing.Point(502, 471);
            this.bunifuTileButton3.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton3.Name = "bunifuTileButton3";
            this.bunifuTileButton3.Size = new System.Drawing.Size(128, 129);
            this.bunifuTileButton3.TabIndex = 8;
            this.bunifuTileButton3.Click += new System.EventHandler(this.bunifuTileButton3_Click);
            // 
            // bunifuTileButton2
            // 
            this.bunifuTileButton2.BackColor = System.Drawing.Color.RoyalBlue;
            this.bunifuTileButton2.color = System.Drawing.Color.RoyalBlue;
            this.bunifuTileButton2.colorActive = System.Drawing.Color.RoyalBlue;
            this.bunifuTileButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuTileButton2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTileButton2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTileButton2.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton2.Image")));
            this.bunifuTileButton2.ImagePosition = 20;
            this.bunifuTileButton2.ImageZoom = 45;
            this.bunifuTileButton2.LabelPosition = 41;
            this.bunifuTileButton2.LabelText = "Receive data";
            this.bunifuTileButton2.Location = new System.Drawing.Point(642, 471);
            this.bunifuTileButton2.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton2.Name = "bunifuTileButton2";
            this.bunifuTileButton2.Size = new System.Drawing.Size(128, 129);
            this.bunifuTileButton2.TabIndex = 7;
            this.bunifuTileButton2.Click += new System.EventHandler(this.bunifuTileButton2_Click);
            // 
            // bunifuTileButton1
            // 
            this.bunifuTileButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuTileButton1.color = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuTileButton1.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition2.SetDecoration(this.bunifuTileButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.bunifuTileButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTileButton1.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton1.Image")));
            this.bunifuTileButton1.ImagePosition = 20;
            this.bunifuTileButton1.ImageZoom = 45;
            this.bunifuTileButton1.LabelPosition = 41;
            this.bunifuTileButton1.LabelText = "Restart";
            this.bunifuTileButton1.Location = new System.Drawing.Point(782, 471);
            this.bunifuTileButton1.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton1.Name = "bunifuTileButton1";
            this.bunifuTileButton1.Size = new System.Drawing.Size(128, 129);
            this.bunifuTileButton1.TabIndex = 6;
            this.bunifuTileButton1.Click += new System.EventHandler(this.bunifuTileButton1_Click);
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.Gainsboro;
            this.panel33.Controls.Add(this.panel35);
            this.bunifuTransition2.SetDecoration(this.panel33, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel33, BunifuAnimatorNS.DecorationType.None);
            this.panel33.Location = new System.Drawing.Point(11, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(300, 701);
            this.panel33.TabIndex = 3;
            this.panel33.Paint += new System.Windows.Forms.PaintEventHandler(this.panel33_Paint);
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.panel35.Controls.Add(this.label51);
            this.panel35.Controls.Add(this.pictureBox6);
            this.bunifuTransition2.SetDecoration(this.panel35, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel35, BunifuAnimatorNS.DecorationType.None);
            this.panel35.Location = new System.Drawing.Point(22, 412);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(254, 234);
            this.panel35.TabIndex = 0;
            this.panel35.Paint += new System.Windows.Forms.PaintEventHandler(this.panel35_Paint);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label51, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label51, BunifuAnimatorNS.DecorationType.None);
            this.label51.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(94, 146);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(60, 23);
            this.label51.TabIndex = 11;
            this.label51.Text = "Done";
            this.label51.Visible = false;
            // 
            // pictureBox6
            // 
            this.bunifuTransition1.SetDecoration(this.pictureBox6, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.pictureBox6, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(92, 75);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(64, 64);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click_1);
            // 
            // About
            // 
            this.About.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(61)))), ((int)(((byte)(120)))));
            this.About.Controls.Add(this.panel29);
            this.About.Controls.Add(this.pictureBox4);
            this.About.Controls.Add(this.label1);
            this.bunifuTransition2.SetDecoration(this.About, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.About, BunifuAnimatorNS.DecorationType.None);
            this.About.Location = new System.Drawing.Point(4, 22);
            this.About.Name = "About";
            this.About.Size = new System.Drawing.Size(963, 734);
            this.About.TabIndex = 6;
            this.About.Text = "About";
            // 
            // panel29
            // 
            this.panel29.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.panel29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.panel29.Controls.Add(this.pictureBox2);
            this.bunifuTransition2.SetDecoration(this.panel29, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition1.SetDecoration(this.panel29, BunifuAnimatorNS.DecorationType.None);
            this.panel29.Location = new System.Drawing.Point(679, 427);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(269, 241);
            this.panel29.TabIndex = 5;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(40)))), ((int)(((byte)(105)))));
            this.bunifuTransition1.SetDecoration(this.pictureBox2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.pictureBox2, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(245, 215);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.bunifuTransition1.SetDecoration(this.pictureBox4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.pictureBox4, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(3, -1);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(959, 410);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.label1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this.label1, BunifuAnimatorNS.DecorationType.None);
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(29, 450);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(587, 198);
            this.label1.TabIndex = 2;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // bunifuDragControl4
            // 
            this.bunifuDragControl4.Fixed = true;
            this.bunifuDragControl4.Horizontal = true;
            this.bunifuDragControl4.TargetControl = this.pictureBox1;
            this.bunifuDragControl4.Vertical = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // bunifuDragControl6
            // 
            this.bunifuDragControl6.Fixed = true;
            this.bunifuDragControl6.Horizontal = true;
            this.bunifuDragControl6.TargetControl = this.About;
            this.bunifuDragControl6.Vertical = true;
            // 
            // bunifuTransition1
            // 
            this.bunifuTransition1.AnimationType = BunifuAnimatorNS.AnimationType.VertBlind;
            this.bunifuTransition1.Cursor = null;
            animation14.AnimateOnlyDifferences = true;
            animation14.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation14.BlindCoeff")));
            animation14.LeafCoeff = 0F;
            animation14.MaxTime = 1F;
            animation14.MinTime = 0F;
            animation14.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation14.MosaicCoeff")));
            animation14.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation14.MosaicShift")));
            animation14.MosaicSize = 0;
            animation14.Padding = new System.Windows.Forms.Padding(0);
            animation14.RotateCoeff = 0F;
            animation14.RotateLimit = 0F;
            animation14.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation14.ScaleCoeff")));
            animation14.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation14.SlideCoeff")));
            animation14.TimeCoeff = 0F;
            animation14.TransparencyCoeff = 0F;
            this.bunifuTransition1.DefaultAnimation = animation14;
            // 
            // bunifuTransition2
            // 
            this.bunifuTransition2.AnimationType = BunifuAnimatorNS.AnimationType.HorizBlind;
            this.bunifuTransition2.Cursor = null;
            animation13.AnimateOnlyDifferences = true;
            animation13.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation13.BlindCoeff")));
            animation13.LeafCoeff = 0F;
            animation13.MaxTime = 1F;
            animation13.MinTime = 0F;
            animation13.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation13.MosaicCoeff")));
            animation13.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation13.MosaicShift")));
            animation13.MosaicSize = 0;
            animation13.Padding = new System.Windows.Forms.Padding(0);
            animation13.RotateCoeff = 0F;
            animation13.RotateLimit = 0F;
            animation13.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation13.ScaleCoeff")));
            animation13.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation13.SlideCoeff")));
            animation13.TimeCoeff = 0F;
            animation13.TransparencyCoeff = 0F;
            this.bunifuTransition2.DefaultAnimation = animation13;
            // 
            // bunifuDragControl7
            // 
            this.bunifuDragControl7.Fixed = true;
            this.bunifuDragControl7.Horizontal = true;
            this.bunifuDragControl7.TargetControl = this.panel3;
            this.bunifuDragControl7.Vertical = true;
            // 
            // bunifuDragControl8
            // 
            this.bunifuDragControl8.Fixed = true;
            this.bunifuDragControl8.Horizontal = true;
            this.bunifuDragControl8.TargetControl = this.panel4;
            this.bunifuDragControl8.Vertical = true;
            // 
            // bunifuDragControl9
            // 
            this.bunifuDragControl9.Fixed = true;
            this.bunifuDragControl9.Horizontal = true;
            this.bunifuDragControl9.TargetControl = this.panel5;
            this.bunifuDragControl9.Vertical = true;
            // 
            // bunifuDragControl10
            // 
            this.bunifuDragControl10.Fixed = true;
            this.bunifuDragControl10.Horizontal = true;
            this.bunifuDragControl10.TargetControl = this.gMapControl2;
            this.bunifuDragControl10.Vertical = true;
            // 
            // bunifuDragControl11
            // 
            this.bunifuDragControl11.Fixed = true;
            this.bunifuDragControl11.Horizontal = true;
            this.bunifuDragControl11.TargetControl = this.panel8;
            this.bunifuDragControl11.Vertical = true;
            // 
            // bunifuDragControl12
            // 
            this.bunifuDragControl12.Fixed = true;
            this.bunifuDragControl12.Horizontal = true;
            this.bunifuDragControl12.TargetControl = this.panel7;
            this.bunifuDragControl12.Vertical = true;
            // 
            // bunifuDragControl5
            // 
            this.bunifuDragControl5.Fixed = true;
            this.bunifuDragControl5.Horizontal = true;
            this.bunifuDragControl5.TargetControl = this.Home;
            this.bunifuDragControl5.Vertical = true;
            // 
            // New
            // 
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1175, 710);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tabControl1);
            this.bunifuTransition1.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.bunifuTransition2.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "New";
            this.Load += new System.EventHandler(this.New_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.Home.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Serial_Monitor.ResumeLayout(false);
            this.Serial_Monitor.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).EndInit();
            this.Charts.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).EndInit();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).EndInit();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart5)).EndInit();
            this.Maps.ResumeLayout(false);
            this.Database.ResumeLayout(false);
            this.Database.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Settings.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel33.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.About.ResumeLayout(false);
            this.About.PerformLayout();
            this.panel29.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        private void bunifuCustomLabel7_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private calypsoSQLDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton2;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton5;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton9;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton10;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Serial_Monitor;
        private System.Windows.Forms.TabPage Home;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton11;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton12;
        private System.Windows.Forms.TabPage Charts;
        private System.Windows.Forms.TabPage Maps;
        private System.Windows.Forms.TabPage Database;
        private System.Windows.Forms.TabPage Settings;
        private System.Windows.Forms.TabPage About;
        private GMap.NET.WindowsForms.GMapControl gMapControl1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private GMap.NET.WindowsForms.GMapControl gMapControl2;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar1;
        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar2;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar6;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar5;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar4;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar3;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton14;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton13;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton7;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar7;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar8;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar9;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar10;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar11;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar12;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar13;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar14;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel13;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton19;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton18;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton17;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton16;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton20;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch3;
        private System.Windows.Forms.Label label9;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel14;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox2;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox3;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox2;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox1;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox4;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label15;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton21;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton22;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox5;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox6;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox7;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox8;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox4;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox5;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private System.Windows.Forms.Panel panel19;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch5;
        private System.Windows.Forms.Label label21;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox9;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox10;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox11;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox12;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox6;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox7;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        private System.Windows.Forms.Panel panel22;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch7;
        private System.Windows.Forms.Label label28;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch8;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox13;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox14;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox15;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox16;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox8;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox9;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton4;
        private System.Windows.Forms.Panel panel25;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch9;
        private System.Windows.Forms.Label label35;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch10;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart4;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton23;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton24;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton25;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton26;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox17;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox18;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox19;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox20;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox10;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox11;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton5;
        private System.Windows.Forms.Panel panel28;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch11;
        private System.Windows.Forms.Label label42;
        private Bunifu.Framework.UI.BunifuSwitch bunifuSwitch12;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart5;
        private Bunifu.Framework.UI.BunifuTextbox bunifuTextbox1;
        private Bunifu.Framework.UI.BunifuCheckbox bunifuCheckbox21;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.PictureBox pictureBox4;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton6;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton27;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private BunifuAnimatorNS.BunifuTransition bunifuTransition1;
        private System.Windows.Forms.Panel panel32;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton28;
        private BunifuAnimatorNS.BunifuTransition bunifuTransition2;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl7;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl8;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl9;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl10;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl11;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl12;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton1;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn location;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton2;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton4;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton3;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.PictureBox pictureBox5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar15;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton22;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.PictureBox pictureBox6;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton23;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl5;
    }
}