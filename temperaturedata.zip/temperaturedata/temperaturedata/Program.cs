﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace temperaturedata
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        
        [STAThread]
        static void Main()
        {
          
            //string last = File.ReadLines(@"D:\BucurestiTechlallenge\temperaturedata\temperaturedata\bin\Debug\security.txt").Last();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

           
               
                Application.Run(new New());
            
           
           
        }
    }
}
