﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace temperaturedata
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (System.IO.File.Exists(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt") == false)
            {
                StreamWriter mi = new StreamWriter("mail.txt", true);
                mi.WriteLine(textBox1.Text);
                MessageBox.Show("E-mail saved!");
                mi.Close();
                this.Close();
            }
         
        }
    }
}
