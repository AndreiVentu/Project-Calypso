﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace temperaturedata
{
    public partial class emailwindow : Form
    {
        private SerialPort myport;
        String turb = "";
        String temp = "";
        String pH = "";
        String EC = "";
        private string in_data;
        public emailwindow()
        {
            InitializeComponent();          
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            int i, k = 0, k1 = 0, j = 0, k2 = 0, k3 = 0, k4 = 0, k5 = 0;
            temp = "";
            turb = "";
            pH = "";
            in_data = myport.ReadLine();

            for (i = 0; i < in_data.Length - 1; i++)
            {

                //turb
                if (in_data[i] == '(' && in_data[i + 1] != '(')
                {
                    k = i;
                    continue;
                }
                if (in_data[i] == ')' && in_data[i + 1] != ')')
                {
                    k1 = i;
                    // continue;
                }
                //
                //pH
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] != '(')
                {
                    k2 = i;
                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] != ')')
                {
                    k3 = i;
                }
                //
                // EC
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] == '(' && in_data[i + 3] != '(')
                {
                    k4 = i;
                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] == ')' && in_data[i + 3] != ')')
                {
                    k5 = i;
                }
                //

            }

            if (k > 0 && k1 > 0)
            {
                for (j = (k + 1); j < k1 - 1; j++)
                {
                    turb += in_data[j];
                }
            }
            for (j = 0; j < k; j++)
            {
                temp += in_data[j];
            }

            for (j = k2 + 2; j < k3; j++)
            {
                pH += in_data[j];
            }

            for (j = k4 + 3; j < k5; j++)
            {
                EC += in_data[j];
            }

            int F1, F2;
            string Watlvl;
            F1 = (int)(7 * 1.8) + 32;
            F2 = (int)(15 * 1.8) + 32;
            if (System.IO.File.Exists(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt") == false)
            {
                Form10 f10 = new Form10();
                f10.Show();
            }
            else
            {//
                string line1;
                using (StreamReader reader = new StreamReader(@"D:\Andrei\arduino projects\temperaturedata\temperaturedata\bin\Debug\mail.txt"))
                {
                    line1 = reader.ReadLine();
                }

                using (MailMessage mail = new MailMessage())
                {
                    mail.From = new MailAddress("AtlasTeamCL@gmail.com");
                    mail.To.Add(line1);
                    mail.Subject = "Calypo - water quality";
                    //if(water level ....)
                    //{
                    Watlvl = "Also Calypso is protected!";
                    // }
                    //  else
                    //  {
                    Watlvl = "Careful Calypso is not protected!";
                    //   }

                    if (Convert.ToSingle(temp.Trim()) >= 7 && Convert.ToSingle(temp.Trim()) <= 15 || Convert.ToSingle(turb.Trim()) >= 0 && Convert.ToSingle(turb.Trim()) <= 150 || Convert.ToSingle(temp.Trim()) >= 6 && Convert.ToSingle(temp.Trim()) <= 8 || Convert.ToSingle(temp.Trim()) >= 5 && Convert.ToSingle(temp.Trim()) <= 50)
                    {
                        mail.Body = "Water quality is good. \nTemperature is" + temp + " which is ok because is between 7° C and 15° C (" + F1 + "° F and " + F2 + "° F) \nTurbidity is" + temp + " which is ok because is between 0 NTU and 150 NTU \npH is " + temp + " which is ok because is between 6 and 8 \nElectrical Conductivity is" + temp + " which is ok because is between 5 and 50 \n" + Watlvl;
                    }
                    else
                    {
                        mail.Body = "Water quality is bad. \nTemperature is" + temp + " which should be between 7° C and 15° C (" + F1 + "° F and " + F2 + "° F) \nTurbidity is" + temp + " which should be between 0 NTU and 150 NTU \npH is " + temp + " should be between 6 and 8 \nElectrical Conductivity is" + temp + " which should be between 5 and 50 \n" + Watlvl;
                    }
                    // mail.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new NetworkCredential("AtlasTeamCL@gmail.com", "calypsovs");
                        smtp.EnableSsl = true;
                        smtp.Send(mail);
                    }
                    MessageBox.Show("E-mail sent!");

                }
                //
            }



        }
       

        private void emailwindow_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
