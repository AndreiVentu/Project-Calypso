﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using temperaturedata.calypsoSQLDataSetTableAdapters;
using System.IO.Ports;
using System.Web.UI.WebControls;
using temperaturedata;
using GMap.NET.MapProviders;
using GMap.NET;
using GMap.NET.WindowsForms.Markers;
using GMap.NET.WindowsForms;

namespace temperaturedata
{
    public partial class Form9 : Form
    {
       
        public static string tempergr="";
        SqlConnection con = new SqlConnection(@"Data Source=ANDREI-LPT;Initial Catalog=calypsoSQL;Integrated Security=True");
        private Connection sqlcon = new Connection();
        public ArrayList list = new ArrayList();
        DateTime thisDay = DateTime.Today;
        String turb = "";
        String temp = "";
        String pH = "";
        String EC = "";
        String Waterlvl;
        private string in_data;
        string loc,wat,tempe,turbe,phe,ECe,data;
        
        public Form9()
        {
            InitializeComponent();
            
            int w = Screen.PrimaryScreen.Bounds.Width +30 ;       
            int h = Screen.PrimaryScreen.Bounds.Height+30;
            this.Size = new System.Drawing.Size(w,h);           
            New.myport.DataReceived += myport_DataReceived;                        
        }
  
         void myport_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int i, k = 0, k1 = 0, j = 0, k2 = 0, k3 = 0, k4 = 0, k5 = 0,k6 = 0,k7 = 0;
            temp = "";
            turb = "";
            pH = "";
            EC = "";
            Waterlvl = "";
            in_data = New.myport.ReadLine();
            for (i = 0; i < in_data.Length - 1; i++)
            {

                //turb
                if (in_data[i] == '(' && in_data[i + 1] != '(' && in_data[i - 1] != '(')
                {
                    k = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] != ')' && in_data[i - 1] != ')')
                {
                    k1 = i;

                }
                //
                //pH
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(')
                {
                    k2 = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')')
                {
                    k3 = i;

                }
                //
                // EC
                if (in_data[i] == '(' && in_data[i + 1] == '(' && in_data[i + 2] == '(' && in_data[i + 3] != '(' && in_data[i - 1] != '(' && in_data[i - 2] != '(' && in_data[i - 3] != '(')
                {
                    k4 = i;

                }
                if (in_data[i] == ')' && in_data[i + 1] == ')' && in_data[i + 2] == ')' && in_data[i + 3] != ')' && in_data[i - 1] != ')' && in_data[i - 2] != ')' && in_data[i - 3] != ')')
                {
                    k5 = i;
                    
                }

                if (in_data[i] == '*' && in_data[i + 1] != '*' && in_data[i - 1] != '*')
                {
                    k6 = i;
                }

                if (in_data[i] == '^')
                {
                    k7 = i;

                }
                //

            }

            if (k > 0 && k1 > 0)
            {
                for (j = (k + 1); j < k1 - 1; j++)
                {
                    turb += in_data[j];
                }
            }
            for (j = 0; j < k; j++)
            {
                temp += in_data[j];
            }

            for (j = k2 + 2; j < k3; j++)
            {
                pH += in_data[j];
            }

            for (j = k4 + 3; j < k5; j++)
            {
                EC += in_data[j];
            }

            for (j = k6 + 1; j < k7; j++)
            {
                Waterlvl += in_data[j];
            }

            con.Open();       
             
            SqlCommand cmd = new SqlCommand("insert into [sensorsdata] (temperature,turbidity,pH,EC,waterlvl,location,time,date) VALUES(@temp, @turb,@ph,@EC,@waterl,@loc,@time,@date)", con);
            cmd.Parameters.AddWithValue("@temp", temp);
            cmd.Parameters.AddWithValue("@turb", turb);
            cmd.Parameters.AddWithValue("@ph", pH);
            cmd.Parameters.AddWithValue("@EC", EC);
            cmd.Parameters.AddWithValue("@waterl", Waterlvl);
            cmd.Parameters.AddWithValue("@loc", "44.438226_26.051790");
            cmd.Parameters.AddWithValue("@time", "12:20:00");
            cmd.Parameters.AddWithValue("@date", "2017-04-05");
            cmd.ExecuteNonQuery();         
            con.Close();
        }

        private void Form9_Load(object sender, EventArgs e)
        {                                                                                     
            // TODO: This line of code loads data into the 'calypsoSQLDataSet.sensorsdata' table. You can move, or remove it, as needed.
            this.sensorsdataTableAdapter.Fill(this.calypsoSQLDataSet.sensorsdata);
            FillTextFields(1);
            //Int32 index = dataGridView1.Rows.Count ;
            // MessageBox.Show(index+"");          
            //MessageBox.Show(dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1].Value.ToString() + "");
            tempergr = dataGridView1.Rows[dataGridView1.RowCount - 1].Cells[1].Value.ToString();                  
        }

        private void FillTextFields(int id)
        {
            list = sqlcon.GetAllsensdata(id);
            textBox1.Text  = list[0].ToString();
            textBox3.Text  = list[1].ToString();
            textBox2.Text  = list[2].ToString();
            textBox7.Text  = list[6].ToString();
            textBox8.Text  = list[7].ToString();
            textBox16.Text = list[3].ToString();
            textBox17.Text = list[5].ToString();
            //
            loc            = list[5].ToString();
            //
            wat            = list[4].ToString();
            //
            tempe          = list[0].ToString();
            //
            turbe          = list[1].ToString();
            //
            phe            = list[2].ToString();
            //
            ECe            = list[3].ToString();
            //
            data           = list[7].ToString();
            //
            textBox6.Text  = list[0].ToString();
            textBox9.Text  = list[1].ToString();
            textBox10.Text = list[2].ToString();
            textBox11.Text = list[3].ToString();
            
            dataGridView1.AllowUserToAddRows = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           // con.Open();         
           //  con.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var currentRowindex = dataGridView1.SelectedCells[0].RowIndex;
            int currentIndex = (int)dataGridView1.Rows[currentRowindex].Cells[0].Value;
            FillTextFields(currentIndex);        
            //
            int k = 0, i;
            string lat = "", Long = "";
            for (i = 0; i < loc.Length; i++)
            {
                if (loc[i] == '_')
                {
                    k = i;
                }
            }
            for (i = 0; i < k; i++)
            {
                lat += loc[i];
            }
            for (i = k + 1; i < loc.Length; i++)
            {
                Long += loc[i];
            }
            //       

            int ok = 0;
            if (Convert.ToSingle(wat) < 100)
            {
                label17.Text = "Protected";
                label17.ForeColor = Color.Green;
            }
            else
            {
                label17.Text = "Not protected!";
                label17.ForeColor = Color.Red;
                ok = 1;
            }
            //

            if(Convert.ToSingle(tempe) > 6 && Convert.ToSingle(tempe) < 16)
            {
                textBox12.Text = "GOOD";
                textBox12.ForeColor = Color.Green;
            }
            else
            {
                textBox12.Text = "BAD";
                textBox12.ForeColor = Color.Red;
                ok = 1;
            }

            if (Convert.ToSingle(turbe) >= 0 && Convert.ToSingle(turbe) < 151)
            {
                textBox13.Text = "GOOD";
                textBox13.ForeColor = Color.Green;
            }
            else
            {
                textBox13.Text = "BAD";
                textBox13.ForeColor = Color.Red;
                ok = 1;
            }

            if (Convert.ToSingle(phe) >= 6 && Convert.ToSingle(phe) <= 8)
            {
                textBox14.Text = "GOOD";
                textBox14.ForeColor = Color.Green;
            }
            else
            {
                textBox14.Text = "BAD";
                textBox14.ForeColor = Color.Red;
                ok = 1;
            }

            if (Convert.ToSingle(ECe) >= 5  && Convert.ToSingle(ECe) < 51)
            {
                textBox15.Text = "GOOD";
                textBox15.ForeColor = Color.Green;
            }
            else
            {
                textBox15.Text = "BAD";
                textBox15.ForeColor = Color.Red;
                ok = 1;
            }

            if(ok == 0)
            {
                label4.Text = "GOOD";
                label4.ForeColor = Color.Green;
            }
            else
            {
                label4.Text = "BAD";
                label4.ForeColor = Color.Red;
            }

            textBox5.Text = "Day(" + data +")" + Environment.NewLine + "water quality is";
            gMapControl1.Position = new PointLatLng( Convert.ToSingle(lat), Convert.ToSingle(Long) );
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.sensorsdataTableAdapter.Fill(this.calypsoSQLDataSet.sensorsdata);
            string searchValue = textBox4.Text;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                bool valueResult = false;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    for (int i = 0; i < row.Cells.Count; i++)
                    {
                        if (row.Cells[i].Value != null && row.Cells[i].Value.ToString().Equals(searchValue))
                        {
                            int rowIndex = row.Index;
                            dataGridView1.Rows[rowIndex].Selected = true;
                            valueResult = true;
                            break;
                        }
                    }

                }
                if (!valueResult)
                {
                    MessageBox.Show("Unable to find " + textBox4.Text, "Not Found");
                    return;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        //Refresh
        private void button1_Click_1(object sender, EventArgs e)
        {
            this.sensorsdataTableAdapter.Fill(this.calypsoSQLDataSet.sensorsdata);
            int nRowIndex = dataGridView1.Rows.Count - 1;
            dataGridView1.CurrentCell = dataGridView1.Rows[nRowIndex].Cells[0];
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void sensorsdataBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void gMapControl1_Load(object sender, EventArgs e)
        {
            gMapControl1.DragButton = MouseButtons.Left;
            gMapControl1.CanDragMap = true;
            gMapControl1.MapProvider = GMapProviders.GoogleMap;
            gMapControl1.Position = new PointLatLng();
            gMapControl1.MinZoom = 0;
            gMapControl1.MaxZoom = 24;
            gMapControl1.Zoom = 7;
            gMapControl1.AutoScroll = true;
            GMapOverlay markersOverlay = new GMapOverlay("markers");
            GMarkerGoogle marker = new GMarkerGoogle(new PointLatLng(),
            GMarkerGoogleType.green);
            markersOverlay.Markers.Add(marker);
            gMapControl1.Overlays.Add(markersOverlay);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
