﻿using System;

namespace temperaturedata
{
    internal class GeoCoordinate
    {
        private double v;
        private float v1;
        private float v2;
        private double v3;

        public GeoCoordinate(double v, double v3)
        {
            this.v = v;
            this.v3 = v3;
        }

        public GeoCoordinate(float v1, float v2)
        {
            this.v1 = v1;
            this.v2 = v2;
        }

        internal void GetDistanceTo(GeoCoordinate point2)
        {
            throw new NotImplementedException();
        }
    }
}