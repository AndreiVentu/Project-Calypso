﻿using System;
using System.Collections;
using System.Data.SqlClient;

namespace temperaturedata
{
    class Connection
    {
        private String connectionString = "Data Source=ANDREI-LPT;Initial Catalog=calypsoSQL;Integrated Security=True";
        public ArrayList GetAllsensdata(int id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                String query = "SELECT * FROM sensorsdata WHERE id = " + id;
                
                using (var command = new SqlCommand(query, connection))
                {
                    var reader = command.ExecuteReader();
                    var list = new ArrayList();
                    while (reader.Read())
                    {                        
                        float temperi = (float)reader.GetDouble(1);
                        float turbi = (float)reader.GetDouble(2);
                        float phi = (float)reader.GetDouble(3);
                        float EC = (float)reader.GetDouble(4);
                        float waterlvl = (float)reader.GetDouble(5);
                        string location = reader.GetString(6);
                        TimeSpan timei = reader.GetTimeSpan(7);
                        DateTime? datei = reader.GetDateTime(8);

                        list.Add(temperi);
                        list.Add(turbi);
                        list.Add(phi);
                        list.Add(EC);
                        list.Add(waterlvl);
                        list.Add(location);
                        list.Add(timei);
                        list.Add(datei);

                    }
                    connection.Close();
                    reader.Close();
                    return list;
                }

            }
        }

        internal ArrayList GetAllsensdata(object id)
        {
            throw new NotImplementedException();
        }
    }
}