﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GMap.NET.MapProviders;
using GMap.NET;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using System.Collections;

namespace temperaturedata
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();

        }
        ColorDialog dlg = new ColorDialog();
        GMarkerGoogle marker;
        private double deg2rad(double deg)
        {
            return (deg * Math.PI / 180.0);
        }
        private double rad2deg(double rad)
        {
            return (rad / Math.PI * 180.0);
        }
        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text != "" && textBox2.Text != "")
            {
                GMapOverlay markersOverlay = new GMapOverlay("markers");
                marker = new GMarkerGoogle(new PointLatLng(Convert.ToSingle(textBox1.Text), Convert.ToSingle(textBox2.Text)),
                GMarkerGoogleType.blue);
                gMapControl1.Overlays.Add(markersOverlay);
                label10.Text = textBox1.Text;
                label9.Text = textBox2.Text;
                ColorDialog MyDialog = new ColorDialog();
                //line
                GMapOverlay routes = new GMapOverlay("routes");
                List<PointLatLng> points = new List<PointLatLng>();
                points.Add(new PointLatLng(47.640742, 26.245164));
                points.Add(new PointLatLng(Convert.ToSingle(textBox1.Text), Convert.ToSingle(textBox2.Text)));
                markersOverlay.Markers.Add(marker);
                GMapRoute route = new GMapRoute(points, "A walk in the park");
                route.Stroke = new Pen(dlg.Color, 3);
                routes.Routes.Add(route);
                gMapControl1.Overlays.Add(routes);
                gMapControl1.UpdateRouteLocalPosition(route);

                double theta = 26.245164 - (Convert.ToSingle(textBox2.Text));
                double dist = Math.Sin(deg2rad(47.640742)) * Math.Sin(deg2rad(Convert.ToSingle(textBox1.Text))) + Math.Cos(deg2rad(47.640742)) * Math.Cos(deg2rad(Convert.ToSingle(textBox1.Text))) * Math.Cos(deg2rad(theta));
                dist = Math.Acos(dist);
                dist = rad2deg(dist);
                //dist = dist * 60 * 1.1515;

                dist = dist * 1.1515 * 100;
                int rez = (int)dist;
                label16.Text = Convert.ToString(rez);
            }
            else
            {
                MessageBox.Show("ENTER LONG/LAT!");
            }
        }

        private void gMapControl1_Load(object sender, EventArgs e)
        {
            gMapControl1.DragButton = MouseButtons.Left;
            gMapControl1.CanDragMap = true;
            gMapControl1.MapProvider = GMapProviders.GoogleMap;
            gMapControl1.Position = new PointLatLng(47.640742, 26.245164);
            gMapControl1.MinZoom = 0;
            gMapControl1.MaxZoom = 24;
            gMapControl1.Zoom = 8;
            gMapControl1.AutoScroll = true;
            GMapOverlay markersOverlay = new GMapOverlay("markers");
            GMarkerGoogle marker = new GMarkerGoogle(new PointLatLng(47.640742, 26.245164),
            GMarkerGoogleType.green);
            markersOverlay.Markers.Add(marker);
            gMapControl1.Overlays.Add(markersOverlay);
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            dlg.ShowDialog();
            button2.BackColor = dlg.Color;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //
        }

    }
}
